(() => {
 'use strict';
 const panel=document.getElementById('preparation-assistant');if(!panel)return;
 const form=panel.closest('form'),$=id=>document.getElementById(id);
 const labels={contexte:'Contexte',faits:'Faits observés',objectif_manager:'Ce que vous souhaitez obtenir',enjeux:'Enjeux perçus'};
 const names=['titre','type_entretien','cdc_role','collaborateur_ref','fonction','date_entretien',...Object.keys(labels)];
 const modes={resume:'Résumer mes propos',preciser:'M’aider à préciser',eogi:'Explorer avec EOGI',trame:'Proposer une trame'};
 const newId=()=>Array.from(crypto.getRandomValues(new Uint8Array(16)),n=>n.toString(16).padStart(2,'0')).join('');
 const draftId=newId();let mode='',busy=false,result=null,origin=null,choices=[],lastRequest=null,dirty=false,submitting=false,historyContext='',historyItems=[];
 const eogiOriginal=JSON.parse($('preparation-eogi-original').value),eogiLabels=JSON.parse($('preparation-eogi-labels').value);
 const node=(tag,text='',className='')=>{const e=document.createElement(tag);if(text)e.textContent=text;if(className)e.className=className;return e;};
 const tell=text=>{$('preparation-status').textContent=text;};
 function snapshot(){const draft={};for(const name of names)draft[name]=form.elements.namedItem(name)?.value||'';const dictation=window.prepaDictation?.snapshot()||null;if(dictation&&Object.hasOwn(labels,dictation.field))draft[dictation.field]+=(draft[dictation.field].trim()?'\n\n':'')+dictation.text;return {draft,dictation,eogi:$('preparation-eogi-payload').value};}
 const fingerprint=s=>JSON.stringify(s);
 function controls(){document.querySelectorAll('[data-preparation-mode]').forEach(b=>{b.disabled=busy;b.setAttribute('aria-pressed',String(b.dataset.preparationMode===mode));});$('preparation-send').disabled=busy||!mode;$('preparation-apply').disabled=busy;$('preparation-retain-trame').disabled=busy;$('preparation-apply-summary').disabled=busy;}
 function summaryTarget(){const field=form.elements.namedItem($('preparation-summary-target').value);$('preparation-summary-replace-label').hidden=!field?.value.trim();$('preparation-summary-replace').checked=false;}
 function matches(){if(!origin||fingerprint(snapshot())!==fingerprint(origin)){tell('Les champs ou la dictée ont changé depuis cette proposition. Vos textes sont conservés ; demandez une proposition actualisée avant de la reprendre.');return false;}return true;}
 function currentEogi(){let staged={};try{staged=JSON.parse($('preparation-eogi-payload').value||'{}').fields||{};}catch{}return {...eogiOriginal.data,...staged};}
 function showChoices(values,kind){const box=$('preparation-choices');box.replaceChildren();choices=[];const current=kind==='eogi'?currentEogi():Object.fromEntries(Object.keys(labels).map(k=>[k,form.elements.namedItem(k).value]));
  for(const [key,value] of Object.entries(values)){
   const existing=(current[key]||'').trim(),section=node('section','','preparation-choice'),id='prepa-choice-'+kind+'-'+key;
   const select=document.createElement('input');select.type='checkbox';select.id=id;select.checked=!existing;
   const label=node('label','','preparation-check');label.htmlFor=id;label.append(select,node('strong',(kind==='eogi'?eogiLabels:labels)[key]));section.append(label);
   if(existing){const details=node('details'),summary=node('summary','Voir le texte déjà présent'),text=node('div',existing,'preparation-current');details.append(summary,text);section.append(details);}
   const edit=document.createElement('textarea');edit.rows=4;edit.maxLength=4000;edit.value=value;edit.id=id+'-text';const editLabel=node('label','Proposition modifiable');editLabel.htmlFor=edit.id;section.append(editLabel,edit);
   let replace=null;if(existing){replace=document.createElement('input');replace.type='checkbox';replace.id=id+'-replace';const consent=node('label','','preparation-check');consent.htmlFor=replace.id;consent.append(replace,node('span','Je confirme le remplacement du texte existant dans ce champ.'));section.append(consent);}
   choices.push({key,select,edit,replace,kind});box.append(section);
  }
  $('preparation-review').hidden=choices.length===0;
 }
 function render(answer){result=answer;$('preparation-result').hidden=false;$('preparation-result-title').textContent=modes[answer.mode]+' · proposition à relire';$('preparation-answer').textContent=answer.reply;
  const summary=answer.mode==='resume';$('preparation-answer').hidden=summary;$('preparation-summary-review').hidden=!summary;
  if(summary){$('preparation-summary-preview').value=answer.reply;$('preparation-summary-target').value=origin.dictation?.field||'contexte';summaryTarget();}
  const questions=$('preparation-questions');questions.replaceChildren();if(answer.questions.length){questions.append(node('h3','À préciser avec vous'));const list=node('ol');answer.questions.forEach(q=>list.append(node('li',q)));questions.append(list);}
  const sources=$('preparation-sources');sources.replaceChildren();if(answer.sources.length){sources.append(node('h3','Références utilisées'));for(const source of answer.sources){const details=node('details');details.append(node('summary','['+source.ref+'] '+source.titre),node('p',source.source||''),node('pre',source.extrait||''));sources.append(details);}}
  showChoices(answer.mode==='eogi'?answer.eogi:answer.fields,answer.mode==='eogi'?'eogi':'fields');
  $('preparation-trame-review').hidden=answer.mode!=='trame';if(answer.mode==='trame')$('preparation-trame-preview').value=answer.reply;
  tell(fingerprint(snapshot())===fingerprint(origin)?(answer.mode==='preciser'?'Répondez aux questions utiles. Pour reprendre vos précisions dans les champs, choisissez ensuite « Résumer mes propos ».':'Proposition prête. Relisez-la, répondez aux questions utiles ou choisissez les textes à reprendre.'):'Les champs ont changé pendant la réponse. Cette proposition reste consultable ; demandez une actualisation avant de l’appliquer.');
 }
 async function ask(nextMode){if(busy)return;mode=nextMode;const source=snapshot();if(!Object.keys(labels).some(k=>source.draft[k].trim())){tell('Décrivez ou dictez d’abord au moins un élément de la situation.');controls();return;}
  const question=$('preparation-question').value.trim();const key=JSON.stringify({mode,source,question});if(!lastRequest||lastRequest.key!==key)lastRequest={key,id:newId()};
  busy=true;controls();tell('L’assistant prépare sa proposition…');
  const data=new FormData();data.append('csrf',form.elements.namedItem('csrf').value);data.append('id',form.elements.namedItem('id').value);data.append('mode',mode);data.append('question',question);data.append('draft_id',draftId);data.append('request_id',lastRequest.id);data.append('draft',JSON.stringify(source.draft));
  try{
   const response=await fetch('index.php?action=preparation_chat',{method:'POST',body:data,credentials:'same-origin',redirect:'error'});
   if(response.status===401||response.status===419)throw Error('Votre session a expiré. Copiez vos textes avant de vous reconnecter.');
   let body;try{body=await response.json();}catch{throw Error('Réponse indisponible. Vos textes restent intacts.');}
   if(!response.ok||!body.ok)throw Error(body.error||'L’accompagnement est indisponible.');
   const conversationContext=JSON.stringify(source.draft);if(historyContext!==conversationContext){historyContext=conversationContext;historyItems=[];}
   historyItems.push({mode,question,reply:body.reply});historyItems=historyItems.slice(-6);const historyBox=$('preparation-history-items');historyBox.replaceChildren();for(const item of historyItems){const section=node('section','','preparation-choice');section.append(node('h4',modes[item.mode]),node('p',item.question?'Vous : '+item.question:'Vous : '+modes[item.mode]),node('div',item.reply,'preparation-answer'));historyBox.append(section);}$('preparation-history').hidden=false;
   origin=source;render(body);$('preparation-question').value='';$('preparation-result-title').tabIndex=-1;$('preparation-result-title').focus();
  }catch(e){tell(e instanceof TypeError?'Connexion interrompue. Vos textes sont conservés. Une même demande ne sera pas envoyée deux fois.':e.message);}
  finally{busy=false;controls();}
 }
 document.querySelectorAll('[data-preparation-mode]').forEach(b=>b.addEventListener('click',()=>ask(b.dataset.preparationMode)));
 $('preparation-send').addEventListener('click',()=>ask(mode));
 $('preparation-summary-target').addEventListener('change',summaryTarget);
 $('preparation-summary-preview').addEventListener('input',()=>{dirty=true;});
 $('preparation-apply-summary').addEventListener('click',()=>{
  if(busy||result?.mode!=='resume'||!matches())return;
  const text=$('preparation-summary-preview').value.trim(),key=$('preparation-summary-target').value,field=form.elements.namedItem(key);
  if(!Object.hasOwn(labels,key)||!field){tell('Choisissez un champ de destination.');return;}
  if(!text){tell('Le résumé est vide. Corrigez-le avant de le valider.');return;}
  if(text.length>4000){tell('Le résumé est trop long. Limitez-le à 4 000 caractères avant validation.');return;}
  if(field.value.trim()&&!$('preparation-summary-replace').checked){tell('Confirmez le remplacement du texte déjà présent dans le champ choisi.');return;}
  field.value=text;field.dispatchEvent(new Event('input',{bubbles:true}));field.dispatchEvent(new Event('change',{bubbles:true}));
  if(origin.dictation&&key===origin.dictation.field)window.prepaDictation?.consume(origin.dictation);
  dirty=true;$('preparation-summary-review').hidden=true;$('preparation-review').hidden=true;
  tell('Votre résumé corrigé a été repris dans « '+labels[key]+' ». Vérifiez le champ, puis cliquez sur Enregistrer.');
 });
 $('preparation-apply').addEventListener('click',()=>{
  if(!matches())return;const selected=choices.filter(c=>c.select.checked);if(!selected.length){tell('Cochez au moins un champ à reprendre.');return;}
  if(selected.some(c=>!c.edit.value.trim()||(c.replace&&!c.replace.checked))){tell('Vérifiez les textes cochés et confirmez séparément chaque remplacement d’un texte existant.');return;}
  if(result.mode==='eogi'){
   let old={fields:{},replace:[],revision:eogiOriginal.revision};try{if($('preparation-eogi-payload').value)old=JSON.parse($('preparation-eogi-payload').value);}catch{}
   const fields={},replace=new Set();for(const c of selected){fields[c.key]=c.edit.value.trim();if(c.replace?.checked)replace.add(c.key);}
   $('preparation-eogi-payload').value=JSON.stringify({fields,replace:[...replace],revision:eogiOriginal.revision,token:result.token});$('preparation-eogi-staged').hidden=false;
   tell('Reprise EOGI retenue. Cette sélection remplace toute reprise EOGI précédente en attente. Enregistrez la situation pour compléter votre grille.');
  }else{
   for(const c of selected){const field=form.elements.namedItem(c.key);field.value=c.edit.value.trim();field.dispatchEvent(new Event('input',{bubbles:true}));field.dispatchEvent(new Event('change',{bubbles:true}));}
   if(origin.dictation&&selected.some(c=>c.key===origin.dictation.field))window.prepaDictation?.consume(origin.dictation);
   tell('Les textes sélectionnés ont été repris. Vérifiez vos champs, puis enregistrez la situation.');
  }
  dirty=true;$('preparation-review').hidden=true;if(result.mode==='resume')$('preparation-summary-review').hidden=true;
 });
 $('preparation-retain-trame').addEventListener('click',()=>{if(!matches())return;const text=$('preparation-trame-preview').value.trim();if(!text){tell('La trame est vide.');return;}$('preparation-trame-retained').value=text;$('preparation-trame-token').value=result.token;$('preparation-trame-staged').hidden=false;$('preparation-trame-review').hidden=true;dirty=true;tell('Trame retenue et encore modifiable ci-dessous. Enregistrez la situation pour la conserver.');});
 $('preparation-clear-eogi').addEventListener('click',()=>{$('preparation-eogi-payload').value='';$('preparation-eogi-staged').hidden=true;tell('La reprise EOGI a été retirée. Votre grille enregistrée est inchangée.');});
 $('preparation-clear-trame').addEventListener('click',()=>{$('preparation-trame-retained').value='';$('preparation-trame-token').value='';$('preparation-trame-staged').hidden=true;tell('La reprise de trame a été retirée.');});
 window.addEventListener('prepa-request-summary',()=>{panel.scrollIntoView({behavior:'auto',block:'start'});ask('resume');});
 window.addEventListener('prepa-dictation-ready',()=>tell('Votre dictée est prête. Vous pouvez la relire, puis choisir « Résumer mes propos » sans la recopier.'));
 form.addEventListener('submit',event=>{if(busy){event.preventDefault();tell('Attendez la réponse avant d’enregistrer la situation.');return;}if(!event.defaultPrevented)submitting=true;});
 window.addEventListener('beforeunload',event=>{if(!submitting&&(dirty||busy)){event.preventDefault();event.returnValue='';}});
 controls();
})();
