/* Dictée facultative : aucun envoi avant le bouton Transcrire. */
(() => {
 'use strict';
 const panel=document.getElementById('dictee');if(!panel)return;
 const form=panel.closest('form'), $=id=>document.getElementById(id), status=$('dictee-status'), preview=$('dictee-preview');
 const labels={contexte:'Contexte',faits:'Faits observés',objectif_manager:'Ce que vous souhaitez obtenir',enjeux:'Enjeux perçus'};
 let target='',recorder=null,stream=null,chunks=[],blob=null,timer=null,seconds=0,bytes=0,busy=false,opening=false,nonce='',job='',generation=0;
 const buttons=['start','pause','resume','stop','send','apply','summary','discard'];
 function tell(text){status.textContent=text;}
 function controls(){const recording=recorder&&recorder.state!=='inactive';for(const name of buttons){let enabled=false;if(name==='start')enabled=!!target&&!recording&&!blob&&!preview.value&&!busy&&!opening;if(name==='pause')enabled=recorder?.state==='recording';if(name==='resume')enabled=recorder?.state==='paused';if(name==='stop')enabled=!!recording;if(name==='send')enabled=!!blob&&!busy&&!job;if(name==='apply'||name==='summary')enabled=!!preview.value.trim()&&!busy;if(name==='discard')enabled=!!target&&!busy; $('dictee-'+name).disabled=!enabled;}
 document.querySelectorAll('[data-dictee]').forEach(b=>b.disabled=busy||opening||!!recording||!!blob||!!preview.value);
 }
 function release(){stream?.getTracks().forEach(t=>t.stop());stream=null;clearInterval(timer);timer=null;}
 function reset(){generation++;if(recorder&&recorder.state!=='inactive'){recorder.onstop=null;recorder.stop();}release();recorder=null;chunks=[];blob=null;preview.value='';job='';nonce='';seconds=0;bytes=0;target='';panel.hidden=true;controls();}
 function stop(){if(recorder&&recorder.state!=='inactive')recorder.stop();}
 async function api(action,data){data.append('csrf',form.querySelector('[name=csrf]').value);let response;
 try{response=await fetch('index.php?action='+action,{method:'POST',body:data,credentials:'same-origin',redirect:'error'});}catch{throw Error('Connexion interrompue. Vos champs restent intacts.');}
 if(response.status===401||response.status===419)throw Error('Votre session a expiré. Copiez vos textes avant de vous reconnecter.');
 let result;try{result=await response.json();}catch{throw Error('Réponse indisponible. Vos champs restent intacts.');}if(!response.ok||!result.ok)throw Error(result.error||'Transcription indisponible.');return result;
 }
 async function poll(){busy=true;controls();const run=generation;
 try{for(let n=0;n<120;n++){if(n)await new Promise(resolve=>setTimeout(resolve,5000));if(run!==generation)return;const data=new FormData();data.append('job',job);const result=await api('stt_poll',data);if(result.status==='completed'){preview.value=result.text;blob=null;chunks=[];tell('Transcription prête. Corrigez le texte, puis ajoutez-le au champ choisi.');preview.focus();window.dispatchEvent(new Event('prepa-dictation-ready'));return;}if(result.status!=='pending')throw Error('Cette prise n’est plus disponible.');}throw Error('Le traitement prend plus de temps que prévu. Cliquez sur Rechercher le résultat.');}
 catch(e){tell(e.message);}finally{busy=false;$('dictee-send').textContent=job?'Rechercher le résultat':'Transcrire l’audio';controls();if(job&&!preview.value)$('dictee-send').disabled=false;}
 }
 document.querySelectorAll('[data-dictee]').forEach(b=>b.addEventListener('click',()=>{target=b.dataset.dictee;panel.hidden=false;$('dictee-target').textContent=labels[target];tell('Prêt à dicter. Le microphone sera activé seulement au démarrage.');controls();$('dictee-start').focus();panel.scrollIntoView({behavior:'auto',block:'center'});}));
 $('dictee-start').addEventListener('click',async()=>{opening=true;controls();const run=generation;
 try{stream=await navigator.mediaDevices.getUserMedia({audio:{channelCount:{ideal:1}}});if(run!==generation){release();return;}
 const mime=['audio/webm;codecs=opus','audio/mp4','audio/webm'].find(m=>MediaRecorder.isTypeSupported(m));if(!mime)throw Error('Format d’enregistrement non pris en charge. Utilisez la saisie au clavier.');
 try{recorder=new MediaRecorder(stream,{mimeType:mime,audioBitsPerSecond:40000});}catch{recorder=new MediaRecorder(stream,{mimeType:mime});}
 chunks=[];bytes=0;seconds=0;nonce=Array.from(crypto.getRandomValues(new Uint8Array(16)),x=>x.toString(16).padStart(2,'0')).join('');
 recorder.ondataavailable=e=>{if(e.data.size){chunks.push(e.data);bytes+=e.data.size;if(bytes>7*1024*1024)stop();}};
 recorder.onerror=()=>{stop();tell('La prise de son a été interrompue. Vérifiez le microphone.');};
 recorder.onstop=()=>{release();blob=new Blob(chunks,{type:recorder.mimeType});chunks=[];tell(blob.size>8388608?'Audio trop volumineux. Effacez cette prise et faites une dictée plus courte.':'Enregistrement terminé. Cliquez sur Transcrire pour envoyer cet audio au service de transcription.');if(blob.size>8388608)blob=null;controls();};
 recorder.start(1000);tell('Enregistrement en cours · 0 s');timer=setInterval(()=>{if(recorder?.state==='recording')seconds++;tell((recorder?.state==='paused'?'En pause':'Enregistrement en cours')+' · '+seconds+' s / 300 s');if(seconds>=300)stop();},1000);
 }catch(e){release();tell(e.name==='NotAllowedError'?'Microphone non autorisé. Autorisez-le dans le navigateur ou saisissez au clavier.':e.message||'Microphone indisponible.');}finally{opening=false;controls();}});
 $('dictee-pause').addEventListener('click',()=>{recorder.pause();tell('En pause.');controls();});
 $('dictee-resume').addEventListener('click',()=>{recorder.resume();tell('Enregistrement repris.');controls();});
 $('dictee-stop').addEventListener('click',stop);
 $('dictee-send').addEventListener('click',async()=>{if(job){await poll();return;}busy=true;controls();tell('Transmission de l’audio…');
 try{const data=new FormData();data.append('field',target);data.append('nonce',nonce);data.append('audio',blob,'dictee.'+(blob.type.includes('mp4')?'m4a':'webm'));const result=await api('stt_submit',data);job=result.job;blob=null;chunks=[];tell('Transcription en cours…');await poll();}
 catch(e){tell(e.message+' Vous pouvez réessayer cette transmission : une même prise ne sera pas envoyée deux fois.');}finally{busy=false;controls();if(job&&!preview.value)$('dictee-send').disabled=false;}});
 preview.addEventListener('input',controls);
 $('dictee-apply').addEventListener('click',()=>{const input=form.elements.namedItem(target),text=preview.value.trim();if(!text)return;input.value=input.value+(input.value.trim()?'\n\n':'')+text;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));reset();input.focus();});
 $('dictee-summary').addEventListener('click',()=>window.dispatchEvent(new Event('prepa-request-summary')));
 $('dictee-discard').addEventListener('click',reset);
 form.addEventListener('submit',e=>{if(target){e.preventDefault();tell('Ajoutez la transcription au champ ou effacez la prise avant d’enregistrer la situation.');status.focus();}});
 window.prepaDictation={snapshot:()=>target&&preview.value.trim()?{field:target,text:preview.value.trim()}:null,consume:source=>{if(source&&target===source.field&&preview.value.trim()===source.text)reset();}};
 window.addEventListener('beforeunload',e=>{if(target){e.preventDefault();e.returnValue='';}});
 window.addEventListener('pagehide',()=>{generation++;release();blob=null;chunks=[];});
 if(!window.isSecureContext||!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){document.querySelectorAll('[data-dictee]').forEach(b=>{b.disabled=true;b.title='La dictée nécessite HTTPS et un navigateur avec microphone.';});$('dictee-unavailable').hidden=false;}else controls();
})();
