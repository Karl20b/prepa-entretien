/* Éditeur de constellation systémique — SVG + JavaScript natif, sans dépendance.
 * Plateau logique 1000 × 700. Angle : 0 = regard vers le haut, sens horaire.
 */
(() => {
  'use strict';

  const boot = JSON.parse(document.getElementById('const-boot').textContent);
  const NS = 'http://www.w3.org/2000/svg';
  const W = 1000, H = 700;
  const SIZES = { 1: 26, 2: 36, 3: 48 };
  const COLORS = { personne: '#3E6BB0', cadre: '#C8A84B', role: '#1F3864', enjeu: '#B4531A', ressource: '#2E7D5B' };
  const LINK_STYLE = {
    lien:    { color: '#1F3864', width: 3, dash: '' },
    fort:    { color: '#1F3864', width: 8, dash: '' },
    tension: { color: '#B4531A', width: 4, dash: '14 8' },
    rupture: { color: '#8A8F99', width: 4, dash: '3 10' },
  };

  const svg = document.getElementById('board');
  const panel = document.getElementById('panel');
  const tabs = document.getElementById('tabs');
  const status = document.getElementById('save-status');
  const linkBtn = document.getElementById('btn-link');
  const linkKind = document.getElementById('link-kind');
  const ghostBox = document.getElementById('ghost');

  let doc = boot.data && Array.isArray(boot.data.images) && boot.data.images.length
    ? boot.data
    : { version: 1, images: [{ id: uid(), nom: 'Image actuelle', elements: [], liens: [] }] };
  let cur = 0;
  let sel = null;              // { kind: 'el' | 'link', id }
  let linkMode = false;
  let linkFrom = null;
  let drag = null;             // { mode: 'move' | 'rotate', id, dx, dy }
  let dirty = false;
  let saveTimer = null;

  // ------------------------------------------------------------ utilitaires
  function uid() { return Math.random().toString(36).slice(2, 10); }
  function img() { return doc.images[cur]; }
  function byId(id) { return img().elements.find(e => e.id === id); }
  function make(tag, attrs = {}, parent = null) {
    const n = document.createElementNS(NS, tag);
    for (const k in attrs) n.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(n);
    return n;
  }
  function pt(evt) {
    const p = svg.createSVGPoint();
    p.x = evt.clientX; p.y = evt.clientY;
    return p.matrixTransform(svg.getScreenCTM().inverse());
  }
  const oriented = e => ['personne', 'cadre', 'role'].includes(e.type);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const norm = a => ((Math.round(a) % 360) + 360) % 360;
  function esc(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

  // ------------------------------------------------------------ rendu
  function shape(e, g, ghost = false) {
    const r = SIZES[e.taille] || 36;
    const color = COLORS[e.type] || '#3E6BB0';
    const fill = ghost ? 'none' : color;
    const stroke = ghost ? color : '#FBFAF6';
    const sw = ghost ? 3 : 3;
    const dash = ghost ? '6 6' : '';
    switch (e.type) {
      case 'role':
        make('rect', { x: -r, y: -r, width: 2 * r, height: 2 * r, rx: 6, fill, stroke, 'stroke-width': sw, 'stroke-dasharray': dash }, g); break;
      case 'enjeu':
        make('polygon', { points: `0,${-r * 1.2} ${r * 1.2},0 0,${r * 1.2} ${-r * 1.2},0`, fill, stroke, 'stroke-width': sw, 'stroke-dasharray': dash }, g); break;
      case 'ressource':
        make('circle', { r, fill: ghost ? 'none' : '#E3F0EA', stroke: color, 'stroke-width': 4, 'stroke-dasharray': '8 5' }, g); break;
      default:
        make('circle', { r, fill, stroke, 'stroke-width': sw, 'stroke-dasharray': dash }, g);
    }
    // Direction du regard : flèche sur le bord, tournée selon l'angle (personnes et rôles)
    if (!oriented(e)) return;
    const rot = make('g', { transform: `rotate(${e.angle})` }, g);
    make('polygon', { points: `-11,${-r - 3} 11,${-r - 3} 0,${-r - 22}`, fill: ghost ? 'none' : color, stroke: ghost ? color : 'none', 'stroke-width': 2 }, rot);
  }

  function render() {
    svg.textContent = '';
    make('rect', { x: 0, y: 0, width: W, height: H, fill: '#FBFAF6' }, svg);
    // Repères discrets : centre et bord du plateau
    make('rect', { x: 6, y: 6, width: W - 12, height: H - 12, fill: 'none', stroke: '#E4DFD2', 'stroke-width': 2, rx: 12 }, svg);
    make('circle', { cx: W / 2, cy: H / 2, r: 5, fill: '#D8D2C2' }, svg);
    const t = make('text', { x: W / 2, y: 30, 'text-anchor': 'middle', 'font-size': 16, fill: '#A39C8A', 'font-family': 'Calibri, Carlito, Arial, sans-serif' }, svg);
    t.textContent = img().nom;

    // Image précédente en filigrane, avec la trace des déplacements
    if (ghostBox.checked && cur > 0) {
      const prev = doc.images[cur - 1];
      const gl = make('g', { opacity: 0.35, 'pointer-events': 'none' }, svg);
      for (const p of prev.elements) {
        const now = byId(p.id);
        if (now && Math.hypot(now.x - p.x, now.y - p.y) > 20) {
          make('line', { x1: p.x, y1: p.y, x2: now.x, y2: now.y, stroke: '#7A5F17', 'stroke-width': 2, 'stroke-dasharray': '4 6' }, gl);
        }
        const g = make('g', { transform: `translate(${p.x},${p.y})` }, gl);
        shape(p, g, true);
      }
    }

    // Liens
    const gLinks = make('g', {}, svg);
    for (const l of img().liens) {
      const a = byId(l.from), b = byId(l.to);
      if (!a || !b) continue;
      const st = LINK_STYLE[l.kind] || LINK_STYLE.lien;
      const g = make('g', { 'data-link': l.id, class: 'link' }, gLinks);
      make('line', { x1: a.x, y1: a.y, x2: b.x, y2: b.y, stroke: 'transparent', 'stroke-width': 22 }, g);
      if (sel && sel.kind === 'link' && sel.id === l.id) {
        make('line', { x1: a.x, y1: a.y, x2: b.x, y2: b.y, stroke: '#C8A84B', 'stroke-width': st.width + 8, opacity: 0.5 }, g);
      }
      make('line', { x1: a.x, y1: a.y, x2: b.x, y2: b.y, stroke: st.color, 'stroke-width': st.width, 'stroke-dasharray': st.dash, 'stroke-linecap': 'round' }, g);
      if (l.kind === 'rupture') {
        const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
        make('path', { d: `M${mx - 10},${my - 10} L${mx + 10},${my + 10} M${mx + 10},${my - 10} L${mx - 10},${my + 10}`, stroke: st.color, 'stroke-width': 4 }, g);
      }
      if (l.label) {
        const lt = make('text', { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 - 10, 'text-anchor': 'middle', 'font-size': 16, fill: st.color, 'font-family': 'Calibri, Carlito, Arial, sans-serif', 'paint-order': 'stroke', stroke: '#FBFAF6', 'stroke-width': 5 }, g);
        lt.textContent = l.label;
      }
    }

    // Éléments
    const gEls = make('g', {}, svg);
    for (const e of img().elements) {
      const g = make('g', { transform: `translate(${e.x},${e.y})`, 'data-el': e.id, class: 'el' }, gEls);
      const r = SIZES[e.taille] || 36;
      const isSel = sel && sel.kind === 'el' && sel.id === e.id;
      const isFrom = linkFrom === e.id;
      if (isSel || isFrom) {
        make('circle', { r: r + 12, fill: 'none', stroke: isFrom ? '#B4531A' : '#C8A84B', 'stroke-width': 3, 'stroke-dasharray': '6 5' }, g);
      }
      shape(e, g);
      // Étiquette sous l'élément (décalée si le regard pointe vers le bas), au-dessus près du bord inférieur
      const down = oriented(e) && Math.cos(e.angle * Math.PI / 180) < -0.5;
      let ly = r + 30 + (down ? 20 : 0);
      if (e.y + ly > H - 12) ly = -(r + (oriented(e) && !down ? 30 : 12));
      const label = make('text', { y: ly, 'text-anchor': 'middle', 'font-size': 19, 'font-weight': 700, fill: '#1F3864', 'font-family': 'Calibri, Carlito, Arial, sans-serif', 'paint-order': 'stroke', stroke: '#FBFAF6', 'stroke-width': 5 }, g);
      label.textContent = e.label;
      if (isSel && !linkMode && oriented(e)) {
        // Poignée d'orientation
        const rad = e.angle * Math.PI / 180, d = r + 40;
        make('line', { x1: 0, y1: 0, x2: Math.sin(rad) * d, y2: -Math.cos(rad) * d, stroke: '#C8A84B', 'stroke-width': 2, 'pointer-events': 'none' }, g);
        make('circle', { cx: Math.sin(rad) * d, cy: -Math.cos(rad) * d, r: 11, fill: '#C8A84B', stroke: '#1F3864', 'stroke-width': 2, 'data-handle': e.id, class: 'handle' }, g);
      }
    }
    svg.classList.toggle('linking', linkMode);
  }

  function renderTabs() {
    tabs.innerHTML = '';
    doc.images.forEach((im, i) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'tab' + (i === cur ? ' active' : '');
      b.textContent = im.nom;
      b.addEventListener('click', () => { cur = i; sel = null; linkFrom = null; refresh(); });
      tabs.appendChild(b);
    });
    const add = document.createElement('button');
    add.type = 'button'; add.className = 'tab tab-add';
    add.textContent = '+ Nouvelle image (copie)';
    add.title = 'Copie l\'image en cours pour tester des déplacements';
    add.addEventListener('click', () => {
      const copy = JSON.parse(JSON.stringify(img()));
      copy.id = uid();
      copy.nom = doc.images.length === 1 ? 'Image souhaitée' : 'Image ' + (doc.images.length + 1);
      doc.images.splice(cur + 1, 0, copy);
      cur += 1; sel = null; changed();
    });
    tabs.appendChild(add);
  }

  function renderPanel() {
    const types = Object.entries(boot.types).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join('');
    const kinds = Object.entries(boot.liens).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join('');
    let html = '';
    if (sel && sel.kind === 'el' && byId(sel.id)) {
      const e = byId(sel.id);
      html = `<h2>Élément</h2>
        <label>Nom ou rôle<input id="p-label" maxlength="60" value="${esc(e.label)}"></label>
        <label>Type<select id="p-type">${types}</select></label>
        <label>Taille (importance)<select id="p-taille"><option value="1">Petite</option><option value="2">Moyenne</option><option value="3">Grande</option></select></label>
        ${oriented(e) ? `<label>Orientation du regard : <span id="p-angle-v">${e.angle}°</span><input type="range" id="p-angle" min="0" max="359" value="${e.angle}"></label>` : ''}
        <label>Note<textarea id="p-note" rows="3" maxlength="300" placeholder="Ressenti, observation…">${esc(e.note || '')}</textarea></label>
        <button type="button" class="btn btn-small btn-danger" id="p-del">Supprimer l'élément</button>`;
      panel.innerHTML = html;
      panel.querySelector('#p-type').value = e.type;
      panel.querySelector('#p-taille').value = String(e.taille);
      bind('#p-label', 'input', v => { e.label = v || 'Sans nom'; });
      bind('#p-type', 'change', v => { e.type = v; renderPanel(); });
      bind('#p-taille', 'change', v => { e.taille = Number(v); });
      if (oriented(e)) bind('#p-angle', 'input', v => { e.angle = norm(Number(v)); panel.querySelector('#p-angle-v').textContent = e.angle + '°'; });
      bind('#p-note', 'input', v => { e.note = v; }, false);
      panel.querySelector('#p-del').addEventListener('click', removeSelected);
    } else if (sel && sel.kind === 'link') {
      const l = img().liens.find(x => x.id === sel.id);
      if (!l) { sel = null; return renderPanel(); }
      const a = byId(l.from), b = byId(l.to);
      html = `<h2>Lien</h2><p class="hint">${esc(a ? a.label : '?')} — ${esc(b ? b.label : '?')}</p>
        <label>Nature<select id="p-kind">${kinds}</select></label>
        <label>Étiquette<input id="p-llabel" maxlength="60" value="${esc(l.label || '')}" placeholder="Ex. désaccord sur les priorités"></label>
        <button type="button" class="btn btn-small btn-danger" id="p-del">Supprimer le lien</button>`;
      panel.innerHTML = html;
      panel.querySelector('#p-kind').value = l.kind;
      bind('#p-kind', 'change', v => { l.kind = v; });
      bind('#p-llabel', 'input', v => { l.label = v; });
      panel.querySelector('#p-del').addEventListener('click', removeSelected);
    } else {
      html = `<h2>Image : ${esc(img().nom)}</h2>
        <label>Nom de l'image<input id="p-iname" maxlength="60" value="${esc(img().nom)}"></label>
        ${doc.images.length > 1 ? '<button type="button" class="btn btn-small btn-danger" id="p-idel">Supprimer cette image</button>' : ''}
        <h3>Repères de lecture</h3>
        <ul class="legend">
          <li><b>Place</b> : centre ou périphérie, proximité</li>
          <li><b>Regard</b> : vers qui ou quoi chacun est tourné</li>
          <li><b>Taille</b> : importance perçue</li>
          <li><b>Liens</b> : soutien, tension, rupture</li>
        </ul>
        <h3>Légende</h3>
        <ul class="legend">${Object.entries(boot.types).map(([k, v]) => `<li><span class="sw sw-${k}"></span>${esc(v)}</li>`).join('')}</ul>
        <p class="hint">${linkMode ? 'Mode liaison : cliquez sur deux éléments.' : 'Cliquez sur un élément ou un lien pour le modifier.'}</p>`;
      panel.innerHTML = html;
      bind('#p-iname', 'input', v => { img().nom = v || 'Image'; renderTabs(); });
      const idel = panel.querySelector('#p-idel');
      if (idel) idel.addEventListener('click', () => {
        if (!confirm('Supprimer l\'image « ' + img().nom + ' » ?')) return;
        doc.images.splice(cur, 1); cur = Math.max(0, cur - 1); changed();
      });
    }
  }

  function bind(selector, ev, fn, rerender = true) {
    const n = panel.querySelector(selector);
    n.addEventListener(ev, () => { fn(n.value); if (rerender) render(); markDirty(); });
  }

  function refresh() { render(); renderTabs(); renderPanel(); }
  function changed() { refresh(); markDirty(); }

  // ------------------------------------------------------------ actions
  function addElement(type, x, y) {
    const n = img().elements.filter(e => e.type === type).length + 1;
    const base = type === 'cadre' ? 'Moi' : (boot.types[type] || 'Élément').split(' ')[0];
    const e = {
      id: uid(), type,
      label: type === 'cadre' ? 'Moi' : `${base} ${n}`,
      x: x ?? clamp(W / 2 + (Math.random() - 0.5) * 300, 60, W - 60),
      y: y ?? clamp(H / 2 + (Math.random() - 0.5) * 200, 60, H - 60),
      angle: type === 'cadre' ? 180 : 0, taille: 2, note: '',
    };
    img().elements.push(e);
    sel = { kind: 'el', id: e.id };
    changed();
    const input = panel.querySelector('#p-label');
    if (input) { input.focus(); input.select(); }
  }

  function removeSelected() {
    if (!sel) return;
    const im = img();
    if (sel.kind === 'el') {
      im.elements = im.elements.filter(e => e.id !== sel.id);
      im.liens = im.liens.filter(l => l.from !== sel.id && l.to !== sel.id);
    } else {
      im.liens = im.liens.filter(l => l.id !== sel.id);
    }
    sel = null;
    changed();
  }

  function setLinkMode(on) {
    linkMode = on; linkFrom = null;
    linkBtn.classList.toggle('btn-primary', on);
    linkBtn.textContent = on ? 'Terminer les liaisons' : 'Relier deux éléments';
    refresh();
  }

  function clickElementInLinkMode(id) {
    if (!linkFrom) { linkFrom = id; render(); return; }
    if (linkFrom === id) { linkFrom = null; render(); return; }
    const exists = img().liens.find(l => (l.from === linkFrom && l.to === id) || (l.from === id && l.to === linkFrom));
    if (exists) {
      exists.kind = linkKind.value;
      sel = { kind: 'link', id: exists.id };
    } else {
      const l = { id: uid(), from: linkFrom, to: id, kind: linkKind.value, label: '' };
      img().liens.push(l);
      sel = { kind: 'link', id: l.id };
    }
    linkFrom = null;
    changed();
  }

  // ------------------------------------------------------------ souris / tactile
  svg.addEventListener('pointerdown', evt => {
    const handle = evt.target.closest('[data-handle]');
    const elNode = evt.target.closest('[data-el]');
    const linkNode = evt.target.closest('[data-link]');
    const p = pt(evt);

    if (handle) {
      drag = { mode: 'rotate', id: handle.getAttribute('data-handle') };
    } else if (elNode) {
      const id = elNode.getAttribute('data-el');
      if (linkMode) { clickElementInLinkMode(id); return; }
      const e = byId(id);
      sel = { kind: 'el', id };
      drag = { mode: 'move', id, dx: p.x - e.x, dy: p.y - e.y, moved: false };
      render(); renderPanel();
    } else if (linkNode) {
      sel = { kind: 'link', id: linkNode.getAttribute('data-link') };
      render(); renderPanel();
      return;
    } else {
      sel = null; linkFrom = null;
      render(); renderPanel();
      return;
    }
    try { svg.setPointerCapture(evt.pointerId); } catch (_) { /* évènement synthétique */ }
    evt.preventDefault();
  });

  svg.addEventListener('pointermove', evt => {
    if (!drag) return;
    const e = byId(drag.id);
    if (!e) return;
    const p = pt(evt);
    if (drag.mode === 'move') {
      e.x = Math.round(clamp(p.x - drag.dx, 30, W - 30));
      e.y = Math.round(clamp(p.y - drag.dy, 30, H - 30));
      drag.moved = true;
    } else {
      e.angle = norm(Math.atan2(p.x - e.x, -(p.y - e.y)) * 180 / Math.PI);
      const v = panel.querySelector('#p-angle');
      if (v) { v.value = e.angle; panel.querySelector('#p-angle-v').textContent = e.angle + '°'; }
    }
    render();
  });

  const endDrag = () => {
    if (drag && (drag.mode === 'rotate' || drag.moved)) markDirty();
    drag = null;
  };
  svg.addEventListener('pointerup', endDrag);
  svg.addEventListener('pointercancel', endDrag);

  svg.addEventListener('dblclick', evt => {
    if (evt.target.closest('[data-el]') || evt.target.closest('[data-link]')) return;
    const p = pt(evt);
    addElement('personne', Math.round(p.x), Math.round(p.y));
  });

  document.addEventListener('keydown', evt => {
    const tag = (evt.target.tagName || '').toLowerCase();
    if (['input', 'textarea', 'select'].includes(tag)) return;
    if ((evt.key === 'Delete' || evt.key === 'Backspace') && sel) { evt.preventDefault(); removeSelected(); }
    if (evt.key === 'Escape') { if (linkMode) setLinkMode(false); else { sel = null; refresh(); } }
    if (sel && sel.kind === 'el' && (evt.key === 'ArrowLeft' || evt.key === 'ArrowRight') && oriented(byId(sel.id))) {
      const e = byId(sel.id);
      e.angle = norm(e.angle + (evt.key === 'ArrowRight' ? 15 : -15));
      evt.preventDefault(); render(); renderPanel(); markDirty();
    }
    if ((evt.ctrlKey || evt.metaKey) && evt.key === 's') { evt.preventDefault(); save(); }
  });

  // ------------------------------------------------------------ barre d'outils
  document.querySelectorAll('.add-el').forEach(b => b.addEventListener('click', () => {
    if (linkMode) setLinkMode(false);
    addElement(b.dataset.type);
  }));
  linkBtn.addEventListener('click', () => setLinkMode(!linkMode));
  ghostBox.addEventListener('change', render);
  document.getElementById('btn-save').addEventListener('click', () => save());
  ['f-titre', 'f-question', 'f-situation'].forEach(id => document.getElementById(id).addEventListener('input', markDirty));

  // ------------------------------------------------------------ export
  function exportSvgString() {
    const keepSel = sel, keepFrom = linkFrom, keepMode = linkMode;
    sel = null; linkFrom = null; linkMode = false;
    render();
    const clone = svg.cloneNode(true);
    clone.setAttribute('width', W); clone.setAttribute('height', H);
    const out = new XMLSerializer().serializeToString(clone);
    sel = keepSel; linkFrom = keepFrom; linkMode = keepMode;
    render();
    return out;
  }
  function fileName(ext) {
    const t = (document.getElementById('f-titre').value || 'constellation') + ' - ' + img().nom;
    return t.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9 _-]+/g, '').trim().replace(/\s+/g, '_') + '.' + ext;
  }
  function download(blob, name) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
  document.getElementById('btn-svg').addEventListener('click', () => {
    download(new Blob([exportSvgString()], { type: 'image/svg+xml' }), fileName('svg'));
  });
  document.getElementById('btn-png').addEventListener('click', () => {
    const url = URL.createObjectURL(new Blob([exportSvgString()], { type: 'image/svg+xml' }));
    const im = new Image();
    im.onload = () => {
      const c = document.createElement('canvas');
      c.width = W * 2; c.height = H * 2;
      c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      c.toBlob(b => download(b, fileName('png')), 'image/png');
    };
    im.src = url;
  });

  // ------------------------------------------------------------ enregistrement
  function markDirty() {
    dirty = true;
    status.textContent = 'Modifications non enregistrées';
    clearTimeout(saveTimer);
    saveTimer = setTimeout(save, 2500); // enregistrement automatique
  }

  async function save() {
    clearTimeout(saveTimer);
    const fd = new FormData();
    fd.append('csrf', boot.csrf);
    fd.append('id', boot.id);
    fd.append('titre', document.getElementById('f-titre').value);
    fd.append('question', document.getElementById('f-question').value);
    fd.append('situation_id', document.getElementById('f-situation').value);
    fd.append('data', JSON.stringify(doc));
    status.textContent = 'Enregistrement…';
    try {
      const res = await fetch(boot.saveUrl, { method: 'POST', body: fd, credentials: 'same-origin' });
      const json = await res.json().catch(() => ({ ok: false, error: 'Réponse inattendue (session expirée ?)' }));
      if (!res.ok || !json.ok) throw new Error(json.error || ('HTTP ' + res.status));
      dirty = false;
      status.textContent = 'Enregistré à ' + json.saved_at;
      if (json.description !== undefined) document.getElementById('description').textContent = json.description;
      return true;
    } catch (err) {
      status.textContent = 'Échec de l\'enregistrement : ' + err.message;
      return false;
    }
  }

  // La lecture IA porte sur la version enregistrée : on enregistre d'abord si besoin
  const formAnalyse = document.getElementById('form-analyse');
  formAnalyse.addEventListener('submit', async evt => {
    if (!dirty) return;
    evt.preventDefault();
    if (await save()) formAnalyse.submit();
  });

  window.addEventListener('beforeunload', evt => {
    if (dirty) { evt.preventDefault(); evt.returnValue = ''; }
  });

  refresh();
})();
