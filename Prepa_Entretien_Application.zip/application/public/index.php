<?php
declare(strict_types=1);

require dirname(__DIR__) . '/src/bootstrap.php';

use App\Ai\AiException;
use App\Ai\AiFactory;
use App\Constellation\ConstellationData;
use App\Constellation\Describer;
use App\Db;
use App\Repo\ConstellationRepo;
use App\Domain\Categorie;
use App\Domain\TypeEntretien;
use App\Prompt\PromptBuilder;
use App\Rag\Chunker;
use App\Rag\DocumentIndexer;
use App\Rag\FulltextRetriever;
use App\Repo\DocumentRepo;
use App\Repo\MessageRepo;
use App\Repo\SituationRepo;

\App\Auth::gate(Db::pdo());
if (($_GET['action'] ?? '') === 'logout' && $_SERVER['REQUEST_METHOD'] === 'POST') \App\Auth::logout();

$action = (string) ($_GET['action'] ?? 'list');
$user   = current_user();
$isPost = $_SERVER['REQUEST_METHOD'] === 'POST';
if ($isPost) {
    csrf_check();
}
$id = (int) (($isPost ? $_POST['id'] ?? null : $_GET['id'] ?? null) ?? 0);

$pdo        = Db::pdo();
$situations = new SituationRepo($pdo);
$messages   = new MessageRepo($pdo);
$documents  = new DocumentRepo($pdo);
$retriever  = new FulltextRetriever($pdo);
$indexer    = new DocumentIndexer($pdo, new Chunker((int) config('rag.chunk_size', 1200), (int) config('rag.chunk_overlap', 200)));
$prompts    = new PromptBuilder(max(24000,(int) config('rag.max_context_chars', 9000)), (int) config('rag.history_messages', 10));
$constellations = new ConstellationRepo($pdo);
$describer  = new Describer();
$ateliers = new \App\Repo\AtelierRepo($pdo);
$atelierChat = new \App\Repo\AtelierChatRepo($pdo);

$requirePost  = static function () use ($isPost): void { if (!$isPost) { http_response_code(405); exit('Méthode non autorisée.'); } };
$requireAdmin = static function (): void { if (!is_admin()) { http_response_code(403); exit('Accès réservé aux administrateurs.'); } };

switch ($action) {
    case 'redaction':
    case 'redaction_save':
    case 'redaction_download':
        \App\Redaction\Controller::serve($pdo,$user,$action,$id);

    case 'preparation_chat':
        \App\Preparation\Controller::serve($pdo,$user);
    case 'stt_submit':
    case 'stt_poll':
        \App\Stt\Dictation::serve($action,$user);


    case 'role_reference':\App\Reference\RoleCatalog::serve();

    case 'guide':
        $capsules = json_decode((string)file_get_contents(APP_ROOT . '/config/guide.json'), true) ?: [];
        $helpDocs=$pdo->query("SELECT titre,source,contenu FROM pe_documents WHERE actif=1 AND categorie='aide_utilisation' ORDER BY titre")->fetchAll();
        render('guide', ['capsules' => $capsules, 'helpDocs'=>$helpDocs], 'Guide d’utilisation');
        break;

    case 'media':
        \App\Media::serve();

    case 'accounts':
    case 'account_create':
    case 'account_update':
    case 'account_link':
        $requireAdmin();
        $accountsRepo = new \App\Repo\AccountRepo($pdo);
        $newLink = null; $linkType = ''; $linkUser = '';
        if ($action !== 'accounts') {
            $requirePost();
            try {
                $target = (string)($_POST['username'] ?? '');
                if ($action === 'account_create') {
                    $code = $accountsRepo->create($user, $target, (string)($_POST['display_name'] ?? ''), (string)($_POST['role'] ?? 'user'));
                    $linkType = 'activate'; $linkUser = mb_strtolower(trim($target));
                } elseif ($action === 'account_link') {
                    $linkType = (string)($_POST['kind'] ?? ''); $linkUser = $target;
                    $code = $accountsRepo->issueToken($user, $target, $linkType);
                } else {
                    $accountsRepo->update($user, $target, (string)($_POST['display_name'] ?? ''), (string)($_POST['role'] ?? ''), !empty($_POST['active']));
                    flash('Compte mis à jour. Les droits sont pris en compte immédiatement.', 'success');
                    redirect('index.php?action=accounts');
                }
                $newLink = rtrim((string)config('app.base_url', 'https://entretiens.exemple.ch'), '/') . '/index.php?action=activate#activation=' . rawurlencode($code);
            } catch (\InvalidArgumentException $e) {
                flash($e->getMessage(), 'error');
            }
        }
        render('accounts', ['accounts'=>$accountsRepo->all(), 'audit'=>$accountsRepo->auditRecent(), 'newLink'=>$newLink, 'linkType'=>$linkType, 'linkUser'=>$linkUser], 'Comptes et accès');
        break;


    case 'fiches':
        render('fiches', ['fiches'=>\App\Atelier\Fiches::all($pdo)], 'Fiches pratiques');
        break;
    case 'fiche_photo':
        \App\Atelier\Fiches::photo();
    case 'ateliers':
        render('ateliers', ['items'=>$situations->all($user)], 'Analyse et feed-back');
        break;
    case 'atelier_fill_preview':
        $requirePost();
        $s=$situations->find($id,$user) ?? not_found();
        $kind=(string)($_POST['kind']??'');
        if(!in_array($kind,['eogi','feedback'],true))not_found();
        try {
            $row=$ateliers->save($id,$kind,$user,$_POST,(int)($_POST['revision']??0));
            if(\App\Atelier\FillProposal::emptyFields($kind,$row['data'])===[])throw new \InvalidArgumentException('Tous les champs de cette grille sont déjà remplis. Aucun texte ne sera remplacé.');
            $source=(string)($_GET['source']??'');
            $origin=\App\Atelier\FillProposal::source($pdo,$id,$kind,$user,$source);
            set_time_limit((int)config('ai.timeout',120)+30);
            $ai=AiFactory::make();
            $raw=$ai->chat($prompts->system($s),[['role'=>'user','content'=>\App\Atelier\FillProposal::request($kind,$row['data'],$origin['text'])]]);
            $fields=\App\Atelier\FillProposal::parse($raw,$kind,$row['data'],$origin['sources']);
            if($fields===[])throw new \InvalidArgumentException('Cette réponse ne propose pas de texte à reprendre dans les champs vides. Précisez votre demande à l’assistant.');
            \App\Atelier\FillProposal::remember($user,$id,$kind,(int)$row['revision'],\App\Atelier\Grille::contextHash($s),$source,$origin,$fields);
            redirect('index.php?action=atelier_fill_review&id='.$id.'&kind='.$kind);
        }catch(\InvalidArgumentException|\RuntimeException $e){flash($e->getMessage(),'error');redirect('index.php?action=atelier&id='.$id.'&kind='.$kind.'#assistance');}
    case 'atelier_fill_review':
        $s=$situations->find($id,$user) ?? not_found();$kind=(string)($_GET['kind']??'');
        if(!in_array($kind,['eogi','feedback'],true))not_found();
        $pending=\App\Atelier\FillProposal::pending($user,$id,$kind);
        $row=$ateliers->find($id,$kind,$user);
        if(!$pending || !$row || (int)$row['revision']!==$pending['revision'] || \App\Atelier\Grille::contextHash($s)!==$pending['context']){
            unset($_SESSION['atelier_fill'][$id.':'.$kind]);flash('L’aperçu a expiré ou la grille a changé. Préparez un nouvel aperçu.','error');redirect('index.php?action=atelier&id='.$id.'&kind='.$kind);
        }
        render('atelier_fill_review',['s'=>$s,'kind'=>$kind,'pending'=>$pending],'Valider le remplissage de la grille');
        break;
    case 'atelier_fill_apply':
        $requirePost();$situations->find($id,$user) ?? not_found();$kind=(string)($_POST['kind']??'');
        if(!in_array($kind,['eogi','feedback'],true))not_found();
        try {
            $selected=$_POST['selected']??[];if(!is_array($selected))throw new \InvalidArgumentException('Sélection de champs invalide.');
            $edits=$_POST['edits']??null;if(!is_array($edits))throw new \InvalidArgumentException('Textes de l’aperçu invalides. Rechargez l’aperçu.');
            $n=\App\Atelier\FillProposal::apply($pdo,$user,$id,$kind,(string)($_POST['nonce']??''),$selected,$edits);
            flash($n.' champ'.($n>1?'s':'').' complété'.($n>1?'s':'').' après votre validation. Vos textes existants ont été conservés.','success');
            redirect('index.php?action=atelier&id='.$id.'&kind='.$kind.'#grille');
        }catch(\InvalidArgumentException|\RuntimeException $e){flash($e->getMessage(),'error');redirect('index.php?action=atelier_fill_review&id='.$id.'&kind='.$kind);}

    case 'atelier':
    case 'atelier_save':
    case 'atelier_generate':
    case 'atelier_help':
        $s=$situations->find($id,$user) ?? not_found();
        $kind=(string)($_POST['kind'] ?? $_GET['kind'] ?? 'eogi');
        if(!in_array($kind,['eogi','feedback'],true))not_found();
        $row=$ateliers->find($id,$kind,$user);
        $errors=[]; $helpQuestion=is_string($_POST['assistant_question']??null)?trim($_POST['assistant_question']):''; $form=\App\Atelier\Grille::withSituationFacts($kind,$row['data']??[],$s); $revision=(int)($row['revision']??0);
        if($action!=='atelier'){
            $requirePost(); $form=$_POST; $revision=(int)($_POST['revision']??0);
            try {
                $row=$ateliers->save($id,$kind,$user,$_POST,$revision);
                $form=$row['data']; $revision=(int)$row['revision'];
                if($action==='atelier_help'){
                    if($helpQuestion==='' || mb_strlen($helpQuestion)>2000)throw new \InvalidArgumentException('Saisissez une question de 1 à 2 000 caractères. Votre brouillon est enregistré.');
                    set_time_limit((int)config('ai.timeout',120)+30);
                    $chunks=(new \App\Reference\Sources($pdo))->search($s,$helpQuestion.' '.\App\Atelier\Assistant::query($kind,$form),6,$kind==='eogi'?['systemique']:['feedback','ecoute']);
                    [$sourcesBlock,$sourcesMeta]=$prompts->sources($chunks);
                    $history=\App\Atelier\Assistant::conversation(array_values(array_filter($atelierChat->history($id,$kind,$user,40),static fn($m)=>$m['context_hash']===\App\Atelier\Grille::contextHash($s))));
                    $history[]=['role'=>'user','content'=>\App\Atelier\Assistant::help($kind,$form,$helpQuestion,$sourcesBlock)];
                    $ai=AiFactory::make();
                    $answer=$ai->chat($prompts->system($s,null,$ateliers->context($id,$user)),$history);
                    \App\Rag\SourceValidator::check($answer,$sourcesMeta);
                    $atelierChat->exchange($id,$kind,$user,$revision,\App\Atelier\Grille::contextHash($s),$helpQuestion,$answer,$sourcesMeta,$ai->name());
                    flash('L’assistant a répondu. Vous pouvez reprendre les formulations utiles dans votre grille.','success');
                    redirect('index.php?action=atelier&id='.$id.'&kind='.$kind.'#assistance-reponse');
                }
                if($action==='atelier_generate'){
                    $essential=$kind==='eogi'?'question':'faits';
                    if(trim($form[$essential])==='')throw new \InvalidArgumentException($kind==='eogi'?'Précisez la question de travail avant de demander une analyse. Votre brouillon est enregistré.':'Complétez « 1 · Exposer les faits » dans la grille ci-dessous, ou les faits observés de la situation. Les pistes de l’assistant ne constituent pas des faits vérifiés. Votre brouillon est enregistré.');
                    set_time_limit((int)config('ai.timeout',120)+30);
                    $chunks=(new \App\Reference\Sources($pdo))->search($s,\App\Atelier\Assistant::query($kind,$form),8,$kind==='eogi'?['systemique']:['feedback','ecoute']);
                    [$sourcesBlock,$sourcesMeta]=$prompts->sources($chunks);
                    $ai=AiFactory::make();
                    $answer=$ai->chat($prompts->system($s,null,$ateliers->context($id,$user)),[['role'=>'user','content'=>\App\Atelier\Assistant::request($kind,$form,$sourcesBlock, array_values(array_filter($atelierChat->history($id,$kind,$user,12),static fn($m)=>$m['context_hash']===\App\Atelier\Grille::contextHash($s))))]]);
                    \App\Rag\SourceValidator::check($answer,$sourcesMeta);
                    if(!$ateliers->saveAnalysis($id,$kind,$user,$revision,\App\Atelier\Grille::contextHash($s),$answer,$sourcesMeta,$ai->name()))throw new \RuntimeException('Le brouillon a changé pendant la génération. Votre texte est conservé ; relancez sur la version actuelle.');
                    flash('Proposition prête. Relisez les hypothèses, les formulations et les sources.','success');
                } else flash('Brouillon enregistré.','success');
                redirect('index.php?action=atelier&id='.$id.'&kind='.$kind.($action==='atelier_generate'?'#proposition':''));
            }catch(\InvalidArgumentException|\RuntimeException $e){
                $errors[]=$e->getMessage();
                if(!$e instanceof AiException)http_response_code($e instanceof \InvalidArgumentException?422:409);
                $row=$ateliers->find($id,$kind,$user);
            }
        }
        render('atelier',['s'=>$s,'kind'=>$kind,'row'=>$row,'form'=>$form,'revision'=>$revision,'errors'=>$errors,'helpQuestion'=>$helpQuestion,'chat'=>$atelierChat->history($id,$kind,$user)],$kind==='eogi'?'Analyse systémique EOGI':'Préparer un feed-back');
        break;

    // ------------------------------------------------------------------ Situations
    case 'list':
        render('situations_list', ['items' => $situations->all($user)], 'Mes situations');
        break;

    case 'new':
        render('situation_form', ['s' => ['type_entretien' => 'objectifs', 'statut' => 'brouillon']], 'Nouvelle situation');
        break;

    case 'edit':
        $s = $situations->find($id, $user) ?? not_found();
        render('situation_form', ['s' => $s, 'preparationEogi'=>$ateliers->find($id,'eogi',$user)], 'Modifier la situation');
        break;

    case 'save':
        $requirePost();
        $data = $_POST;
        foreach (SituationRepo::FIELDS as $field) { if (isset($data[$field]) && mb_strlen((string)$data[$field]) > 12000) { http_response_code(422); exit('Un champ dépasse la longueur autorisée.'); } }
        $data['type_entretien'] = TypeEntretien::fromValue($data['type_entretien'] ?? null)->value;
        $data['statut'] = in_array($data['statut'] ?? '', ['brouillon', 'prepare', 'realise'], true) ? $data['statut'] : 'brouillon';
        if (trim((string) ($data['titre'] ?? '')) === '') {
            flash('L\'intitulé est obligatoire.', 'error');
            render('situation_form', ['s' => $data + ['id' => $id ?: null]], 'Situation');
            break;
        }
        if ($id && !$situations->find($id, $user)) {
            not_found();
        }
        try{$data['cdc_role']=\App\Reference\RoleCatalog::clean($data['cdc_role']??null);}catch(\InvalidArgumentException $e){http_response_code(422);flash($e->getMessage(),'error');$data['cdc_role']=null;render('situation_form',['s'=>$data+['id'=>$id?:null]],'Situation');break;}
        try {
            $pdo->beginTransaction();
            if($id && (!empty($data['prepa_eogi'])||!empty($data['prepa_trame']))) {
                $current=$situations->find($id,$user) ?? not_found();
                if(!hash_equals(\App\Atelier\Grille::contextHash($current),(string)($data['prepa_base']??'')))throw new \RuntimeException('La situation a changé dans un autre onglet. Copiez votre préparation avant de recharger et rapprocher les textes.');
            }
            $newId = $situations->save($data, $user, $id ?: null);
            \App\Preparation\Controller::saveAdditions($pdo,$user,$newId,$data);
            $pdo->commit();
        }catch(\InvalidArgumentException|\RuntimeException $e){
            if($pdo->inTransaction())$pdo->rollBack();http_response_code(422);flash($e->getMessage(),'error');
            render('situation_form',['s'=>$data+['id'=>$id?:null], 'preparationEogi'=>$id?$ateliers->find($id,'eogi',$user):null],'Préparation à vérifier');break;
        }
        flash('Situation enregistrée. Les propositions que vous avez retenues ont été sauvegardées.', 'success');
        redirect('index.php?action=view&id=' . $newId);

    case 'view':
        $s = $situations->find($id, $user) ?? not_found();
        render('situation_view', [
            's'      => $s,
            'thread' => $messages->forSituation($id),
            'redaction'=>(new \App\Redaction\Repository($pdo))->find($id,'entretien',$user),
            'redactionSource'=>(new \App\Redaction\Repository($pdo))->source($id,'entretien',$user),
            'consts' => $constellations->forSituation($id, $user),
        ], $s['titre']);
        break;

    case 'generate':
    case 'ask':
        $requirePost();
        $s = $situations->find($id, $user) ?? not_found();
        set_time_limit((int) config('ai.timeout', 120) + 30);

        $question = trim((string) ($_POST['question'] ?? ''));
        if ($action === 'ask' && ($question === '' || mb_strlen($question)>6000)) {
            flash('Saisissez une question.', 'error');
            redirect('index.php?action=view&id=' . $id);
        }

        try {
            $type = TypeEntretien::fromValue($s['type_entretien']);
            $query = $action === 'generate'
                ? $prompts->searchQuery($s)
                : $question . ' ' . $type->label() . ' ' . ($s['objectif_manager'] ?? '');
            $chunks = (new \App\Reference\Sources($pdo))->search($s,$query, (int) config('rag.top_k', 6), $type->categories());
            [$sourcesBlock, $sourcesMeta] = $prompts->sources($chunks);

            $current = $action === 'generate'
                ? $prompts->preparationRequest($sourcesBlock)
                : $prompts->followUp($question, $sourcesBlock);
            $history = $prompts->history($messages->forSituation($id),$s['cdc_role']??null);
            $history[] = ['role' => 'user', 'content' => $current];

            // Constellation liée la plus récente : ajoutée comme éclairage
            $linked = $constellations->forSituation($id, $user);
            $constText = $linked ? $describer->describe($linked[0]['data']) : null;

            $ai = AiFactory::make();
            $answer = $ai->chat($prompts->system($s, $constText, $ateliers->context($id,$user)), $history);
            \App\Rag\SourceValidator::check($answer, $sourcesMeta);

            // On stocke la question « lisible » ; les extraits sont conservés en métadonnées
            if(\App\Atelier\Grille::contextHash($situations->find($id,$user)??[])!==\App\Atelier\Grille::contextHash($s))throw new AiException('La situation ou le rôle a changé pendant la réponse. Relancez la préparation.');
            $pdo->beginTransaction();
            $messages->add($id, 'user', $action === 'generate' ? 'Préparer l\'entretien' : $question,[],null,$s['cdc_role']??null);
            $messages->add($id, 'assistant', $answer, $sourcesMeta, $ai->name(),$s['cdc_role']??null);
            if ($action === 'generate' && $s['statut'] === 'brouillon') {
                $situations->setStatut($id, 'prepare', $user);
            }
            $pdo->commit();
        } catch (AiException $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash($e->getMessage(), 'error');
        }
        redirect('index.php?action=view&id=' . $id . '#fin');

    case 'reset':
        $requirePost();
        $situations->find($id, $user) ?? not_found();
        $messages->clear($id);
        flash('Échanges effacés.', 'success');
        redirect('index.php?action=view&id=' . $id);

    case 'delete':
        $requirePost();
        $situations->delete($id, $user);
        flash('Situation supprimée.', 'success');
        redirect('index.php');

    // ------------------------------------------------------------- Constellations
    case 'constellations':
        render('constellations_list', ['items' => $constellations->all($user)], 'Constellations');
        break;

    case 'constellation_new':
        $requirePost();
        $sid = (int) ($_POST['situation_id'] ?? 0);
        $sid = $sid && $situations->find($sid, $user) ? $sid : null;
        $titre = trim((string) ($_POST['titre'] ?? '')) ?: 'Constellation du ' . date('d.m.Y');
        $newId = $constellations->create($user, mb_substr($titre, 0, 200), $sid);
        redirect('index.php?action=constellation&id=' . $newId);

    case 'constellation':
        $c = $constellations->find($id, $user) ?? not_found();
        render('constellation_edit', [
            'c'          => $c,
            'situations' => $situations->all($user),
            'description'=> $describer->describe($c['data']),
        ], $c['titre']);
        break;

    case 'constellation_save':
        // Appelé en AJAX par l'éditeur : réponse JSON
        $requirePost();
        header('Content-Type: application/json; charset=utf-8');
        if (!$constellations->find($id, $user)) {
            http_response_code(404);
            exit(json_encode(['ok' => false, 'error' => 'Constellation introuvable.']));
        }
        try {
            $data = ConstellationData::sanitize((string) ($_POST['data'] ?? ''));
        } catch (\InvalidArgumentException $e) {
            http_response_code(422);
            exit(json_encode(['ok' => false, 'error' => $e->getMessage()]));
        }
        $sid = (int) ($_POST['situation_id'] ?? 0);
        $sid = $sid && $situations->find($sid, $user) ? $sid : null;
        $titre = mb_substr(trim((string) ($_POST['titre'] ?? '')), 0, 200) ?: 'Constellation';
        $question = trim((string) ($_POST['question'] ?? '')) ?: null;
        $constellations->save($id, $user, $titre, $question, $sid, $data);
        exit(json_encode(['ok' => true, 'saved_at' => date('H:i:s'), 'description' => $describer->describe($data)], JSON_UNESCAPED_UNICODE));

    case 'constellation_analyse':
        $requirePost();
        $c = $constellations->find($id, $user) ?? not_found();
        set_time_limit((int) config('ai.timeout', 120) + 30);
        $nbElements = array_sum(array_map(fn($i) => count($i['elements']), $c['data']['images']));
        if ($nbElements === 0) {
            flash('Placez au moins quelques éléments avant de demander une lecture.', 'error');
            redirect('index.php?action=constellation&id=' . $id);
        }
        try {
            $situation = $c['situation_id'] ? $situations->find((int) $c['situation_id'], $user) : null;
            $chunks = $retriever->search($prompts->constellationQuery($c), (int) config('rag.top_k', 6), ['constellation', 'conflit', 'ecoute']);
            [$sourcesBlock, $sourcesMeta] = $prompts->sources($chunks);
            $ai = AiFactory::make();
            $answer = $ai->chat(
                $prompts->constellationSystem($c, $situation, $describer->describe($c['data'])),
                [['role' => 'user', 'content' => $prompts->constellationRequest($sourcesBlock, count($c['data']['images']))]]
            );
            \App\Rag\SourceValidator::check($answer, $sourcesMeta);
            $constellations->saveAnalyse($id, $user, $answer, $sourcesMeta, $ai->name());
        } catch (AiException $e) {
            flash($e->getMessage(), 'error');
        }
        redirect('index.php?action=constellation&id=' . $id . '#analyse');

    case 'constellation_delete':
        $requirePost();
        $constellations->delete($id, $user);
        flash('Constellation supprimée.', 'success');
        redirect('index.php?action=constellations');

    // ------------------------------------------------------------- Base documentaire
    case 'docs':
        $requireAdmin();
        render('documents_list', ['docs' => $documents->all()], 'Base documentaire');
        break;

    case 'doc_new':
        $requireAdmin();
        render('document_form', ['d' => ['categorie' => 'autre']], 'Nouveau document');
        break;

    case 'doc_edit':
        $requireAdmin();
        $d = $documents->find($id) ?? not_found();
        render('document_form', ['d' => $d, 'chunks' => $documents->chunks($id)], 'Modifier le document');
        break;

    case 'doc_save':
        $requirePost();
        $requireAdmin();
        $d = [
            'titre'     => trim((string) ($_POST['titre'] ?? '')),
            'categorie' => Categorie::fromValue($_POST['categorie'] ?? null)->value,
            'source'    => (string) ($_POST['source'] ?? ''),
            'contenu'   => (string) ($_POST['contenu'] ?? ''),
        ];

        $file = $_FILES['fichier'] ?? null;
        if (mb_strlen($d['contenu']) > (int)config('upload.max_bytes',2000000) || mb_strlen($d['titre'])>255 || mb_strlen($d['source'])>255) { http_response_code(422); exit('Document ou métadonnées trop volumineux.'); }
        if ($file && !in_array($file['error'],[UPLOAD_ERR_OK,UPLOAD_ERR_NO_FILE],true)) { flash('Le transfert a échoué. Réessayez avec un fichier de moins de 2 Mo.','error'); render('document_form',['d'=>$d+['id'=>$id?:null]],'Document'); break; }
        if ($file && $file['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, config('upload.extensions', ['txt', 'md']), true)) {
                flash('Format non pris en charge (.txt ou .md).', 'error');
                render('document_form', ['d' => $d + ['id' => $id ?: null]], 'Document');
                break;
            }
            if ($file['size'] > (int) config('upload.max_bytes', 2_000_000)) {
                flash('Fichier trop volumineux.', 'error');
                render('document_form', ['d' => $d + ['id' => $id ?: null]], 'Document');
                break;
            }
            $raw = (string) file_get_contents($file['tmp_name']);
            if (!mb_check_encoding($raw, 'UTF-8')) {
                $raw = mb_convert_encoding($raw, 'UTF-8', 'Windows-1252');
            }
            [$meta, $body] = DocumentIndexer::parseFrontMatter($raw);
            $d['contenu'] = $body;
            $d['titre'] = $d['titre'] ?: ($meta['titre'] ?? pathinfo($file['name'], PATHINFO_FILENAME));
            if (isset($meta['categorie']) && ($_POST['categorie'] ?? 'autre') === 'autre') {
                $d['categorie'] = Categorie::fromValue($meta['categorie'])->value;
            }
            $d['source'] = $d['source'] ?: ($meta['source'] ?? $file['name']);
        }

        if ($d['titre'] === '' || trim($d['contenu']) === '') {
            flash('Titre et contenu (ou fichier) obligatoires.', 'error');
            render('document_form', ['d' => $d + ['id' => $id ?: null]], 'Document');
            break;
        }
        $docId = $documents->save($d, $user, $id ?: null);
        $n = $indexer->index($docId);
        flash("Document enregistré et indexé ({$n} fragments).", 'success');
        redirect('index.php?action=docs');

    case 'doc_toggle':
        $requirePost();
        $requireAdmin();
        $documents->toggle($id);
        redirect('index.php?action=docs');

    case 'doc_delete':
        $requirePost();
        $requireAdmin();
        $documents->delete($id);
        flash('Document supprimé.', 'success');
        redirect('index.php?action=docs');

    case 'doc_seed':
        $requirePost();
        $requireAdmin();
        $n = $indexer->importDirectory(APP_ROOT . '/docs_seed', $user);
        flash("{$n} documents de démarrage importés.", 'success');
        redirect('index.php?action=docs');

    case 'doc_reindex':
        $requirePost();
        $requireAdmin();
        $n = $indexer->reindexAll();
        flash("Base réindexée ({$n} fragments).", 'success');
        redirect('index.php?action=docs');

    case 'search':
        // Page de test du RAG : voir ce que la recherche remonte pour une requête
        $q = trim((string) ($_GET['q'] ?? ''));
        $cat = (string) ($_GET['type'] ?? '');
        try{$cdcRole=\App\Reference\RoleCatalog::clean($_GET['cdc_role']??null);}catch(\InvalidArgumentException $e){http_response_code(422);$cdcRole=null;flash($e->getMessage(),'error');}
        $corpus = (string)($_GET['corpus'] ?? 'metier');
        if (!in_array($corpus, ['metier','aide'], true)) { http_response_code(422); exit('Corpus documentaire inconnu.'); }
        $results = $q === '' ? [] : ($corpus === 'aide'
            ? $retriever->search($q, (int)config('rag.top_k',6), [], 'aide')
            : (new \App\Reference\Sources($pdo))->search(['cdc_role'=>$cdcRole],$q, (int) config('rag.top_k', 6), $cat !== '' ? TypeEntretien::fromValue($cat)->categories() : []));
        render('search', ['q' => $q, 'type' => $cat, 'results' => $results,'cdcRole'=>$cdcRole,'corpus'=>$corpus], 'Tester la recherche');
        break;

    default:
        not_found('Page inconnue.');
}
