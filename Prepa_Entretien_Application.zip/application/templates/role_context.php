<?php $selectedRole=\App\Reference\RoleCatalog::get($s['cdc_role']??null); ?>
<section class="card" aria-label="Cahier des charges de référence">
<p class="eyebrow">LE POSTE COMME POINT DE DÉPART</p><h2>Préparer selon le cahier des charges</h2>
<?php if($selectedRole): ?>
<p><strong><?= e($selectedRole['label']) ?></strong> · niveau <?= e($selectedRole['level']) ?> indiqué dans le document.</p>
<p class="hint"><?= e($selectedRole['file']) ?> · <?= e($selectedRole['version']) ?>. Confirmez que ce modèle correspond au poste et à l’affectation.</p>
<p>L’assistant utilisera les pages actives de ce CDC et les méthodes actives du corpus. Préparez vos faits observés, vos questions et les objectifs à discuter. Aucune note n’est attribuée automatiquement.</p>
<div class="btn-row"><a class="btn btn-small" href="index.php?action=role_reference&amp;file=<?= e($s['cdc_role']) ?>">Télécharger ce CDC</a><a class="btn btn-small" href="index.php?action=edit&amp;id=<?= (int)$s['id'] ?>">Changer le rôle</a></div>
<?php else: ?><p>Aucun CDC associé. Choisissez le rôle du collaborateur dans la situation pour adapter la préparation à ses missions et compétences.</p><a class="btn btn-small" href="index.php?action=edit&amp;id=<?= (int)$s['id'] ?>">Choisir le rôle</a><?php endif; ?>
<?php if(!isset($kind)): ?><form method="post" action="index.php?action=generate" data-wait class="no-print"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$s['id'] ?>"><button class="btn btn-primary">Préparer l’entretien selon <?= $selectedRole?'ce CDC':'les sources disponibles' ?></button></form><?php endif; ?>
<p class="hint">La distribution publique fournit deux CDC fictifs. Remplacez-les uniquement par des références que vous êtes autorisé à utiliser.</p>
</section>
