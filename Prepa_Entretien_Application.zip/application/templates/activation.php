<section class="card form activation-card">
 <span class="eyebrow">ACCÈS PERSONNEL</span><h1>Définir mon mot de passe</h1>
 <p>Ce lien permet d’activer votre compte ou de choisir un nouveau mot de passe. Votre administrateur vous transmet le lien personnel ; vous choisissez vous-même votre mot de passe.</p>
 <?php if($error): ?><p class="flash flash-error" role="alert" tabindex="-1" id="auth-error"><?= e($error) ?></p><?php endif; ?>
 <form method="post" action="index.php?action=activate">
  <?= csrf_field() ?>
  <label>Code personnel<input type="password" name="activation" id="activation" required autocomplete="off" spellcheck="false"></label>
  <label>Nouveau mot de passe (14 caractères minimum)<input type="password" name="password" autocomplete="new-password" minlength="14" maxlength="1024" required></label>
  <label>Confirmer le mot de passe<input type="password" name="confirmation" autocomplete="new-password" minlength="14" maxlength="1024" required></label>
  <label class="check"><input type="checkbox" name="exercise_only" value="1" required> J’utilise uniquement des données fictives ou d’exercice dans ce prototype privé.</label>
  <button class="btn btn-primary">Enregistrer mon mot de passe</button><a class="btn" href="index.php">Revenir à la connexion</a>
 </form>
 <p class="hint">Un lien d’activation est valable 48 heures ; un lien de réinitialisation est valable une heure. Chaque lien est à usage unique.</p>
</section>
<script>
const activation = new URLSearchParams(location.hash.slice(1)).get('activation');
if(activation){document.getElementById('activation').value=activation;history.replaceState(null,'',location.pathname+location.search);}
<?php if($error): ?>document.getElementById('auth-error').focus();<?php endif; ?>
</script>
