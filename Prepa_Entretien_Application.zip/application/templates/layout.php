<?php $current = $_GET['action'] ?? 'list'; ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e(($title ? $title . ' — ' : '') . config('app.name')) ?></title>
    <link rel="stylesheet" href="assets/app.css?v=4">
    <link rel="stylesheet" href="assets/design.css?v=7">
</head>
<body class="<?= !empty($_SESSION['user'])?'is-authenticated':'is-public' ?>">
<a class="skip-link" href="#main">Aller au contenu</a>
<header class="topbar">
    <a class="brand" href="index.php"><span class="brand-mark" aria-hidden="true"><svg viewBox="0 0 32 32" fill="none"><path d="M8 23V9h8a5 5 0 0 1 0 10H8m13-2 4 6M8 26h16"/></svg></span><span class="brand-name"><?= e(config('app.name')) ?><span class="brand-caption">Votre espace de réflexion</span></span></a>
    <?php if (!empty($_SESSION['user'])): ?>
    <details class="site-navigation" open><summary><svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><path d="M4 6h16M4 12h16M4 18h16"/></svg>Navigation<span class="menu-indicator" aria-hidden="true">+</span></summary><nav aria-label="Navigation principale">
        <a href="index.php" class="<?= in_array($current, ['list', 'new', 'edit', 'view'], true) ? 'active' : '' ?>">Mes situations</a>
        <a href="index.php?action=constellations" class="<?= str_starts_with($current, 'constellation') ? 'active' : '' ?>">Constellations</a>
        <a href="index.php?action=ateliers" class="<?= str_starts_with($current, 'atelier') ? 'active' : '' ?>">Analyse et feed-back</a>
        <a href="index.php?action=fiches" class="<?= str_starts_with($current, 'fiche') ? 'active' : '' ?>">Fiches pratiques</a>
        <?php if(is_admin()): ?><a href="index.php?action=docs" class="<?= str_starts_with($current, 'doc') ? 'active' : '' ?>">Base documentaire</a><?php endif; ?>
        <a href="index.php?action=search" class="<?= $current === 'search' ? 'active' : '' ?>">Tester le RAG</a>
        <a href="index.php?action=guide" class="<?= $current === 'guide' ? 'active' : '' ?>">Guide d’utilisation</a>
        <?php if (is_admin()): ?><a href="index.php?action=accounts" class="<?= str_starts_with($current, 'account') ? 'active' : '' ?>">Comptes</a><?php endif; ?>
    </nav></details>
    <form method="post" action="index.php?action=logout" class="logout"><?= csrf_field() ?><button class="btn btn-small" title="Se déconnecter de l’espace privé">Déconnexion</button></form>
    <?php endif; ?>
</header>

<script>
const siteNavigation=document.querySelector('.site-navigation');
if(siteNavigation){const phoneNavigation=matchMedia('(max-width:760px)');const adaptNavigation=()=>{siteNavigation.open=!phoneNavigation.matches;};adaptNavigation();phoneNavigation.addEventListener('change',adaptNavigation);siteNavigation.addEventListener('keydown',event=>{if(event.key==='Escape'&&phoneNavigation.matches){siteNavigation.open=false;siteNavigation.querySelector('summary').focus();}});}
</script>
<main class="container" id="main">
    <?php foreach (flashes() as $f): ?>
        <div role="status" class="flash flash-<?= e($f['type']) ?>"><?= e($f['msg']) ?></div>
    <?php endforeach; ?>
    <?= $content ?>
</main>

<footer class="footer">
    Prototype privé · Données fictives ou d’exercice uniquement. L’IA propose, vous décidez.
</footer>
<script>
document.querySelectorAll('.topbar nav a.active').forEach(link=>link.setAttribute('aria-current','page'));
document.querySelectorAll('form[data-wait]').forEach(f => f.addEventListener('submit', () => {
    Array.from(f.elements).filter(el=>el.tagName==='BUTTON').forEach(b=>b.disabled=true);
    const w = document.getElementById('wait'); if (w) w.hidden = false;
}));
document.querySelectorAll('[data-confirm]').forEach(el => el.addEventListener('submit', ev => {
    if (!confirm(el.dataset.confirm)) ev.preventDefault();
}));
</script>
</body>
</html>
