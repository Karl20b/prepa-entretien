<div class="card empty">
    <h1>Oups</h1>
    <p><?= e($message) ?></p>
    <a class="btn" href="index.php">Retour</a>
</div>
