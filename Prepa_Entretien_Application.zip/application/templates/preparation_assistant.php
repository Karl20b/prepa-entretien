<?php
$preparationEogi=$preparationEogi??null;
$initialEogi=['data'=>$preparationEogi['data']??[], 'revision'=>(int)($preparationEogi['revision']??0)];
$eogiLabels=[];foreach(\App\Atelier\Grille::fields('eogi') as $key=>$pair)$eogiLabels[$key]=$pair[0];
?>
<section id="preparation-assistant" class="preparation-panel" aria-labelledby="preparation-title">
 <p class="eyebrow">VOTRE PRÉPARATION · QUATRE ÉTAPES À VOTRE RYTHME</p>
 <h2 id="preparation-title">Clarifier, explorer, préparer</h2>
 <p>Partez de vos notes ou de votre dictée relue. Choisissez l’aide utile, puis échangez avec l’assistant. Ses propositions restent à vérifier et à adapter.</p>
 <p class="hint">Le résumé reprend vos propos sans ajouter d’informations documentaires. L’exploration EOGI et la trame utilisent les méthodes et le CDC choisi lorsqu’ils sont disponibles. Aucun champ n’est modifié automatiquement.</p>
 <div class="preparation-steps" role="group" aria-label="Choisir une étape de préparation">
  <button type="button" class="btn" data-preparation-mode="resume"><span>1</span> Résumer mes propos</button>
  <button type="button" class="btn" data-preparation-mode="preciser"><span>2</span> M’aider à préciser</button>
  <button type="button" class="btn" data-preparation-mode="eogi"><span>3</span> Explorer avec EOGI</button>
  <button type="button" class="btn" data-preparation-mode="trame"><span>4</span> Proposer une trame</button>
 </div>
 <p id="preparation-status" role="status" aria-live="polite" tabindex="-1">Vous gardez la main sur les faits et les formulations retenues.</p>
 <details id="preparation-history" hidden><summary>Voir les échanges de cette préparation</summary><div id="preparation-history-items"></div></details>
 <div id="preparation-result" hidden>
  <h3 id="preparation-result-title">Proposition à relire</h3>
  <div id="preparation-answer" class="preparation-answer"></div>
  <div id="preparation-summary-review" class="preparation-choice" hidden>
   <label for="preparation-summary-preview">Résumé proposé · modifiable avant validation</label>
   <textarea id="preparation-summary-preview" rows="8" maxlength="4000" aria-describedby="preparation-summary-help"></textarea>
   <p id="preparation-summary-help">Corrigez ce résumé directement ici. Votre validation reprendra le texte corrigé dans le champ choisi ci-dessous.</p>
   <label for="preparation-summary-target">Reprendre le résumé dans</label>
   <select id="preparation-summary-target">
    <option value="contexte">Contexte</option>
    <option value="faits">Faits observés</option>
    <option value="objectif_manager">Ce que vous souhaitez obtenir</option>
    <option value="enjeux">Enjeux perçus</option>
   </select>
   <label id="preparation-summary-replace-label" class="preparation-check" hidden><input type="checkbox" id="preparation-summary-replace"> Je confirme le remplacement du texte existant dans ce champ.</label>
   <button type="button" class="btn btn-primary" id="preparation-apply-summary">Valider ce résumé corrigé</button>
   <p>Après validation, cliquez sur Enregistrer pour conserver votre modification.</p>
  </div>
  <div id="preparation-questions"></div>
  <div id="preparation-sources"></div>
  <div id="preparation-review" hidden>
   <h3>Choisir les textes à reprendre</h3>
   <p>Corrigez les propositions. Cochez les champs souhaités et confirmez séparément tout remplacement d’un texte existant.</p>
   <div id="preparation-choices"></div>
   <button type="button" id="preparation-apply" class="btn btn-primary">Valider les textes sélectionnés</button>
  </div>
  <div id="preparation-trame-review" hidden>
   <label for="preparation-trame-preview">Trame à adapter avant validation</label>
   <textarea id="preparation-trame-preview" rows="12" maxlength="14000"></textarea>
   <button type="button" class="btn btn-primary" id="preparation-retain-trame">Retenir cette trame</button>
  </div>
 </div>
 <div class="preparation-dialogue">
  <label for="preparation-question">Votre réponse ou votre demande de précision</label>
  <textarea id="preparation-question" rows="3" maxlength="4000" placeholder="Ex. Le retard concernait deux dossiers mardi. Je souhaite comprendre ce qui a freiné leur traitement."></textarea>
  <button type="button" class="btn btn-primary" id="preparation-send">Échanger avec l’assistant</button>
  <p class="hint">Choisissez une étape pour commencer. Une demande est envoyée uniquement à votre clic, avec les champs actuels et les échanges de clarification de cette discussion. Maximum 30 demandes par heure.</p>
 </div>
 <input type="hidden" id="preparation-eogi-original" value="<?= e(json_encode($initialEogi,JSON_UNESCAPED_UNICODE)) ?>">
 <input type="hidden" id="preparation-eogi-labels" value="<?= e(json_encode($eogiLabels,JSON_UNESCAPED_UNICODE)) ?>">
 <input type="hidden" id="preparation-eogi-payload" name="prepa_eogi" value="<?= e($s['prepa_eogi']??'') ?>">
 <input type="hidden" name="prepa_base" value="<?= e($s['prepa_base']??\App\Atelier\Grille::contextHash($s)) ?>">
 <input type="hidden" name="prepa_trame_token" id="preparation-trame-token" value="<?= e($s['prepa_trame_token']??'') ?>">
 <div id="preparation-eogi-staged" class="preparation-retained" <?= empty($s['prepa_eogi'])?'hidden':'' ?>>
  <p><strong>Reprise EOGI retenue.</strong> Les champs sélectionnés seront enregistrés dans votre grille avec la situation.</p>
  <button type="button" class="btn" id="preparation-clear-eogi">Retirer la reprise EOGI</button>
 </div>
 <div id="preparation-trame-staged" class="preparation-retained" <?= empty($s['prepa_trame'])?'hidden':'' ?>>
  <label for="preparation-trame-retained">Trame retenue · encore modifiable</label>
  <textarea name="prepa_trame" id="preparation-trame-retained" rows="10" maxlength="16000"><?= e($s['prepa_trame']??'') ?></textarea>
  <p class="hint">Elle sera conservée dans les échanges de la situation comme trame relue et retenue par le cadre.</p>
  <button type="button" class="btn" id="preparation-clear-trame">Retirer cette trame</button>
 </div>
 <p><strong>Après validation, cliquez sur Enregistrer</strong> pour sauvegarder la situation et les reprises retenues.</p>
 <noscript><p>Activez JavaScript pour cet accompagnement. La saisie manuelle et l’assistant de la situation enregistrée restent disponibles.</p></noscript>
</section>
