<?php use App\Domain\TypeEntretien;
use App\View\Markdown;
$sid = (int) $s['id'];
$block = function (string $label, ?string $text): void {
    if (trim((string) $text) === '') return;
    echo '<h3>' . e($label) . '</h3><p>' . nl2br(e($text)) . '</p>';
}; ?>
<div class="page-head no-print">
    <h1><?= e($s['titre']) ?></h1>
    <div class="btn-row">
        <a class="btn" href="index.php?action=edit&id=<?= $sid ?>">Modifier la situation</a><a class="btn btn-primary" href="index.php?action=redaction&id=<?= $sid ?>&amp;kind=entretien">Modifier et exporter la préparation</a>
        <a class="btn btn-primary" href="index.php?action=edit&id=<?= $sid ?>#preparation-assistant">Accompagnement guidé</a>
        <button class="btn" onclick="window.print()">Imprimer</button>
    </div>
</div>

<?php require __DIR__.'/role_context.php'; ?>
<div class="layout-2">
    <aside class="card situation">
        <h2>Situation</h2>
        <dl>
            <dt>Type</dt><dd><?= e(TypeEntretien::fromValue($s['type_entretien'])->label()) ?></dd>
            <dt>Collaborateur</dt><dd><?= e($s['collaborateur_ref'] ?: '—') ?></dd>
            <dt>Fonction</dt><dd><?= e($s['fonction'] ?: '—') ?></dd>
            <dt>Date prévue</dt><dd><?= e(format_date($s['date_entretien'])) ?></dd>
        </dl>
        <?php $block('Contexte', $s['contexte']);
        $block('Faits observés', $s['faits']);
        $block('Objectif du manager', $s['objectif_manager']);
        $block('Enjeux', $s['enjeux']); ?>

        <h3>Préparer avec une grille</h3>
        <p><a class="btn btn-small" href="index.php?action=atelier&id=<?= $sid ?>&kind=eogi">Analyse systémique EOGI</a></p>
        <p><a class="btn btn-small" href="index.php?action=atelier&id=<?= $sid ?>&kind=feedback">Préparer un feed-back</a></p>
        <p class="hint small-hint">Vos grilles enregistrées éclairent les prochaines réponses de l’assistant. Elles restent personnelles.</p>
        <h3>Constellations</h3>
        <?php foreach ($consts as $k): ?>
            <p><a href="index.php?action=constellation&id=<?= (int) $k['id'] ?>"><?= e($k['titre']) ?></a></p>
        <?php endforeach; ?>
        <?php if ($consts): ?><p class="hint small-hint">La plus récente est transmise à l'assistant comme éclairage.</p><?php endif; ?>
        <form method="post" action="index.php?action=constellation_new" class="no-print">
            <?= csrf_field() ?><input type="hidden" name="situation_id" value="<?= $sid ?>">
            <input type="hidden" name="titre" value="Équipe — <?= e($s['titre']) ?>">
            <button class="btn btn-small">+ Dessiner une constellation</button>
        </form>

        <div class="danger-zone no-print">
            <form method="post" action="index.php?action=reset" data-confirm="Effacer tous les échanges avec l'assistant ?">
                <?= csrf_field() ?><input type="hidden" name="id" value="<?= $sid ?>">
                <button class="btn btn-small">Effacer les échanges</button>
            </form>
            <form method="post" action="index.php?action=delete" data-confirm="Supprimer définitivement cette situation ?">
                <?= csrf_field() ?><input type="hidden" name="id" value="<?= $sid ?>">
                <button class="btn btn-small btn-danger">Supprimer</button>
            </form>
        </div>
    </aside>

    <section class="assistant">
        <?php if (!$thread): ?>
            <div class="card empty no-print">
                <p>L'assistant va analyser la situation, rechercher les fiches pertinentes (GROW, SMART, écoute active…) et proposer une préparation complète.</p>
                <form method="post" action="index.php?action=generate" data-wait>
                    <?= csrf_field() ?><input type="hidden" name="id" value="<?= $sid ?>">
                    <button class="btn btn-primary">Préparer l'entretien avec l'IA</button>
                </form>
            </div>
        <?php endif; ?>

        <?php $currentAnswer=null;foreach($thread as $entry)if((int)$entry['id']===(int)($redactionSource['message_id']??0))$currentAnswer=$entry;
        if($redaction || $currentAnswer): ?><article class="msg msg-ai card"><p class="eyebrow"><?= $redaction?'VOTRE VERSION DE TRAVAIL':'PROPOSITION ACTUELLE · À RELIRE' ?></p>
        <?php if($redaction && \App\Redaction\Repository::stale($redaction,$redactionSource)): ?><p class="flash">La situation ou la proposition a évolué : réexaminez votre version avant l’entretien.</p><?php endif; ?>
        <?= Markdown::render($redaction['contenu']??$currentAnswer['contenu']) ?>
        <?php $visibleSources=$redaction['sources']??$currentAnswer['sources'];if($visibleSources): ?><details class="sources"><summary>Sources à vérifier</summary><?php foreach($visibleSources as $src): ?><p><strong>[<?= e($src['ref']??'') ?>] <?= e($src['titre']??'') ?></strong> <?= e($src['source']??'') ?></p><pre><?= e($src['extrait']??'') ?></pre><?php endforeach; ?></details><?php endif; ?>
        <p class="no-print"><a class="btn btn-primary" href="index.php?action=redaction&amp;id=<?= $sid ?>&amp;kind=entretien">Modifier le texte et exporter Word / PDF</a></p></article><?php endif; ?>
        <?php if($thread): ?><details class="card no-print"><summary>Historique des générations et échanges (<?= count($thread) ?> messages)</summary><p>Les réponses d’origine restent disponibles ici. Une nouvelle génération ne remplace pas votre version de travail.</p>
        <?php foreach ($thread as $m): ?>
            <?php if ($m['role'] === 'user'): ?>
                <div class="msg msg-user no-print"><?= nl2br(e($m['contenu'])) ?></div>
            <?php else: ?>
                <article class="msg msg-ai card">
                    <?php if(($m['cdc_role']??null)!==($s['cdc_role']??null)): ?><p class="hint">Réponse préparée avec un autre rôle ou sans CDC. Relancez la préparation pour le rôle actuel.</p><?php endif; ?>
                    <?= Markdown::render($m['contenu']) ?>
                    <?php if ($m['sources']): ?>
                        <div class="sources">
                            <strong>Sources :</strong>
                            <?php foreach ($m['sources'] as $src): ?>
                                <span class="src"><span class="src-ref"><?= e($src['ref']) ?></span> <?= e($src['titre']) ?><details><summary>Voir l’extrait</summary><p><?= e($src['source'] ?? '') ?></p><pre><?= e($src['extrait'] ?? '') ?></pre></details></span>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <div class="meta"><?= e(format_date($m['created_at'], 'd.m.Y H:i')) ?> · <?= e($m['fournisseur'] ?? '') ?></div>
                </article>
            <?php endif; ?>
        <?php endforeach; ?>

</details><?php endif; ?>
        <?php if ($thread): ?>
            <form method="post" action="index.php?action=ask" class="card form ask no-print" data-wait id="fin">
                <?= csrf_field() ?><input type="hidden" name="id" value="<?= $sid ?>">
                <label>Affiner avec l'assistant
                    <textarea name="question" rows="3" required placeholder="Ex. Et s'il conteste les faits ? Propose une version plus courte de la trame. Joue le collaborateur pour que je m'entraîne."></textarea>
                </label>
                <div class="actions">
                    <button class="btn btn-primary">Envoyer</button>
                </div>
            </form>
        <?php endif; ?>
        <p id="wait" class="wait" hidden>L'assistant prépare sa réponse… (jusqu'à une minute)</p>
    </section>
</div>
