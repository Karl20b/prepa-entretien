<div class="page-head">
    <h1>Constellations systémiques</h1>
    <form method="post" action="index.php?action=constellation_new">
        <?= csrf_field() ?>
        <button class="btn btn-primary">+ Nouvelle constellation</button>
    </form>
</div>

<div class="card intro">
    <p>Représentez spatialement les membres, les rôles et les enjeux d'une équipe : leur place, leur distance, la direction de leur regard et leurs liens.
       L'image rend visibles des dynamiques difficiles à formuler. Créez plusieurs images (actuelle, souhaitée…) pour explorer des mouvements,
       puis demandez une lecture à l'assistant, appuyée sur la base documentaire.</p>
</div>

<?php if ($items): ?>
    <table class="table">
        <thead><tr><th>Titre</th><th>Situation liée</th><th>Images</th><th>Éléments</th><th>Lecture IA</th><th>Modifiée</th></tr></thead>
        <tbody>
        <?php foreach ($items as $c): ?>
            <tr>
                <td><a href="index.php?action=constellation&id=<?= (int) $c['id'] ?>"><?= e($c['titre']) ?></a></td>
                <td><?= $c['situation_id'] ? '<a href="index.php?action=view&id=' . (int) $c['situation_id'] . '">' . e($c['situation_titre']) . '</a>' : '—' ?></td>
                <td><?= (int) $c['nb_images'] ?></td>
                <td><?= (int) $c['nb_elements'] ?></td>
                <td><?= $c['analyse_at'] ? e(format_date($c['analyse_at'])) : '—' ?></td>
                <td><?= e(format_date($c['updated_at'], 'd.m.Y H:i')) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
