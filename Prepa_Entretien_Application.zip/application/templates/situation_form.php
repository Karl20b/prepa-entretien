<?php use App\Domain\TypeEntretien;
$v = fn(string $k) => e($s[$k] ?? ''); ?>
<h1><?= empty($s['id']) ? 'Nouvelle situation' : 'Modifier la situation' ?></h1>

<form method="post" action="index.php?action=save" class="card form">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int) ($s['id'] ?? 0) ?>">

    <div class="grid-2">
        <label>Intitulé *
            <input name="titre" required maxlength="200" value="<?= $v('titre') ?>" placeholder="Ex. Objectifs annuels — gestionnaire logistique">
        </label>
        <label>Type d'entretien
            <select name="type_entretien">
                <?php foreach (TypeEntretien::cases() as $t): ?>
                    <option value="<?= e($t->value) ?>" <?= ($s['type_entretien'] ?? '') === $t->value ? 'selected' : '' ?>><?= e($t->label()) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Collaborateur (pseudonyme ou initiales)
            <input name="collaborateur_ref" maxlength="100" value="<?= $v('collaborateur_ref') ?>" placeholder="Ex. Collab. A">
            <small>Ne saisissez pas de nom complet.</small>
        </label>
        <label>Rôle du collaborateur · CDC de référence
            <select name="cdc_role" aria-describedby="cdc-help"><option value="">— Sans CDC associé / autre rôle —</option>
            <?php foreach(\App\Reference\RoleCatalog::all() as $key=>$role): ?><option value="<?= e($key) ?>" <?= ($s['cdc_role']??'')===$key?'selected':'' ?>><?= e($role['label']) ?></option><?php endforeach; ?>
            </select><small id="cdc-help">Choisissez le poste à préparer. Les deux références fournies sont fictives. Pour un autre rôle, aucun CDC n’est déduit. Vérifiez que le modèle correspond au poste actuel.</small>
        </label>
        <label>Fonction / affectation (précision libre)
            <input name="fonction" maxlength="150" value="<?= $v('fonction') ?>">
        </label>
        <label>Date prévue de l'entretien
            <input type="date" name="date_entretien" value="<?= $v('date_entretien') ?>">
        </label>
        <label>Statut
            <select name="statut">
                <?php foreach (['brouillon' => 'Brouillon', 'prepare' => 'Préparé', 'realise' => 'Réalisé'] as $k => $l): ?>
                    <option value="<?= $k ?>" <?= ($s['statut'] ?? '') === $k ? 'selected' : '' ?>><?= $l ?></option>
                <?php endforeach; ?>
            </select>
        </label>
    </div>

    <label>Contexte
        <textarea id="champ-contexte" name="contexte" rows="4" placeholder="Service, ancienneté dans le poste, historique utile, organisation…"><?= $v('contexte') ?></textarea>
    </label>
    <button type="button" class="btn dictee-trigger" data-dictee="contexte" aria-controls="dictee">Dicter · Contexte</button>
    <label>Faits observés
        <textarea id="champ-faits" name="faits" rows="5" placeholder="Faits concrets et datés, sans jugement : ce qui a été vu, entendu, mesuré."><?= $v('faits') ?></textarea>
    </label>
    <button type="button" class="btn dictee-trigger" data-dictee="faits" aria-controls="dictee">Dicter · Faits observés</button>
    <label>Ce que vous souhaitez obtenir de l'entretien
        <textarea id="champ-objectif_manager" name="objectif_manager" rows="3" placeholder="Ex. Que le collaborateur formule un objectif d'amélioration et un plan d'action."><?= $v('objectif_manager') ?></textarea>
    </label>
    <button type="button" class="btn dictee-trigger" data-dictee="objectif_manager" aria-controls="dictee">Dicter · Objectif de l’entretien</button>
    <label>Enjeux / points sensibles
        <textarea id="champ-enjeux" name="enjeux" rows="3" placeholder="Tensions, risques, attentes du collaborateur, contraintes du service…"><?= $v('enjeux') ?></textarea>
    </label>
    <button type="button" class="btn dictee-trigger" data-dictee="enjeux" aria-controls="dictee">Dicter · Enjeux perçus</button>

    <p id="dictee-unavailable" class="hint" hidden>La dictée nécessite HTTPS, un microphone et un navigateur récent. La saisie au clavier reste disponible.</p>
    <section id="dictee" class="dictee-panel" aria-labelledby="dictee-title" hidden>
        <p class="eyebrow">DICTÉE FACULTATIVE · FRANÇAIS</p>
        <h2 id="dictee-title">Dicter : <span id="dictee-target"></span></h2>
        <p>Décrivez une situation fictive ou d’exercice, avec des pseudonymes. Cinq minutes maximum par prise. L’audio est envoyé au service de transcription seulement au clic sur « Transcrire ». La transcription peut comporter des erreurs : relisez les faits, les dates et les négations.</p>
        <div class="actions">
            <button type="button" class="btn btn-primary" id="dictee-start">Démarrer le microphone</button>
            <button type="button" class="btn" id="dictee-pause" disabled>Pause</button>
            <button type="button" class="btn" id="dictee-resume" disabled>Reprendre</button>
            <button type="button" class="btn" id="dictee-stop" disabled>Terminer la prise</button>
        </div>
        <p id="dictee-status" role="status" aria-live="polite" tabindex="-1"></p>
        <button type="button" class="btn btn-primary" id="dictee-send" disabled>Transcrire l’audio</button>
        <label for="dictee-preview">Transcription à relire et à corriger</label>
        <textarea id="dictee-preview" rows="5" placeholder="La transcription apparaîtra ici. Vous pourrez la modifier avant de l’ajouter."></textarea>
        <div class="actions">
            <button type="button" class="btn btn-primary" id="dictee-apply" disabled>Ajouter au champ choisi</button>
            <button type="button" class="btn" id="dictee-summary" disabled>Résumer mes propos avec l’assistant</button>
            <button type="button" class="btn" id="dictee-discard">Effacer cette prise</button>
        </div>
        <p class="hint">Le texte déjà saisi est conservé. Après ajout, cliquez sur Enregistrer pour sauvegarder la situation. Aucun audio n’est archivé par l’application ; la transcription n’alimente pas le RAG.</p>
    </section>

    <?php require __DIR__.'/preparation_assistant.php'; ?>
    <div class="actions">
        <button class="btn btn-primary">Enregistrer</button>
        <a class="btn" href="<?= empty($s['id']) ? 'index.php' : 'index.php?action=view&id=' . (int) $s['id'] ?>">Annuler</a>
    </div>
</form>

<link rel="stylesheet" href="assets/dictee.css?v=11">
<script src="assets/dictee.js?v=12" defer></script>

<link rel="stylesheet" href="assets/preparation.css?v=12">
<script src="assets/preparation.js?v=12.2" defer></script>
