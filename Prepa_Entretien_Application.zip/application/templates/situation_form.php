<?php use App\Domain\TypeEntretien;
$v = fn(string $k) => e($s[$k] ?? ''); ?>
<h1><?= empty($s['id']) ? 'Nouvelle situation' : 'Modifier la situation' ?></h1>

<form method="post" action="index.php?action=save" class="card form">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int) ($s['id'] ?? 0) ?>">

    <div class="grid-2">
        <label>Intitulé *
            <input name="titre" required maxlength="200" value="<?= $v('titre') ?>" placeholder="Ex. Objectifs annuels — gestionnaire logistique">
        </label>
        <label>Type d'entretien
            <select name="type_entretien">
                <?php foreach (TypeEntretien::cases() as $t): ?>
                    <option value="<?= e($t->value) ?>" <?= ($s['type_entretien'] ?? '') === $t->value ? 'selected' : '' ?>><?= e($t->label()) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Collaborateur (pseudonyme ou initiales)
            <input name="collaborateur_ref" maxlength="100" value="<?= $v('collaborateur_ref') ?>" placeholder="Ex. Collab. A">
            <small>Ne saisissez pas de nom complet.</small>
        </label>
        <label>Fonction / rôle
            <input name="fonction" maxlength="150" value="<?= $v('fonction') ?>">
        </label>
        <label>Date prévue de l'entretien
            <input type="date" name="date_entretien" value="<?= $v('date_entretien') ?>">
        </label>
        <label>Statut
            <select name="statut">
                <?php foreach (['brouillon' => 'Brouillon', 'prepare' => 'Préparé', 'realise' => 'Réalisé'] as $k => $l): ?>
                    <option value="<?= $k ?>" <?= ($s['statut'] ?? '') === $k ? 'selected' : '' ?>><?= $l ?></option>
                <?php endforeach; ?>
            </select>
        </label>
    </div>

    <label>Contexte
        <textarea name="contexte" rows="4" placeholder="Service, ancienneté dans le poste, historique utile, organisation…"><?= $v('contexte') ?></textarea>
    </label>
    <label>Faits observés
        <textarea name="faits" rows="5" placeholder="Faits concrets et datés, sans jugement : ce qui a été vu, entendu, mesuré."><?= $v('faits') ?></textarea>
    </label>
    <label>Ce que vous souhaitez obtenir de l'entretien
        <textarea name="objectif_manager" rows="3" placeholder="Ex. Que le collaborateur formule un objectif d'amélioration et un plan d'action."><?= $v('objectif_manager') ?></textarea>
    </label>
    <label>Enjeux / points sensibles
        <textarea name="enjeux" rows="3" placeholder="Tensions, risques, attentes du collaborateur, contraintes du service…"><?= $v('enjeux') ?></textarea>
    </label>

    <div class="actions">
        <button class="btn btn-primary">Enregistrer</button>
        <a class="btn" href="<?= empty($s['id']) ? 'index.php' : 'index.php?action=view&id=' . (int) $s['id'] ?>">Annuler</a>
    </div>
</form>
