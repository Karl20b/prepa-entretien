<?php use App\Constellation\ConstellationData;
use App\View\Markdown;
$cid = (int) $c['id'];
$boot = [
    'id'       => $cid,
    'csrf'     => csrf_token(),
    'data'     => $c['data'],
    'types'    => ConstellationData::TYPES,
    'liens'    => ConstellationData::LIENS,
    'saveUrl'  => 'index.php?action=constellation_save',
]; ?>
<link rel="stylesheet" href="assets/constellation.css?v=16">
<div class="page-head no-print">
    <h1>Constellation systémique</h1>
    <div class="btn-row">
        <span id="save-status" class="hint">Enregistré</span>
        <button type="button" class="btn btn-primary" id="btn-save">Enregistrer</button>
    </div>
</div>

<div class="card form const-meta">
    <div class="grid-3">
        <label>Titre
            <input id="f-titre" maxlength="200" value="<?= e($c['titre']) ?>">
        </label>
        <label>Situation liée
            <select id="f-situation">
                <option value="">— Aucune —</option>
                <?php foreach ($situations as $s): ?>
                    <option value="<?= (int) $s['id'] ?>" <?= (int) $c['situation_id'] === (int) $s['id'] ? 'selected' : '' ?>><?= e($s['titre']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Question de travail
            <input id="f-question" maxlength="500" value="<?= e($c['question'] ?? '') ?>" placeholder="Ex. Pourquoi les décisions de l'équipe ne sont-elles pas appliquées ?">
        </label>
    </div>
</div>

<div class="const-toolbar no-print">
    <div class="btn-row">
        <span class="tb-label">Ajouter :</span>
        <?php foreach (ConstellationData::TYPES as $k => $label): ?>
            <button type="button" class="btn btn-small add-el" data-type="<?= e($k) ?>"><span class="sw sw-<?= e($k) ?>"></span><?= e($label) ?></button>
        <?php endforeach; ?>
    </div>
    <div class="btn-row">
        <button type="button" class="btn btn-small" id="btn-circle">Entourer des formes</button>
        <button type="button" class="btn btn-small" id="btn-link">Relier deux éléments</button>
        <select id="link-kind" class="tb-select">
            <?php foreach (ConstellationData::LIENS as $k => $label): ?>
                <option value="<?= e($k) ?>"><?= e($label) ?></option>
            <?php endforeach; ?>
        </select>
        <label class="tb-check"><input type="checkbox" id="ghost"> Montrer l'image précédente</label>
        <button type="button" class="btn btn-small" id="btn-png">Exporter PNG</button>
        <button type="button" class="btn btn-small" id="btn-svg">Exporter SVG</button>
    </div>
</div>

<div class="const-tabs no-print" id="tabs"></div>

<div class="const-layout">
    <div class="board-wrap">
        <svg id="board" viewBox="0 0 1000 700" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Plateau de la constellation"></svg>
        <p class="hint board-help no-print">Glisser pour déplacer · poignée dorée ou touches ← → pour orienter le regard · Suppr pour effacer · double-clic sur le plateau pour ajouter une personne</p>
    </div>
    <aside class="card const-panel no-print" id="panel"></aside>
</div>

<div class="layout-2 const-bottom">
    <section class="card">
        <h2>Description transmise à l'IA</h2>
        <p class="hint">Générée automatiquement à partir du dessin (places, regards, distances, liens, évolutions).</p>
        <pre id="description" class="desc"><?= e($description) ?></pre>
    </section>
    <section class="card" id="analyse">
        <div class="page-head">
            <h2>Lecture proposée par l'assistant</h2>
            <form method="post" action="index.php?action=constellation_analyse" data-wait id="form-analyse" class="no-print">
                <?= csrf_field() ?><input type="hidden" name="id" value="<?= $cid ?>">
                <button class="btn btn-primary"><?= $c['analyse'] ? 'Relancer la lecture' : 'Demander une lecture' ?></button>
            </form>
        </div>
        <p id="wait" class="wait" hidden>L'assistant lit la constellation… (jusqu'à une minute)</p>
        <?php if ($c['analyse']): ?>
            <div class="msg-ai"><?= Markdown::render($c['analyse']) ?></div>
            <?php if ($c['analyse_sources']): ?>
                <div class="sources"><strong>Sources :</strong>
                    <?php foreach ($c['analyse_sources'] as $src): ?>
                        <span class="src"><span class="src-ref"><?= e($src['ref']) ?></span> <?= e($src['titre']) ?></span>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <div class="meta"><?= e(format_date($c['analyse_at'], 'd.m.Y H:i')) ?> · <?= e($c['analyse_fournisseur']) ?> · lecture en hypothèses, à discuter</div>
        <?php else: ?>
            <p class="hint">Aucune lecture pour l'instant. Placez les éléments, enregistrez, puis demandez une lecture.</p>
        <?php endif; ?>
    </section>
</div>

<form method="post" action="index.php?action=constellation_delete" data-confirm="Supprimer définitivement cette constellation ?" class="no-print">
    <?= csrf_field() ?><input type="hidden" name="id" value="<?= $cid ?>">
    <button class="btn btn-small btn-danger">Supprimer la constellation</button>
</form>

<script type="application/json" id="const-boot"><?= json_encode($boot, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?></script>
<script src="assets/constellation.js?v=16"></script>
