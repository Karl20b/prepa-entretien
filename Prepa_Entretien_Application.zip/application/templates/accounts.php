<div class="page-head"><div><span class="eyebrow">ADMINISTRATION</span><h1>Comptes et accès</h1></div><a class="btn" href="index.php?action=guide#comptes">Consulter le guide</a></div>
<p class="hint">Chaque personne dispose d’un compte personnel. Les administrateurs gèrent les accès et la documentation ; les situations des autres utilisateurs restent privées.</p>
<?php if($newLink): $mailAccount=array_values(array_filter($accounts,fn($a)=>$a['username']===$linkUser))[0]??[]; $mail=\App\Accounts\InvitationMail::compose($linkUser,$mailAccount['display_name']??'',$newLink,$linkType); ?>
<section class="card invitation-result" role="status">
 <h2><?= $linkType==='activate'?'Lien d’activation créé':'Lien de réinitialisation créé' ?> pour <?= e($linkUser) ?></h2>
 <p>À transmettre personnellement au titulaire. Valable <?= $linkType==='activate'?'48 heures':'une heure' ?>, à usage unique. Un nouveau lien remplace le précédent. Aucun courriel n’a été envoyé.</p>
 <label for="personal-link">Lien personnel</label><input id="personal-link" class="personal-link" type="text" readonly value="<?= e($newLink) ?>" autocomplete="off" spellcheck="false">
 <button type="button" class="btn" id="copy-link">Copier le lien</button><span id="copy-status" role="status"></span>
 <p class="hint">Ce lien n’est affiché que maintenant. Il n’est pas conservé en clair dans la base.</p>
 <div class="invitation-mail form">
  <h3><?= $linkType==='activate'?'Courriel d’invitation prêt à transmettre':'Courriel de réinitialisation prêt à transmettre' ?></h3>
  <p>Relisez et adaptez le message, puis copiez-le ou ouvrez-le dans votre messagerie. Vous gardez la main sur l’envoi.</p>
  <label for="mail-recipient">Adresse du destinataire <small>Facultatif · utilisée uniquement pour préparer le courriel, sans enregistrement dans l’application.</small></label><input id="mail-recipient" type="email" maxlength="254" autocomplete="off" placeholder="prenom.nom@exemple.ch">
  <label for="mail-subject">Objet</label><input id="mail-subject" type="text" maxlength="200" value="<?= e($mail['subject']) ?>" autocomplete="off">
  <label for="mail-body">Message modifiable</label><textarea id="mail-body" rows="17" spellcheck="true"><?= e($mail['body']) ?></textarea>
  <div class="btn-row"><button type="button" class="btn" id="copy-mail">Copier le message</button><a class="btn btn-primary" id="open-mail" href="<?= e('mailto:?subject='.rawurlencode($mail['subject']).'&body='.rawurlencode($mail['body'])) ?>">Préparer dans ma messagerie</a></div>
  <p id="mail-status" role="status" class="hint"></p><p class="hint">L’ouverture dépend de la messagerie configurée sur votre appareil. Si elle ne s’ouvre pas, copiez le message. Gardez ce lien personnel pour son titulaire.</p>
 </div>
</section>
<script>document.getElementById('copy-link').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(document.getElementById('personal-link').value);document.getElementById('copy-status').textContent='Lien copié.';}catch(e){document.getElementById('personal-link').select();document.getElementById('copy-status').textContent='Sélectionnez puis copiez le lien.';}});</script>
<script>
const recipient=document.getElementById('mail-recipient'), mailSubject=document.getElementById('mail-subject'), mailBody=document.getElementById('mail-body'), mailStatus=document.getElementById('mail-status'), openMail=document.getElementById('open-mail');
const updateMail=()=>{openMail.href='mailto:'+encodeURIComponent(recipient.value.trim())+'?subject='+encodeURIComponent(mailSubject.value)+'&body='+encodeURIComponent(mailBody.value);};
[recipient,mailSubject,mailBody].forEach(field=>field.addEventListener('input',updateMail));
openMail.addEventListener('click',event=>{if(!recipient.checkValidity()){event.preventDefault();recipient.reportValidity();return;}updateMail();mailStatus.textContent='Le message est préparé. Relisez-le dans votre messagerie avant de l’envoyer.';});
document.getElementById('copy-mail').addEventListener('click',async()=>{const text='Objet : '+mailSubject.value+'\n\n'+mailBody.value;try{await navigator.clipboard.writeText(text);mailStatus.textContent='Objet et message copiés. Collez-les dans votre courriel.';}catch(error){mailBody.focus();mailBody.select();mailStatus.textContent='Sélectionnez puis copiez le message. L’objet est indiqué au-dessus.';}});
</script>
<?php endif; ?>
<section class="card form"><h2>Créer un compte</h2>
 <form method="post" action="index.php?action=account_create">
 <?= csrf_field() ?>
 <div class="account-grid">
  <label for="new-username">Identifiant<input id="new-username" name="username" required pattern="[a-z0-9][a-z0-9._\-]{2,39}" minlength="3" maxlength="40" spellcheck="false" autocomplete="off" autocapitalize="none" aria-describedby="username-rules" title="3 à 40 caractères : commencer par une lettre minuscule sans accent ou un chiffre, puis utiliser a-z, 0-9, point, tiret ou trait de soulignement." placeholder="prenom.nom"><small id="username-rules">Unique · 3 à 40 caractères. Commencer par une lettre minuscule ou un chiffre. Puis : a–z, 0–9, point (.), tiret (-) ou trait de soulignement (_). Aucun espace, accent ou @. Exemple : prenom.nom.</small></label>
  <label>Nom affiché<input name="display_name" maxlength="100" autocomplete="off"></label>
  <label>Rôle<select name="role"><option value="user">Utilisateur</option><option value="admin">Administrateur</option></select></label>
 </div>
 <p class="hint">Utilisateur : ses situations et constellations, le guide et la recherche. Administrateur : mêmes droits, avec gestion de la base documentaire et des comptes.</p>
 <button class="btn btn-primary">Créer le compte et son lien d’activation</button>
 </form>
</section>
<h2>Comptes existants (<?= count($accounts) ?>)</h2>
<?php foreach($accounts as $a): ?>
<section class="card account-card">
 <div class="page-head"><h3><?= e($a['username']) ?><?= $a['username']===current_user()?' · votre compte':'' ?></h3><span class="badge"><?= $a['pending']?'En attente d’activation':($a['active']?'Actif':'Désactivé') ?></span></div>
 <form method="post" action="index.php?action=account_update" class="form">
  <?= csrf_field() ?><input type="hidden" name="username" value="<?= e($a['username']) ?>">
  <div class="account-grid">
   <label>Nom affiché<input name="display_name" maxlength="100" value="<?= e($a['display_name']) ?>" autocomplete="off"></label>
   <label>Rôle<select name="role"><option value="user" <?= $a['role']==='user'?'selected':'' ?>>Utilisateur</option><option value="admin" <?= $a['role']==='admin'?'selected':'' ?>>Administrateur</option></select></label>
   <label class="check account-active"><input type="checkbox" name="active" value="1" <?= $a['active']?'checked':'' ?> <?= $a['pending']?'disabled':'' ?>>Compte actif</label>
  </div>
  <button class="btn">Enregistrer les droits et le nom</button>
 </form>
 <div class="btn-row account-links">
 <?php if($a['pending']): ?>
  <form method="post" action="index.php?action=account_link" data-confirm="Émettre un nouveau lien rendra le précédent inutilisable. Continuer ?"><?= csrf_field() ?><input type="hidden" name="username" value="<?= e($a['username']) ?>"><input type="hidden" name="kind" value="activate"><button class="btn btn-small">Renouveler le lien d’activation</button></form>
 <?php elseif($a['active']): ?>
  <form method="post" action="index.php?action=account_link" data-confirm="Créer un lien personnel de réinitialisation du mot de passe ?"><?= csrf_field() ?><input type="hidden" name="username" value="<?= e($a['username']) ?>"><input type="hidden" name="kind" value="reset"><button class="btn btn-small">Créer un lien de réinitialisation</button></form>
 <?php endif; ?>
 <small class="hint">Créé le <?= e(date('d.m.Y H:i',(int)$a['created_at'])) ?></small>
 </div>
</section>
<?php endforeach; ?>
<p class="hint">La modification d’un rôle ou la désactivation invalide les sessions concernées. Le dernier administrateur actif est protégé. Désactiver un compte ne supprime pas ses situations.</p>
<details class="card"><summary>Dernières opérations sur les comptes</summary><p class="hint">Métadonnées uniquement ; aucun lien personnel ni mot de passe.</p>
<ul><?php foreach($audit as $event): ?><li><?= e(date('d.m.Y H:i',(int)$event['created_at'])) ?> · <?= e($event['actor']) ?> → <?= e($event['subject']) ?> · <?= e($event['action']) ?></li><?php endforeach; ?></ul></details>
