<?php use App\Atelier\Grille; use App\View\Markdown; ?>
<section class="card atelier-assistance" id="assistance" aria-labelledby="assistance-title">
<div class="page-head"><div><p class="eyebrow">UN APPUI POUR AVANCER</p><h2 id="assistance-title">Assistance IA · <?= $isE?'Analyse EOGI':'Feed-back' ?></h2></div><a href="#field-<?= $isE?'question':'faits' ?>">Revenir à la grille</a></div>
<p>Posez une question sur votre situation, faites reformuler un passage ou demandez de l’aide pour compléter un champ. L’assistant s’appuie sur votre grille et les fiches du RAG.</p>

<div class="no-print">
<p><strong>Besoin d’une idée pour commencer ?</strong></p><div class="btn-row assistant-ideas">
<?php $ideas=$isE?[
'Par où commencer ?'=>'Aide-moi à commencer cette analyse EOGI. Quel premier point dois-je clarifier au regard des faits disponibles ?',
'Classer mes observations'=>'Aide-moi à répartir mes observations entre Environnement, Organisation, Groupe et Individu, sans inventer les informations absentes.',
'Explorer une interaction'=>'Quelle interaction entre les niveaux puis-je explorer ? Distingue les faits des hypothèses et propose des questions pour vérifier une boucle éventuelle.',
]:[
'Trouver les mots'=>'Aide-moi à formuler un feed-back court adapté au type choisi, à partir des faits saisis et sans jugement sur la personne.',
'Distinguer faits et effets'=>'Aide-moi à distinguer les faits observables, les effets constatés et mon ressenti dans ce feed-back.',
'Préparer l’écoute'=>'Propose deux questions ouvertes pour comprendre le point de vue du collaborateur sans présumer de sa réponse.',
];foreach($ideas as $label=>$question): ?><button type="button" class="btn btn-small" data-help-question="<?= e($question) ?>"><?= e($label) ?></button><?php endforeach; ?>
</div>
<label for="assistant-question">Votre question à l’assistant</label><textarea id="assistant-question" name="assistant_question" rows="3" maxlength="2000" aria-describedby="assistant-hint" placeholder="<?= $isE?'Ex. Cette difficulté concerne-t-elle le groupe ou l’organisation ?':'Ex. Comment dire cela de manière factuelle et constructive ?' ?>"><?= e($helpQuestion) ?></textarea>
<p id="assistant-hint" class="hint">Votre grille est enregistrée avant l’envoi. Les réponses et les échanges restent personnels. L’assistant propose du texte. Le bouton « Reprendre cette réponse dans la grille » prépare un aperçu à valider pour compléter les champs vides.</p>
<button class="btn btn-primary" type="submit" formaction="index.php?action=atelier_help">Enregistrer et demander de l’aide à l’IA</button><p id="wait" class="wait" role="status" hidden>Enregistrement et traitement en cours… L’IA peut prendre jusqu’à deux minutes.</p>
</div>
<?php if($chat): ?><details class="assistant-thread" open><summary>Nos échanges dans ce parcours · <?= count($chat) ?> derniers messages</summary>
<?php foreach($chat as $message): ?><article <?= $message['role']==='assistant' && $message['id']===$chat[count($chat)-1]['id']?'id="assistance-reponse"':'' ?> class="<?= $message['role']==='user'?'help-user':'help-answer' ?>"><h3><?= $message['role']==='user'?'Votre question':'Réponse de l’assistant' ?></h3>
<?php if($message['role']==='user'): ?><p><?= nl2br(e($message['content'])) ?></p><?php else: ?>
<?php if((int)$message['revision']!==(int)($row['revision']??0) || $message['context_hash']!==Grille::contextHash($s)): ?><p class="hint">Réponse fondée sur une version antérieure de la grille ou de la situation.</p><?php endif; ?>
<?= Markdown::render($message['content']) ?>
<?php if($message['sources']): ?><div class="sources"><strong>Extraits de cet échange</strong><?php foreach($message['sources'] as $src): ?><details><summary>[<?= e($src['ref']) ?>] <?= e($src['titre']) ?></summary><p><?= e($src['source']??'') ?></p><pre><?= e($src['extrait']??'') ?></pre></details><?php endforeach; ?></div><?php endif; ?>
<?php if((int)$message['revision']===(int)($row['revision']??0) && $message['context_hash']===Grille::contextHash($s) && \App\Atelier\FillProposal::emptyFields($kind,$form)): ?><div class="no-print fill-action"><button type="submit" class="btn" formaction="index.php?action=atelier_fill_preview&amp;source=<?= (int)$message['id'] ?>">Reprendre cette réponse dans la grille</button><p class="hint">Un aperçu vous permettra de choisir les champs vides à compléter avant validation.</p></div><?php endif; ?>
<?php endif; ?><p class="meta"><?= e(format_date($message['created_at'],'d.m.Y H:i')) ?><?= $message['provider']?' · '.e($message['provider']):'' ?></p></article><?php endforeach; ?></details><?php endif; ?>
</section>
<script>
document.querySelectorAll('[data-help-question]').forEach(button=>button.addEventListener('click',()=>{const field=document.getElementById('assistant-question');field.value=button.dataset.helpQuestion;field.focus();}));
</script>
