<?php use App\Domain\Categorie; ?>
<h1><?= empty($d['id']) ? 'Nouveau document' : 'Modifier le document' ?></h1>

<form method="post" action="index.php?action=doc_save" enctype="multipart/form-data" class="card form">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int) ($d['id'] ?? 0) ?>">

    <div class="grid-2">
        <label>Titre
            <input name="titre" maxlength="255" value="<?= e($d['titre'] ?? '') ?>" placeholder="Vide = titre du fichier">
        </label>
        <label>Catégorie
            <select name="categorie">
                <?php foreach (Categorie::cases() as $c): ?>
                    <option value="<?= e($c->value) ?>" <?= ($d['categorie'] ?? '') === $c->value ? 'selected' : '' ?>><?= e($c->label()) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Source
            <input name="source" maxlength="255" value="<?= e($d['source'] ?? '') ?>" placeholder="Ex. Boîte à outils RH, directive interne…">
        </label>
        <label>Fichier (.txt ou .md, remplace le contenu ci-dessous)
            <input type="file" name="fichier" accept=".txt,.md">
        </label>
    </div>

    <label>Contenu (texte brut ou Markdown)
        <textarea name="contenu" rows="18"><?= e($d['contenu'] ?? '') ?></textarea>
    </label>

    <div class="actions">
        <button class="btn btn-primary">Enregistrer et indexer</button>
        <a class="btn" href="index.php?action=docs">Annuler</a>
    </div>
</form>

<?php if (!empty($chunks)): ?>
    <h2>Fragments indexés (<?= count($chunks) ?>)</h2>
    <?php foreach ($chunks as $c): ?>
        <details class="card chunk"><summary>Fragment <?= (int) $c['ordre'] ?> — <?= mb_strlen($c['contenu']) ?> car.</summary>
            <pre><?= e($c['contenu']) ?></pre>
        </details>
    <?php endforeach; ?>
<?php endif; ?>
