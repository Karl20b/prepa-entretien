<section class="login-shell">
 <div class="login-intro"><span class="eyebrow">ESPACE PERSONNEL · PRÉPARATION D’ENTRETIENS</span><h1>Préparer les mots.<br><em>Clarifier l’intention.</em></h1><p>Une situation concrète, les bonnes méthodes et un espace pour réfléchir avant l’entretien.</p><ol class="journey"><li><strong>Décrire</strong> les faits et vos attentes</li><li><strong>Préparer</strong> avec SMART, GROW et vos sources</li><li><strong>Affiner</strong> la trame et les questions</li></ol><p class="hint">Prototype privé · Données fictives ou d’exercice uniquement</p></div>
 <form method="post" action="index.php" class="card form login-card" autocomplete="on">
  <p class="eyebrow">VOTRE ESPACE PERSONNEL</p>
  <h2><?= $setup?'Activer mon espace privé':'Retrouver mon espace' ?></h2>
  <p><?= $setup?'Choisissez votre mot de passe pour ouvrir votre espace personnel.':'Connectez-vous pour retrouver vos situations et vos documents.' ?></p>
  <?= csrf_field() ?>
  <?php if($error): ?><p class="flash flash-error" role="alert" tabindex="-1" id="auth-error"><?= e($error) ?></p><?php endif; ?>
  <label>Identifiant<input value="<?= e($setup ? (string)config('app.setup_username','administrateur') : ($_POST['username'] ?? '')) ?>" name="username" autocomplete="username" spellcheck="false" maxlength="40" required <?= $setup ? 'readonly' : '' ?>></label>
  <?php if($setup): ?><label>Code d’activation<input name="activation" id="activation" type="password" autocomplete="off" required spellcheck="false"></label><?php endif; ?>
  <label>Mot de passe<?= $setup?' (14 caractères minimum)':'' ?><input type="password" name="password" autocomplete="<?= $setup?'new-password':'current-password' ?>" <?= $setup?'minlength="14"':'' ?> required maxlength="1024"></label>
  <?php if($setup): ?><label>Confirmer le mot de passe<input type="password" name="confirmation" autocomplete="new-password" minlength="14" required maxlength="1024"></label><label class="check"><input type="checkbox" name="exercise_only" value="1" required> J’utilise uniquement des données fictives ou d’exercice dans ce prototype privé.</label><?php endif; ?>
  <button class="btn btn-primary"><?= $setup?'Activer mon espace':'Se connecter' ?><svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></button>
  <p class="hint small-hint">Accès indépendant du portail. Vos documents restent dans cet espace privé.</p>
 </form>
</section>
<?php if($setup): ?><script>
const activation = new URLSearchParams(location.hash.slice(1)).get('activation');
if(activation){document.getElementById('activation').value=activation;history.replaceState(null,'',location.pathname);}
</script><?php endif; ?>
<?php if($error): ?><script>document.getElementById('auth-error').focus();</script><?php endif; ?>
