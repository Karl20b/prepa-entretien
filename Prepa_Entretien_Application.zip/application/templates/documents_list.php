<?php use App\Domain\Categorie; ?>
<div class="page-head">
    <h1>Base documentaire (RAG)</h1>
    <?php if (is_admin()): ?>
        <div class="btn-row">
            <a class="btn btn-primary" href="index.php?action=doc_new">+ Ajouter un document</a>
            <form method="post" action="index.php?action=doc_seed" data-confirm="Importer / mettre à jour les documents du dossier docs_seed ?">
                <?= csrf_field() ?><button class="btn">Importer les documents de démarrage</button>
            </form>
            <form method="post" action="index.php?action=doc_reindex">
                <?= csrf_field() ?><button class="btn">Réindexer tout</button>
            </form>
        </div>
    <?php endif; ?>
</div>

<p class="hint">La catégorie « Aide à l’utilisation » est recherchée séparément. Ses extraits sont exclus des préparations, analyses EOGI et feed-back.</p>
<?php if (!$docs): ?>
    <div class="card empty">
        <p>La base est vide. Importez les documents de démarrage (GROW, SMART, écoute active, feedback, recadrage, préparation) puis ajoutez vos propres fiches.</p>
    </div>
<?php else: ?>
    <table class="table">
        <thead><tr><th>Titre</th><th>Catégorie</th><th>Source</th><th>Taille</th><th>Fragments</th><th>État</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($docs as $d): ?>
            <tr class="<?= $d['actif'] ? '' : 'inactive' ?>">
                <td><?= is_admin() ? '<a href="index.php?action=doc_edit&id=' . (int) $d['id'] . '">' . e($d['titre']) . '</a>' : e($d['titre']) ?></td>
                <td><span class="badge"><?= e(Categorie::fromValue($d['categorie'])->label()) ?></span></td>
                <td><?= e($d['source'] ?: '—') ?></td>
                <td><?= number_format((int) $d['taille'], 0, '.', '\'') ?> car.</td>
                <td><?= (int) $d['nb_chunks'] ?></td>
                <td><?= $d['actif'] ? 'Actif' : 'Désactivé' ?></td>
                <td class="btn-row">
                    <?php if (is_admin()): ?>
                        <form method="post" action="index.php?action=doc_toggle">
                            <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
                            <button class="btn btn-small"><?= $d['actif'] ? 'Désactiver' : 'Activer' ?></button>
                        </form>
                        <form method="post" action="index.php?action=doc_delete" data-confirm="Supprimer ce document et ses fragments ?">
                            <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
                            <button class="btn btn-small btn-danger">Supprimer</button>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
