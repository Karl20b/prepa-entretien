<?php use App\Domain\TypeEntretien; ?>
<h1>Tester la recherche documentaire</h1>
<p class="hint">Vérifiez ce que le RAG transmettrait à l'IA pour une requête donnée.</p>

<form method="get" class="card form inline-form">
    <input type="hidden" name="action" value="search">
    <label for="rag-corpus">Corpus à consulter</label><select id="rag-corpus" name="corpus"><option value="metier" <?= ($corpus??'metier')==='metier'?'selected':'' ?>>CDC et méthodes d’entretien</option><option value="aide" <?= ($corpus??'metier')==='aide'?'selected':'' ?>>Aide à l’utilisation uniquement</option></select>
    <label class="sr-only" for="rag-query">Question documentaire</label><input id="rag-query" name="q" value="<?= e($q) ?>" placeholder="Ex. collaborateur démotivé, fixer un objectif mesurable" required>
    <label class="sr-only" for="rag-type">Type d’entretien</label><select id="rag-type" name="type">
        <option value="">— Sans priorité de catégorie —</option>
        <?php foreach (TypeEntretien::cases() as $t): ?>
            <option value="<?= e($t->value) ?>" <?= $type === $t->value ? 'selected' : '' ?>><?= e($t->label()) ?></option>
        <?php endforeach; ?>
    </select>
    <label for="rag-cdc">CDC à consulter</label><select id="rag-cdc" name="cdc_role"><option value="">— Sans CDC associé —</option><?php foreach(\App\Reference\RoleCatalog::all() as $key=>$role): ?><option value="<?= e($key) ?>" <?= ($cdcRole??'')===$key?'selected':'' ?>><?= e($role['label']) ?></option><?php endforeach; ?></select>
    <button class="btn btn-primary">Rechercher</button>
</form><p class="hint">Dans le corpus métier, les pages actives du seul CDC choisi sont incluses en priorité. Dans le corpus d’aide, aucun CDC ni document de méthode n’est utilisé. Les extraits d’aide sont exclus des préparations, EOGI et feed-back.</p>

<?php if ($q !== '' && !$results): ?>
    <div class="card empty">Aucun fragment trouvé.</div>
<?php endif; ?>
<?php foreach ($results as $i => $r): ?>
    <div class="card chunk">
        <strong><span class="src-ref">S<?= $i + 1 ?></span> <?= e($r['titre']) ?></strong>
        <span class="badge"><?= e($r['categorie']) ?></span>
        <span class="meta">score <?= number_format($r['score'], 3) ?></span>
        <p class="meta"><?= e($r['source'] ?? '') ?></p><pre><?= e($r['contenu']) ?></pre>
    </div>
<?php endforeach; ?>
