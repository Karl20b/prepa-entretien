<?php use App\Domain\TypeEntretien; ?>
<h1>Tester la recherche documentaire</h1>
<p class="hint">Vérifiez ce que le RAG transmettrait à l'IA pour une requête donnée.</p>

<form method="get" class="card form inline-form">
    <input type="hidden" name="action" value="search">
    <label class="sr-only" for="rag-query">Question documentaire</label><input id="rag-query" name="q" value="<?= e($q) ?>" placeholder="Ex. collaborateur démotivé, fixer un objectif mesurable" required>
    <label class="sr-only" for="rag-type">Type d’entretien</label><select id="rag-type" name="type">
        <option value="">— Sans priorité de catégorie —</option>
        <?php foreach (TypeEntretien::cases() as $t): ?>
            <option value="<?= e($t->value) ?>" <?= $type === $t->value ? 'selected' : '' ?>><?= e($t->label()) ?></option>
        <?php endforeach; ?>
    </select>
    <button class="btn btn-primary">Rechercher</button>
</form>

<?php if ($q !== '' && !$results): ?>
    <div class="card empty">Aucun fragment trouvé.</div>
<?php endif; ?>
<?php foreach ($results as $i => $r): ?>
    <div class="card chunk">
        <strong><span class="src-ref">S<?= $i + 1 ?></span> <?= e($r['titre']) ?></strong>
        <span class="badge"><?= e($r['categorie']) ?></span>
        <span class="meta">score <?= number_format($r['score'], 3) ?></span>
        <p class="meta"><?= e($r['source'] ?? '') ?></p><pre><?= e($r['contenu']) ?></pre>
    </div>
<?php endforeach; ?>
