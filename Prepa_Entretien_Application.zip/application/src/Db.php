<?php
declare(strict_types=1);
namespace App;
use PDO;
final class Db {
    private static ?PDO $pdo = null;
    public static function pdo(): PDO {
        if (self::$pdo === null) {
            $path = (string) config('db.path');
            if ($path === '') throw new \RuntimeException('Stockage privé non configuré.');
            $class = class_exists('Pdo\\Sqlite') ? 'Pdo\\Sqlite' : PDO::class;
            self::$pdo = new $class('sqlite:' . $path, null, null, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
            self::$pdo->exec('PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
            $function = method_exists(self::$pdo, 'createFunction') ? 'createFunction' : 'sqliteCreateFunction';
            self::$pdo->$function('NOW', fn()=>date('Y-m-d H:i:s'), 0);
            self::$pdo->$function('CHAR_LENGTH', fn($v)=>mb_strlen((string)$v), 1);
        }
        return self::$pdo;
    }
}
