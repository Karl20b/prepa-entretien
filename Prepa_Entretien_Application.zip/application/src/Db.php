<?php
declare(strict_types=1);
namespace App;
use PDO;
final class Db {
    private static ?PDO $pdo = null;
    public static function pdo(): PDO {
        if (self::$pdo === null) {
            $path = (string) config('db.path');
            if ($path === '') throw new \RuntimeException('Stockage privé non configuré.');
            $class = class_exists('Pdo\\Sqlite') ? 'Pdo\\Sqlite' : PDO::class;
            self::$pdo = new $class('sqlite:' . $path, null, null, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
            self::$pdo->setAttribute(PDO::ATTR_STATEMENT_CLASS,[\App\Security\Statement::class]);
            self::$pdo->exec('PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
            $function = method_exists(self::$pdo, 'createFunction') ? 'createFunction' : 'sqliteCreateFunction';
            self::$pdo->$function('NOW', fn()=>date('Y-m-d H:i:s'), 0);
            self::$pdo->$function('CHAR_LENGTH', fn($v)=>mb_strlen((string)\App\Security\Vault::decoded($v)), 1);
            self::$pdo->$function('PE_DEC', fn($v)=>\App\Security\Vault::decoded($v), 1);
            self::$pdo->$function('PE_VALID_CIPHER', fn($v,$s)=>\App\Security\Vault::valid($v,$s), 2);
        }
        return self::$pdo;
    }
}
