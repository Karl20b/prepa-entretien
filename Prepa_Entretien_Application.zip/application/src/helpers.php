<?php
declare(strict_types=1);

function config(string $path, mixed $default = null): mixed
{
    $value = $GLOBALS['config'];
    foreach (explode('.', $path) as $key) {
        if (!is_array($value) || !array_key_exists($key, $value)) {
            return $default;
        }
        $value = $value[$key];
    }
    return $value;
}

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Identité authentifiée de cette application autonome. */
function current_user(): string {
    if (empty($_SESSION['user'])) throw new RuntimeException('Authentification requise.');
    return (string) $_SESSION['user'];
}

function is_admin(): bool {
    if (empty($_SESSION['user'])) return false;
    $account = (new \App\Repo\AccountRepo(\App\Db::pdo()))->find((string)$_SESSION['user']);
    return $account && (bool)$account['active'] && $account['role'] === 'admin';
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void
{
    $expected = (string) ($_SESSION['csrf'] ?? '');
    $given = (string) ($_POST['csrf'] ?? '');
    // Un jeton vide (session neuve) ne doit jamais valider
    if ($expected === '' || $given === '' || !hash_equals($expected, $given)) {
        http_response_code(419);
        exit('Jeton de sécurité invalide. Rechargez la page.');
    }
}

function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

function flash(string $message, string $type = 'info'): void
{
    $_SESSION['flash'][] = ['msg' => $message, 'type' => $type];
}

/** @return list<array{msg:string,type:string}> */
function flashes(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

function render(string $template, array $vars = [], string $title = ''): void
{
    extract($vars, EXTR_SKIP);
    ob_start();
    require APP_ROOT . '/templates/' . $template . '.php';
    $content = ob_get_clean();
    require APP_ROOT . '/templates/layout.php';
}

function not_found(string $message = 'Élément introuvable.'): never
{
    http_response_code(404);
    render('error', ['message' => $message], 'Introuvable');
    exit;
}

function format_date(?string $value, string $format = 'd.m.Y'): string
{
    if (!$value) {
        return '—';
    }
    $d = date_create($value);
    return $d ? $d->format($format) : '—';
}
