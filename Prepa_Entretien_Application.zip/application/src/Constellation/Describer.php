<?php
declare(strict_types=1);

namespace App\Constellation;

/**
 * Traduit une constellation (positions, orientations, liens) en texte
 * factuel que l'IA peut lire : zones, regards, proximités, liens, évolutions.
 */
final class Describer
{
    private const PROCHE = 160;
    private const ELOIGNE = 380;
    private const REGARD = 25;   // tolérance en degrés pour « regarde vers »
    private const DOS = 155;     // au-delà : « tourne le dos à »

    public function describe(array $data): string
    {
        $out = [];
        $images = $data['images'] ?? [];
        foreach ($images as $i => $img) {
            $out[] = sprintf('### Image %d : %s', $i + 1, $img['nom']);
            $out[] = $this->image($img);
            if ($i > 0) {
                $out[] = $this->diff($images[$i - 1], $img);
            }
        }
        return trim(implode("\n\n", $out));
    }

    public function image(array $img): string
    {
        $els = $img['elements'] ?? [];
        if ($els === []) {
            return '(aucun élément placé)';
        }
        $by = array_column($els, null, 'id');
        [$cx, $cy] = $this->centroid($els);
        $spread = $this->meanDistance($els, $cx, $cy);

        $lines = ['Éléments (plateau vu de dessus ; « haut » = fond du plateau) :'];
        foreach ($els as $e) {
            $parts = [sprintf('%s [%s', $e['label'], ConstellationData::TYPES[$e['type']] ?? $e['type'])];
            $parts[0] .= match ($e['taille']) { 3 => ', grande taille', 1 => ', petite taille', default => '' } . ']';
            $parts[] = 'position : ' . $this->zone($e) . $this->centrality($e, $cx, $cy, $spread, count($els));
            if (self::oriented($e)) {
                $parts[] = 'regard : ' . $this->compass($e['angle']) . $this->gaze($e, $els);
            }
            if ($e['note'] !== '') {
                $parts[] = 'note : ' . $e['note'];
            }
            $lines[] = '- ' . implode(' ; ', $parts);
        }

        // Proximités : voisin le plus proche de chaque élément, sans doublon
        if (count($els) > 1) {
            $lines[] = '';
            $lines[] = 'Proximités :';
            $seen = [];
            foreach ($els as $e) {
                [$n, $d] = $this->nearest($e, $els);
                $key = $e['id'] < $n['id'] ? $e['id'] . $n['id'] : $n['id'] . $e['id'];
                if (isset($seen[$key])) {
                    continue;
                }
                $seen[$key] = true;
                $txt = $d > self::ELOIGNE
                    ? sprintf('- %s est isolé (élément le plus proche : %s, %s)', $e['label'], $n['label'], $this->dist($d))
                    : sprintf('- %s et %s : %s', $e['label'], $n['label'], $this->dist($d));
                $lines[] = $txt;
            }
            foreach ($this->mutualGazes($els) as [$a, $b]) {
                $lines[] = sprintf('- %s et %s se font face', $a['label'], $b['label']);
            }
        }

        $liens = $img['liens'] ?? [];
        if ($liens !== []) {
            $lines[] = '';
            $lines[] = 'Liens tracés :';
            foreach ($liens as $l) {
                if (!isset($by[$l['from']], $by[$l['to']])) {
                    continue;
                }
                $lines[] = sprintf('- %s — %s — %s%s', $by[$l['from']]['label'], ConstellationData::LIENS[$l['kind']] ?? $l['kind'],
                    $by[$l['to']]['label'], $l['label'] !== '' ? ' (« ' . $l['label'] . ' »)' : '');
            }
        }
        return implode("\n", $lines);
    }

    public function diff(array $prev, array $cur): string
    {
        $old = array_column($prev['elements'] ?? [], null, 'id');
        $new = array_column($cur['elements'] ?? [], null, 'id');
        $lines = ['Évolution par rapport à l\'image précédente :'];

        foreach ($new as $id => $e) {
            if (!isset($old[$id])) {
                $lines[] = "- Ajouté : {$e['label']}";
                continue;
            }
            $o = $old[$id];
            $dx = $e['x'] - $o['x'];
            $dy = $e['y'] - $o['y'];
            $d = hypot($dx, $dy);
            if ($d > 60) {
                $dirs = [];
                if (abs($dy) > 40) $dirs[] = $dy < 0 ? 'vers le haut' : 'vers le bas';
                if (abs($dx) > 40) $dirs[] = $dx < 0 ? 'vers la gauche' : 'vers la droite';
                $lines[] = sprintf('- %s s\'est déplacé %s (%s)', $e['label'], implode(' et ', $dirs), $this->dist($d, true));
            }
            $da = abs((($e['angle'] - $o['angle'] + 540) % 360) - 180);
            if ($da > 30 && self::oriented($e)) {
                $lines[] = sprintf('- %s a changé d\'orientation : %s → %s', $e['label'], $this->compass($o['angle']), $this->compass($e['angle']));
            }
            if ($e['label'] !== $o['label']) {
                $lines[] = sprintf('- %s a été renommé en %s', $o['label'], $e['label']);
            }
        }
        foreach ($old as $id => $o) {
            if (!isset($new[$id])) {
                $lines[] = "- Retiré : {$o['label']}";
            }
        }

        $key = fn(array $l) => min($l['from'], $l['to']) . '|' . max($l['from'], $l['to']);
        $ol = [];
        foreach ($prev['liens'] ?? [] as $l) $ol[$key($l)] = $l;
        $nl = [];
        foreach ($cur['liens'] ?? [] as $l) $nl[$key($l)] = $l;
        $label = fn(string $id) => $new[$id]['label'] ?? $old[$id]['label'] ?? '?';
        foreach ($nl as $k => $l) {
            if (!isset($ol[$k])) {
                $lines[] = sprintf('- Nouveau lien (%s) : %s — %s', ConstellationData::LIENS[$l['kind']], $label($l['from']), $label($l['to']));
            } elseif ($ol[$k]['kind'] !== $l['kind']) {
                $lines[] = sprintf('- Lien %s — %s : %s → %s', $label($l['from']), $label($l['to']),
                    ConstellationData::LIENS[$ol[$k]['kind']], ConstellationData::LIENS[$l['kind']]);
            }
        }
        foreach ($ol as $k => $l) {
            if (!isset($nl[$k])) {
                $lines[] = sprintf('- Lien supprimé : %s — %s', $label($l['from']), $label($l['to']));
            }
        }
        if (count($lines) === 1) {
            $lines[] = '- Aucun changement notable';
        }
        return implode("\n", $lines);
    }

    // ------------------------------------------------------------------ outils

    private function zone(array $e): string
    {
        $col = $e['x'] < ConstellationData::W / 3 ? 'gauche' : ($e['x'] > 2 * ConstellationData::W / 3 ? 'droite' : 'centre');
        $row = $e['y'] < ConstellationData::H / 3 ? 'haut' : ($e['y'] > 2 * ConstellationData::H / 3 ? 'bas' : 'milieu');
        if ($col === 'centre' && $row === 'milieu') {
            return 'centre du plateau';
        }
        if ($col === 'centre') {
            return $row . ' du plateau, au centre';
        }
        return $row === 'milieu' ? "côté {$col}" : "{$row} {$col}";
    }

    private function centrality(array $e, float $cx, float $cy, float $spread, int $n): string
    {
        if ($n < 3 || $spread <= 0) {
            return '';
        }
        $r = hypot($e['x'] - $cx, $e['y'] - $cy) / $spread;
        return $r < 0.5 ? ', au cœur du groupe' : ($r > 1.5 ? ', en périphérie du groupe' : '');
    }

    private function compass(int $angle): string
    {
        $dirs = ['vers le haut', 'vers le haut-droite', 'vers la droite', 'vers le bas-droite',
                 'vers le bas', 'vers le bas-gauche', 'vers la gauche', 'vers le haut-gauche'];
        return $dirs[(int) round($angle / 45) % 8];
    }

    /** Angle (0 = haut, horaire) de a vers b. */
    private function bearing(array $a, array $b): float
    {
        $deg = rad2deg(atan2($b['x'] - $a['x'], -($b['y'] - $a['y'])));
        return fmod($deg + 360, 360);
    }

    private function angleDiff(float $a, float $b): float
    {
        return abs(fmod($a - $b + 540, 360) - 180);
    }

    /** Les enjeux et ressources n'ont pas de regard. */
    public static function oriented(array $e): bool
    {
        return in_array($e['type'], ['personne', 'cadre', 'role'], true);
    }

    private function gaze(array $e, array $els): string
    {
        $facing = [];
        $back = [];
        foreach ($els as $o) {
            if ($o['id'] === $e['id']) {
                continue;
            }
            $diff = $this->angleDiff($e['angle'], $this->bearing($e, $o));
            if ($diff <= self::REGARD) {
                $facing[] = [$o['label'], $diff];
            } elseif ($diff >= self::DOS) {
                $back[] = [$o['label'], 180 - $diff];
            }
        }
        // Le plus dans l'axe d'abord
        $sort = static function (array $list): array {
            usort($list, fn($a, $b) => $a[1] <=> $b[1]);
            return array_column(array_slice($list, 0, 3), 0);
        };
        $txt = $facing ? ', regarde vers ' . implode(', puis ', $sort($facing)) : ', ne regarde aucun élément en particulier';
        if ($back) {
            $txt .= ', tourne le dos à ' . implode(' et ', $sort($back));
        }
        return $txt;
    }

    private function mutualGazes(array $els): array
    {
        $pairs = [];
        $n = count($els);
        for ($i = 0; $i < $n; $i++) {
            for ($j = $i + 1; $j < $n; $j++) {
                [$a, $b] = [$els[$i], $els[$j]];
                if (self::oriented($a) && self::oriented($b) &&$this->angleDiff($a['angle'], $this->bearing($a, $b)) <= self::REGARD
                    && $this->angleDiff($b['angle'], $this->bearing($b, $a)) <= self::REGARD) {
                    $pairs[] = [$a, $b];
                }
            }
        }
        return $pairs;
    }

    private function nearest(array $e, array $els): array
    {
        $best = null;
        foreach ($els as $o) {
            if ($o['id'] === $e['id']) {
                continue;
            }
            $d = hypot($o['x'] - $e['x'], $o['y'] - $e['y']);
            if ($best === null || $d < $best[1]) {
                $best = [$o, $d];
            }
        }
        return $best;
    }

    private function dist(float $d, bool $movement = false): string
    {
        if ($movement) {
            return $d < 150 ? 'léger déplacement' : ($d < 350 ? 'déplacement net' : 'déplacement important');
        }
        return $d < self::PROCHE ? 'très proches' : ($d < self::ELOIGNE ? 'à distance moyenne' : 'éloignés');
    }

    private function centroid(array $els): array
    {
        $n = count($els);
        return [array_sum(array_column($els, 'x')) / $n, array_sum(array_column($els, 'y')) / $n];
    }

    private function meanDistance(array $els, float $cx, float $cy): float
    {
        $sum = 0.0;
        foreach ($els as $e) {
            $sum += hypot($e['x'] - $cx, $e['y'] - $cy);
        }
        return $sum / count($els);
    }
}
