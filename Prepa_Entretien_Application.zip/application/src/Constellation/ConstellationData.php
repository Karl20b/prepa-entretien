<?php
declare(strict_types=1);

namespace App\Constellation;

/**
 * Modèle et validation des données d'une constellation.
 * Plateau logique de 1000 × 700 ; angle en degrés, 0 = regard vers le haut, sens horaire.
 */
final class ConstellationData
{
    public const W = 1000;
    public const H = 700;

    public const TYPES = [
        'personne'  => 'Personne',
        'cadre'     => 'Moi (cadre)',
        'role'      => 'Rôle / fonction',
        'enjeu'     => 'Enjeu / objectif',
        'ressource' => 'Ressource / acteur externe',
    ];

    public const LIENS = [
        'lien'    => 'Lien',
        'fort'    => 'Lien fort / soutien',
        'tension' => 'Tension',
        'rupture' => 'Rupture / distance',
    ];

    private const MAX_IMAGES = 12;
    private const MAX_ELEMENTS = 60;
    private const MAX_LIENS = 200;

    public static function empty(): array
    {
        return ['version' => 1, 'images' => [
            ['id' => self::uid(), 'nom' => 'Image actuelle', 'elements' => [], 'liens' => [], 'cercles'=>[]],
        ]];
    }

    /** Nettoie et borne les données reçues du navigateur. */
    public static function sanitize(mixed $raw): array
    {
        if (is_string($raw)) {
            $raw = json_decode($raw, true);
        }
        if (!is_array($raw) || !isset($raw['images']) || !is_array($raw['images'])) {
            throw new \InvalidArgumentException('Données de constellation invalides.');
        }

        $images = [];
        foreach (array_slice($raw['images'], 0, self::MAX_IMAGES) as $img) {
            if (!is_array($img)) {
                continue;
            }
            $elements = [];
            $ids = [];
            foreach (array_slice((array) ($img['elements'] ?? []), 0, self::MAX_ELEMENTS) as $e) {
                if (!is_array($e)) {
                    continue;
                }
                $id = self::id($e['id'] ?? null);
                if ($id === null || isset($ids[$id])) {
                    continue;
                }
                $ids[$id] = true;
                $elements[] = [
                    'id'     => $id,
                    'type'   => array_key_exists($e['type'] ?? '', self::TYPES) ? $e['type'] : 'personne',
                    'label'  => self::text($e['label'] ?? '', 60) ?: 'Sans nom',
                    'x'      => self::clamp((float) ($e['x'] ?? 500), 0, self::W),
                    'y'      => self::clamp((float) ($e['y'] ?? 350), 0, self::H),
                    'angle'  => (int) round(fmod(fmod((float) ($e['angle'] ?? 0), 360) + 360, 360)),
                    'taille' => (int) self::clamp((int) ($e['taille'] ?? 2), 1, 3),
                    'note'   => self::text($e['note'] ?? '', 300),
                ];
            }
            $liens = [];
            foreach (array_slice((array) ($img['liens'] ?? []), 0, self::MAX_LIENS) as $l) {
                if (!is_array($l)) {
                    continue;
                }
                $from = self::id($l['from'] ?? null);
                $to = self::id($l['to'] ?? null);
                if ($from === null || $to === null || $from === $to || !isset($ids[$from], $ids[$to])) {
                    continue;
                }
                $liens[] = [
                    'id'    => self::id($l['id'] ?? null) ?? self::uid(),
                    'from'  => $from,
                    'to'    => $to,
                    'kind'  => array_key_exists($l['kind'] ?? '', self::LIENS) ? $l['kind'] : 'lien',
                    'label' => self::text($l['label'] ?? '', 60),
                ];
            }
            $cercles=[];$circleIds=[];
            foreach(array_slice((array)($img['cercles']??[]),0,20) as $c){
                if(!is_array($c))continue;$ci=self::id($c['id']??null);if($ci===null||isset($circleIds[$ci]))continue;$circleIds[$ci]=true;
                $rx=self::clamp((float)($c['rx']??180),60,490);$ry=self::clamp((float)($c['ry']??140),60,340);
                $members=[];foreach(array_slice((array)($c['members']??[]),0,self::MAX_ELEMENTS) as $mid){$mid=self::id($mid);if($mid!==null&&isset($ids[$mid]))$members[$mid]=$mid;}
                $cercles[]=['id'=>$ci,'label'=>self::text($c['label']??'',60)?:'Regroupement','x'=>self::clamp((float)($c['x']??500),$rx,self::W-$rx),'y'=>self::clamp((float)($c['y']??350),$ry,self::H-$ry),'rx'=>$rx,'ry'=>$ry,'members'=>array_values($members)];
            }
            $images[] = [
                'id'       => self::id($img['id'] ?? null) ?? self::uid(),
                'nom'      => self::text($img['nom'] ?? '', 60) ?: 'Image ' . (count($images) + 1),
                'elements' => $elements,
                'liens'    => $liens,
                'cercles' => $cercles,
            ];
        }
        if ($images === []) {
            return self::empty();
        }
        return ['version' => 1, 'images' => $images];
    }

    private static function id(mixed $v): ?string
    {
        $v = (string) $v;
        return preg_match('/^[A-Za-z0-9_-]{1,32}$/', $v) ? $v : null;
    }

    private static function text(mixed $v, int $max): string
    {
        $v = trim(preg_replace('/[\x00-\x1F\x7F]+/u', ' ', (string) $v) ?? '');
        return mb_substr($v, 0, $max);
    }

    private static function clamp(float|int $v, float|int $min, float|int $max): float|int
    {
        return max($min, min($max, $v));
    }

    private static function uid(): string
    {
        return substr(bin2hex(random_bytes(6)), 0, 10);
    }
}
