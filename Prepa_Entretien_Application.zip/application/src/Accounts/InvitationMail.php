<?php
declare(strict_types=1);
namespace App\Accounts;
final class InvitationMail {
 /** Message préparé uniquement, sans envoi ni stockage d’adresse ou de lien. */
 public static function compose(string $username,string $name,string $link,string $kind):array {
  if(!in_array($kind,['activate','reset'],true))throw new \InvalidArgumentException('Type de lien invalide.');
  $name=trim(preg_replace('/[\r\n]+/u',' ',trim($name))??'');
  $hello=$name!==''&&$name!==$username?'Bonjour '.$name.',':'Bonjour,';
  $activate=$kind==='activate';
  $subject=$activate?'Votre accès à Prépa Entretien':'Réinitialisation de votre accès à Prépa Entretien';
  $intro=$activate?'Votre compte personnel Prépa Entretien a été créé.':'Un lien de réinitialisation de votre mot de passe Prépa Entretien a été préparé pour vous.';
  $verb=$activate?'activer votre compte':'choisir un nouveau mot de passe';
  $duration=$activate?'48 heures':'une heure';
  $base=preg_replace('/index\.php$/','',explode('?',explode('#',$link,2)[0],2)[0]);
  $body=$hello."\n\n".$intro."\n\nVotre identifiant : ".$username."\n\nPour ".$verb.", ouvrez ce lien personnel :\n".$link."\n\nCe lien est valable ".$duration." à compter de sa création et ne peut être utilisé qu’une fois. Ne le partagez pas.\n\n1. Ouvrez le lien.\n2. Choisissez votre propre mot de passe de 14 caractères minimum et confirmez-le.\n3. Confirmez l’utilisation de données fictives ou d’exercice, puis validez.\n\nPour revenir ensuite sur le site :\n".$base."\nConnectez-vous avec votre identifiant et le mot de passe que vous avez choisi.\n\nSi le lien est expiré ou ne fonctionne plus, contactez l’administrateur pour en obtenir un nouveau. Aucun mot de passe ne vous sera demandé par courriel.\n\nBonne préparation.";
  return ['subject'=>$subject,'body'=>$body];
 }
}
