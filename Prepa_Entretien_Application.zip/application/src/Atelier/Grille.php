<?php
declare(strict_types=1);
namespace App\Atelier;
final class Grille {
 public static function fields(string $kind):array {
  return match($kind){
   'eogi'=>[
    'question'=>['Question de travail','Quel problème ou changement souhaitez-vous comprendre ?'],
    'environnement'=>['E · Environnement','Contraintes externes, évolution du contexte, attentes des partenaires ou du public. Quels éléments observables ?'],
    'organisation'=>['O · Organisation','Règles, ressources, formation, processus, décisions. Quel écart entre le fonctionnement prévu et le travail réel ?'],
    'groupe'=>['G · Groupe','Rôles, coopération, communication, normes informelles. Quels échanges et influences réciproques ?'],
    'individu'=>['I · Individu','Compétences, perceptions exprimées, motivations et marge de manœuvre. Évitez les suppositions sur la vie privée.'],
    'boucles'=>['Interactions et boucles de rétroaction','Décrire une séquence : A influence B, puis B renforce ou modère A. Quels faits l’appuient ? Quelles autres explications ?'],
    'incertitudes'=>['Perceptions, hypothèses et informations manquantes','Qui rapporte quoi ? Que reste-t-il à vérifier et auprès de qui ?'],
    'leviers'=>['Marge d’action et première expérience','Ce qui dépend de vous, ce qui peut être influencé ou doit être transmis ; petite action réversible et signe de résultat attendu.'],
   ],
   'feedback'=>[
    'faits'=>['1 · Exposer les faits','Un comportement précis, observable et situé. Évitez « toujours », « jamais » et les étiquettes sur la personne.'],
    'effets'=>['2 · Informer des effets','Conséquences observées ; distinguez-les des effets seulement possibles et de votre ressenti.'],
    'ecoute'=>['3 · Questionner et écouter','Questions ouvertes et, après l’échange, propos réellement recueillis. Ne prêtez pas de réponse au collaborateur.'],
    'attentes'=>['4 · Reformuler et clarifier les attentes','Reformulation à vérifier avec la personne, attentes explicites et comportements attendus.'],
    'suite'=>['5 · Co-construire la suite','Options, soutien, moyens et objectif à convenir. Distinguez proposition et accord réellement obtenu.'],
    'suivi'=>['6 · Valoriser et assurer le suivi','Reconnaissance précise, premier pas, date de retour et indicateur de progrès à convenir.'],
   ],default=>throw new \InvalidArgumentException('Parcours inconnu.')};
 }
 public static function clean(string $kind,array $input):array {
  $out=[];
  if($kind==='feedback'){
   $mode=(string)($input['mode']??'valorisation');
   if(!in_array($mode,['valorisation','amelioration'],true))throw new \InvalidArgumentException('Choisissez un type de feed-back valide.');
   $out['mode']=$mode;
  }
  foreach(self::fields($kind) as $key=>$label){
   if(isset($input[$key])&&!is_string($input[$key]))throw new \InvalidArgumentException('Un champ contient une valeur non valide.');
   $v=trim((string)($input[$key]??''));
   if(mb_strlen($v)>4000)throw new \InvalidArgumentException('Chaque champ est limité à 4 000 caractères. Raccourcissez le texte puis réessayez.');
   $out[$key]=$v;
  }
  return $out;
 }
 public static function block(string $kind,array $data):string {
  $lines=['<atelier type="'.$kind.'">'];
  if($kind==='feedback')$lines[]='Type : '.(($data['mode']??'')==='amelioration'?'amélioration':'valorisation');
  foreach(self::fields($kind) as $key=>[$label])$lines[]=$label.' : '.(($data[$key]??'')!==''?$data[$key]:'(non renseigné)');
  return implode("\n",$lines)."\n</atelier>";
 }
 public static function contextHash(array $s):string {
  return hash('sha256',json_encode(array_intersect_key($s,array_flip(\App\Repo\SituationRepo::FIELDS)),JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
 }
}
