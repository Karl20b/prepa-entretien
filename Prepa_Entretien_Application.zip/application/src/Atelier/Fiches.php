<?php
declare(strict_types=1);
namespace App\Atelier;
use PDO;
final class Fiches {
 public static function all(PDO $pdo):array {
  $catalogue=json_decode(file_get_contents(APP_ROOT.'/fiches/catalogue.json'),true,512,JSON_THROW_ON_ERROR);$out=[];
  $st=$pdo->prepare('SELECT id,contenu FROM pe_documents WHERE titre=? AND actif=1 LIMIT 1');
  foreach($catalogue as $f){$st->execute([$f['titre']]);if($r=$st->fetch())$out[]=$f+$r;}return $out;
 }
 public static function photo():never {
  $id=(string)($_GET['photo']??'');if(!in_array($id,['1','2','3','4'],true))not_found();
  $f=APP_ROOT.'/fiches/photos/photo-'.$id.'.jpg';if(!is_file($f))not_found();
  header('Content-Type: image/jpeg');header('Content-Length: '.filesize($f));session_write_close();
  if(($_SERVER['REQUEST_METHOD']??'GET')!=='HEAD')readfile($f);exit;
 }
}
