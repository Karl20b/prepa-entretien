<?php
declare(strict_types=1);
namespace App\Security;
/** Decode authenticated envelopes before existing domain parsers see JSON or text. */
final class Statement extends \PDOStatement {
 protected function __construct(){}
 public function fetch(int $mode=\PDO::FETCH_DEFAULT,int $cursorOrientation=\PDO::FETCH_ORI_NEXT,int $cursorOffset=0):mixed{return Vault::decoded(parent::fetch($mode,$cursorOrientation,$cursorOffset));}
 public function fetchAll(int $mode=\PDO::FETCH_DEFAULT,mixed ...$args):array{return Vault::decoded(parent::fetchAll($mode,...$args));}
 public function fetchColumn(int $column=0):mixed{return Vault::decoded(parent::fetchColumn($column));}
}
