<?php
declare(strict_types=1);
namespace App\Security;
/** Versioned, authenticated storage. No key or plaintext fallback when enabled. */
final class Vault {
 public const FIELDS=[
  'pe_situations'=>['titre','collaborateur_ref','fonction','date_entretien','contexte','faits','objectif_manager','enjeux'],
  'pe_messages'=>['contenu','sources'], 'pe_ateliers'=>['data','analysis','sources'],
  'pe_atelier_messages'=>['content','sources'],
  'pe_constellations'=>['titre','question','data','analyse','analyse_sources'],
  'pe_documents'=>['titre','source','contenu'],'pe_chunks'=>['contenu'],
  'pe_accounts'=>['display_name'],
 ];
 public static function enabled():bool{return (bool)\config('security.encryption',false);}
 public static function key(string $purpose):string {
  $path=(string)\config('security.key_file','');
  clearstatcache(true,$path);
  if($path===''||!is_file($path)||is_link($path))throw new \RuntimeException('Clé de chiffrement indisponible.');
  if((fileperms($path)&0077)!==0)throw new \RuntimeException('Permissions de la clé trop larges.');
  $raw=file_get_contents($path);if(!is_string($raw)||strlen($raw)!==32)throw new \RuntimeException('Clé de chiffrement invalide.');
  return sodium_crypto_generichash('prepa-v1:'.$purpose,$raw,32);
 }
 public static function seal(?string $value,string $scope,bool $force=false):?string {
  if($value===null||(!self::enabled()&&!$force))return $value;
  $nonce=random_bytes(24);$key=self::key(explode(':',explode('.',$scope,2)[0],2)[0]);
  $box=sodium_crypto_aead_xchacha20poly1305_ietf_encrypt($value,$scope,$nonce,$key);
  sodium_memzero($key);return 'pe1:'.base64_encode($scope).':'.base64_encode($nonce.$box);
 }
 public static function open(?string $value,?string $expected=null):?string {
  if($value===null)return null;
  if(!str_starts_with($value,'pe1:')){if($expected!==null&&self::enabled())throw new \RuntimeException('Donnée protégée non chiffrée.');return $value;}
  $parts=explode(':',$value,3);$scope=base64_decode($parts[1]??'',true);$raw=base64_decode($parts[2]??'',true);
  if(!is_string($scope)||!is_string($raw)||strlen($raw)<40||($expected!==null&&!hash_equals($expected,$scope)))throw new \RuntimeException('Donnée chiffrée invalide.');
  $key=self::key(explode(':',explode('.',$scope,2)[0],2)[0]);$text=sodium_crypto_aead_xchacha20poly1305_ietf_decrypt(substr($raw,24),$scope,substr($raw,0,24),$key);sodium_memzero($key);
  if($text===false)throw new \RuntimeException('Donnée illisible : clé ou intégrité invalide.');return $text;
 }
 public static function values(string $table,array $cols,array $values):array {
  foreach($cols as $i=>$col)if(in_array($col,self::FIELDS[$table]??[],true))$values[$i]=self::seal($values[$i]===null?null:(string)$values[$i],$table.'.'.$col);
  return $values;
 }
 public static function decoded(mixed $value):mixed {
  if(is_array($value)){foreach($value as $k=>&$v)if($k!=='secret')$v=self::decoded($v);return $value;}
  return is_string($value)&&str_starts_with($value,'pe1:')?self::open($value):$value;
 }
 public static function read(string $path):string {return (string)self::open((string)file_get_contents($path),self::enabled()?'file:'.basename($path):null);}
 public static function valid(?string $value,string $scope):int {if($value===null)return 1;try{if(!str_starts_with($value,'pe1:'))return 0;self::open($value,$scope);return 1;}catch(\Throwable){return 0;}}
}
