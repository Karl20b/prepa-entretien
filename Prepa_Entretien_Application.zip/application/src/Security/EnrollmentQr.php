<?php
declare(strict_types=1);
namespace App\Security;
final class EnrollmentQr {
 public static function uri(string $secret,string $username):string {
  if(!preg_match('/^[A-Z2-7]{32}$/D',$secret)||!preg_match('/^[a-z0-9][a-z0-9._-]{2,39}$/D',$username))throw new \InvalidArgumentException('Configuration Authenticator invalide.');
  $issuer='Prépa Entretien';return 'otpauth://totp/'.rawurlencode($issuer).':'.rawurlencode($username).'?'.http_build_query(['secret'=>$secret,'issuer'=>$issuer,'algorithm'=>'SHA1','digits'=>6,'period'=>30],'','&',PHP_QUERY_RFC3986);
 }
 public static function svg(string $secret,string $username):string {return Qr::svg(Qr::encoder(self::uri($secret,$username)));}
}
