<?php
declare(strict_types=1);
namespace App\Security;
/** RFC 4226 / 6238, SHA-1, six digits, 30-second period. */
final class Totp {
 public static function encode(string $raw):string {$bits='';foreach(str_split($raw) as $c)$bits.=str_pad(decbin(ord($c)),8,'0',STR_PAD_LEFT);$out='';foreach(str_split($bits,5) as $b)$out.='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'[bindec(str_pad($b,5,'0'))];return $out;}
 public static function decode(string $secret):string {
  if(!preg_match('/^[A-Z2-7]{16,128}$/D',$secret))throw new \InvalidArgumentException('Secret TOTP invalide.');
  $bits='';foreach(str_split($secret) as $c)$bits.=str_pad(decbin(strpos('ABCDEFGHIJKLMNOPQRSTUVWXYZ234567',$c)),5,'0',STR_PAD_LEFT);
  $out='';foreach(str_split($bits,8) as $b)if(strlen($b)===8)$out.=chr(bindec($b));return $out;
 }
 public static function code(string $secret,int $step,int $digits=6):string {
  if($step<0||!in_array($digits,[6,8],true))throw new \InvalidArgumentException('Compteur invalide.');
  $h=hash_hmac('sha1',pack('N2',intdiv($step,4294967296),$step%4294967296),self::decode($secret),true);$o=ord($h[19])&15;$n=unpack('N',substr($h,$o,4))[1]&0x7fffffff;
  return str_pad((string)($n%(10**$digits)),$digits,'0',STR_PAD_LEFT);
 }
 public static function match(string $secret,string $code,int $now,int $last=-1):?int {
  if(!preg_match('/^[0-9]{6}$/D',$code))return null;$step=intdiv($now,30);
  foreach([0,-1,1] as $d){$candidate=$step+$d;if($candidate>$last&&hash_equals(self::code($secret,$candidate),$code))return $candidate;}return null;
 }
}
