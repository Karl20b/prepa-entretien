<?php
/*
 * Adapté de QR Code generator library (TypeScript) v1.8.0, Copyright (c) Project Nayuki,
 * licence MIT : voir LICENCE-QR.txt.
 * https://www.nayuki.io/page/qr-code-generator-library
 *
 * Réduit à un seul segment en mode octets, sans relèvement du niveau de correction
 * (boostEcl = false), masque choisi par la pénalité comme dans l'original.
 */

namespace App\Security;

/** Code QR (ISO/IEC 18004) produit sur le serveur, sans WordPress ni ressource externe. */
final class Qr
{
    private const VERSION_MIN = 1;
    private const VERSION_MAX = 40;

    private const PENALITE_N1 = 3;
    private const PENALITE_N2 = 3;
    private const PENALITE_N3 = 40;
    private const PENALITE_N4 = 10;

    /** Niveau => [rang dans les tables, bits de format]. */
    private const NIVEAUX = [
        'L' => [0, 1],
        'M' => [1, 0],
        'Q' => [2, 3],
        'H' => [3, 2],
    ];

    private const ECC_PAR_BLOC = [
        [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
        [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28],
        [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
        [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    ];

    private const NOMBRE_BLOCS = [
        [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25],
        [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49],
        [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68],
        [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81],
    ];

    private int $taille;
    private int $version;
    private int $rang;
    private int $bits_format;
    /** @var list<list<bool>> */
    private array $modules = [];
    /** @var list<list<bool>> */
    private array $fonction = [];

    /**
     * @return list<list<bool>> $m[$y][$x], true = module sombre
     */
    public static function encoder(string $octets, string $niveau = 'M'): array
    {
        if (!isset(self::NIVEAUX[$niveau])) {
            throw new \InvalidArgumentException('Niveau de correction inconnu.');
        }
        [$rang, $bits_format] = self::NIVEAUX[$niveau];
        $longueur = strlen($octets);

        // Plus petite version qui contient les données (mode octets : 4 bits + compteur + 8 bits par octet).
        $version = self::VERSION_MIN;
        while (true) {
            $bits_compteur = $version <= 9 ? 8 : 16;
            $capacite = self::nombre_mots_donnees($version, $rang) * 8;
            $utilises = 4 + $bits_compteur + 8 * $longueur;
            if ($longueur < (1 << $bits_compteur) && $utilises <= $capacite) {
                break;
            }
            if ($version >= self::VERSION_MAX) {
                throw new \LengthException('Données trop longues pour un code QR.');
            }
            $version++;
        }

        $bits = [];
        self::ajouter_bits(0x4, 4, $bits);
        self::ajouter_bits($longueur, $bits_compteur, $bits);
        for ($i = 0; $i < $longueur; $i++) {
            self::ajouter_bits(ord($octets[$i]), 8, $bits);
        }
        // Terminateur, alignement sur l'octet, puis octets de bourrage 0xEC / 0x11.
        self::ajouter_bits(0, min(4, $capacite - count($bits)), $bits);
        self::ajouter_bits(0, (8 - count($bits) % 8) % 8, $bits);
        for ($bourrage = 0xEC; count($bits) < $capacite; $bourrage ^= 0xEC ^ 0x11) {
            self::ajouter_bits($bourrage, 8, $bits);
        }
        $mots = array_fill(0, intdiv(count($bits), 8), 0);
        foreach ($bits as $i => $b) {
            $mots[$i >> 3] |= $b << (7 - ($i & 7));
        }

        $qr = new self($version, $rang, $bits_format, $mots);
        return $qr->modules;
    }

    /** @param list<list<bool>> $matrice */
    public static function svg(array $matrice, int $marge = 4): string
    {
        $n = count($matrice) + 2 * $marge;
        $chemin = '';
        foreach ($matrice as $y => $ligne) {
            foreach ($ligne as $x => $sombre) {
                if ($sombre) {
                    $chemin .= 'M' . ($x + $marge) . ' ' . ($y + $marge) . 'h1v1h-1z';
                }
            }
        }
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $n . ' ' . $n . '" role="img"'
            . ' aria-label="Code QR de configuration" shape-rendering="crispEdges">'
            . '<rect width="' . $n . '" height="' . $n . '" fill="#fff"/>'
            . '<path fill="#000" d="' . $chemin . '"/>'
            . '</svg>';
    }

    /** @param list<int> $mots_donnees */
    private function __construct(int $version, int $rang, int $bits_format, array $mots_donnees)
    {
        $this->version = $version;
        $this->rang = $rang;
        $this->bits_format = $bits_format;
        $this->taille = $version * 4 + 17;
        $ligne = array_fill(0, $this->taille, false);
        $this->modules = array_fill(0, $this->taille, $ligne);
        $this->fonction = array_fill(0, $this->taille, $ligne);

        $this->dessiner_motifs_fonction();
        $this->dessiner_mots($this->ajouter_ecc_et_entrelacer($mots_donnees));

        $masque = 0;
        $minimum = 1000000000;
        for ($i = 0; $i < 8; $i++) {
            $this->appliquer_masque($i);
            $this->dessiner_bits_format($i);
            $penalite = $this->penalite();
            if ($penalite < $minimum) {
                $masque = $i;
                $minimum = $penalite;
            }
            $this->appliquer_masque($i); // le XOR défait le masque
        }
        $this->appliquer_masque($masque);
        $this->dessiner_bits_format($masque);
        $this->fonction = [];
    }

    /** @param list<int> $bits */
    private static function ajouter_bits(int $valeur, int $longueur, array &$bits): void
    {
        for ($i = $longueur - 1; $i >= 0; $i--) {
            $bits[] = ($valeur >> $i) & 1;
        }
    }

    private static function bit(int $x, int $i): bool
    {
        return (($x >> $i) & 1) !== 0;
    }

    private function dessiner_motifs_fonction(): void
    {
        for ($i = 0; $i < $this->taille; $i++) {
            $this->poser(6, $i, $i % 2 === 0);
            $this->poser($i, 6, $i % 2 === 0);
        }
        $this->dessiner_reperage(3, 3);
        $this->dessiner_reperage($this->taille - 4, 3);
        $this->dessiner_reperage(3, $this->taille - 4);

        $positions = $this->positions_alignement();
        $nombre = count($positions);
        for ($i = 0; $i < $nombre; $i++) {
            for ($j = 0; $j < $nombre; $j++) {
                if (!($i === 0 && $j === 0 || $i === 0 && $j === $nombre - 1 || $i === $nombre - 1 && $j === 0)) {
                    $this->dessiner_alignement($positions[$i], $positions[$j]);
                }
            }
        }
        $this->dessiner_bits_format(0);
        $this->dessiner_version();
    }

    private function dessiner_bits_format(int $masque): void
    {
        $donnees = $this->bits_format << 3 | $masque;
        $reste = $donnees;
        for ($i = 0; $i < 10; $i++) {
            $reste = ($reste << 1) ^ (($reste >> 9) * 0x537);
        }
        $bits = ($donnees << 10 | $reste) ^ 0x5412;

        for ($i = 0; $i <= 5; $i++) {
            $this->poser(8, $i, self::bit($bits, $i));
        }
        $this->poser(8, 7, self::bit($bits, 6));
        $this->poser(8, 8, self::bit($bits, 7));
        $this->poser(7, 8, self::bit($bits, 8));
        for ($i = 9; $i < 15; $i++) {
            $this->poser(14 - $i, 8, self::bit($bits, $i));
        }
        for ($i = 0; $i < 8; $i++) {
            $this->poser($this->taille - 1 - $i, 8, self::bit($bits, $i));
        }
        for ($i = 8; $i < 15; $i++) {
            $this->poser(8, $this->taille - 15 + $i, self::bit($bits, $i));
        }
        $this->poser(8, $this->taille - 8, true); // toujours sombre
    }

    private function dessiner_version(): void
    {
        if ($this->version < 7) {
            return;
        }
        $reste = $this->version;
        for ($i = 0; $i < 12; $i++) {
            $reste = ($reste << 1) ^ (($reste >> 11) * 0x1F25);
        }
        $bits = $this->version << 12 | $reste;
        for ($i = 0; $i < 18; $i++) {
            $sombre = self::bit($bits, $i);
            $a = $this->taille - 11 + $i % 3;
            $b = intdiv($i, 3);
            $this->poser($a, $b, $sombre);
            $this->poser($b, $a, $sombre);
        }
    }

    private function dessiner_reperage(int $x, int $y): void
    {
        for ($dy = -4; $dy <= 4; $dy++) {
            for ($dx = -4; $dx <= 4; $dx++) {
                $distance = max(abs($dx), abs($dy));
                $xx = $x + $dx;
                $yy = $y + $dy;
                if (0 <= $xx && $xx < $this->taille && 0 <= $yy && $yy < $this->taille) {
                    $this->poser($xx, $yy, $distance !== 2 && $distance !== 4);
                }
            }
        }
    }

    private function dessiner_alignement(int $x, int $y): void
    {
        for ($dy = -2; $dy <= 2; $dy++) {
            for ($dx = -2; $dx <= 2; $dx++) {
                $this->poser($x + $dx, $y + $dy, max(abs($dx), abs($dy)) !== 1);
            }
        }
    }

    private function poser(int $x, int $y, bool $sombre): void
    {
        $this->modules[$y][$x] = $sombre;
        $this->fonction[$y][$x] = true;
    }

    /**
     * @param list<int> $donnees
     * @return list<int>
     */
    private function ajouter_ecc_et_entrelacer(array $donnees): array
    {
        $blocs_nombre = self::NOMBRE_BLOCS[$this->rang][$this->version];
        $ecc_longueur = self::ECC_PAR_BLOC[$this->rang][$this->version];
        $mots_bruts = intdiv(self::nombre_modules_bruts($this->version), 8);
        $courts = $blocs_nombre - $mots_bruts % $blocs_nombre;
        $longueur_court = intdiv($mots_bruts, $blocs_nombre);

        $diviseur = self::rs_diviseur($ecc_longueur);
        $blocs = [];
        for ($i = 0, $k = 0; $i < $blocs_nombre; $i++) {
            $bloc = array_slice($donnees, $k, $longueur_court - $ecc_longueur + ($i < $courts ? 0 : 1));
            $k += count($bloc);
            $ecc = self::rs_reste($bloc, $diviseur);
            if ($i < $courts) {
                $bloc[] = 0;
            }
            $blocs[] = array_merge($bloc, $ecc);
        }

        $resultat = [];
        $longueur_bloc = count($blocs[0]);
        for ($i = 0; $i < $longueur_bloc; $i++) {
            foreach ($blocs as $j => $bloc) {
                // Saute l'octet de remplissage des blocs courts.
                if ($i !== $longueur_court - $ecc_longueur || $j >= $courts) {
                    $resultat[] = $bloc[$i];
                }
            }
        }
        return $resultat;
    }

    /** @param list<int> $mots */
    private function dessiner_mots(array $mots): void
    {
        $total = count($mots) * 8;
        $i = 0;
        for ($droite = $this->taille - 1; $droite >= 1; $droite -= 2) {
            if ($droite === 6) {
                $droite = 5;
            }
            for ($vert = 0; $vert < $this->taille; $vert++) {
                for ($j = 0; $j < 2; $j++) {
                    $x = $droite - $j;
                    $montant = (($droite + 1) & 2) === 0;
                    $y = $montant ? $this->taille - 1 - $vert : $vert;
                    if (!$this->fonction[$y][$x] && $i < $total) {
                        $this->modules[$y][$x] = self::bit($mots[$i >> 3], 7 - ($i & 7));
                        $i++;
                    }
                }
            }
        }
    }

    private function appliquer_masque(int $masque): void
    {
        for ($y = 0; $y < $this->taille; $y++) {
            for ($x = 0; $x < $this->taille; $x++) {
                switch ($masque) {
                    case 0:
                        $inverser = ($x + $y) % 2 === 0;
                        break;
                    case 1:
                        $inverser = $y % 2 === 0;
                        break;
                    case 2:
                        $inverser = $x % 3 === 0;
                        break;
                    case 3:
                        $inverser = ($x + $y) % 3 === 0;
                        break;
                    case 4:
                        $inverser = (intdiv($x, 3) + intdiv($y, 2)) % 2 === 0;
                        break;
                    case 5:
                        $inverser = $x * $y % 2 + $x * $y % 3 === 0;
                        break;
                    case 6:
                        $inverser = ($x * $y % 2 + $x * $y % 3) % 2 === 0;
                        break;
                    default:
                        $inverser = (($x + $y) % 2 + $x * $y % 3) % 2 === 0;
                }
                if ($inverser && !$this->fonction[$y][$x]) {
                    $this->modules[$y][$x] = !$this->modules[$y][$x];
                }
            }
        }
    }

    private function penalite(): int
    {
        $resultat = 0;
        $n = $this->taille;

        // Suites de même couleur et motifs de type repère, en lignes puis en colonnes.
        for ($sens = 0; $sens < 2; $sens++) {
            for ($a = 0; $a < $n; $a++) {
                $couleur = false;
                $suite = 0;
                $historique = [0, 0, 0, 0, 0, 0, 0];
                for ($b = 0; $b < $n; $b++) {
                    $module = $sens === 0 ? $this->modules[$a][$b] : $this->modules[$b][$a];
                    if ($module === $couleur) {
                        $suite++;
                        if ($suite === 5) {
                            $resultat += self::PENALITE_N1;
                        } elseif ($suite > 5) {
                            $resultat++;
                        }
                    } else {
                        $this->historique_ajouter($suite, $historique);
                        if (!$couleur) {
                            $resultat += $this->compter_motifs($historique) * self::PENALITE_N3;
                        }
                        $couleur = $module;
                        $suite = 1;
                    }
                }
                $resultat += $this->terminer_et_compter($couleur, $suite, $historique) * self::PENALITE_N3;
            }
        }

        // Blocs 2 × 2 de même couleur.
        for ($y = 0; $y < $n - 1; $y++) {
            for ($x = 0; $x < $n - 1; $x++) {
                $c = $this->modules[$y][$x];
                if ($c === $this->modules[$y][$x + 1] && $c === $this->modules[$y + 1][$x] && $c === $this->modules[$y + 1][$x + 1]) {
                    $resultat += self::PENALITE_N2;
                }
            }
        }

        // Équilibre sombre / clair.
        $sombres = 0;
        foreach ($this->modules as $ligne) {
            foreach ($ligne as $module) {
                $sombres += $module ? 1 : 0;
            }
        }
        $total = $n * $n;
        $k = intdiv(abs($sombres * 20 - $total * 10) + $total - 1, $total) - 1; // ceil(|…| / total) - 1
        return $resultat + $k * self::PENALITE_N4;
    }

    /** @param list<int> $historique */
    private function compter_motifs(array $historique): int
    {
        $n = $historique[1];
        $coeur = $n > 0 && $historique[2] === $n && $historique[3] === $n * 3 && $historique[4] === $n && $historique[5] === $n;
        return ($coeur && $historique[0] >= $n * 4 && $historique[6] >= $n ? 1 : 0)
            + ($coeur && $historique[6] >= $n * 4 && $historique[0] >= $n ? 1 : 0);
    }

    /** @param list<int> $historique */
    private function terminer_et_compter(bool $couleur, int $suite, array &$historique): int
    {
        if ($couleur) {
            $this->historique_ajouter($suite, $historique);
            $suite = 0;
        }
        $suite += $this->taille; // bordure claire après la dernière suite
        $this->historique_ajouter($suite, $historique);
        return $this->compter_motifs($historique);
    }

    /** @param list<int> $historique */
    private function historique_ajouter(int $suite, array &$historique): void
    {
        if ($historique[0] === 0) {
            $suite += $this->taille; // bordure claire avant la première suite
        }
        array_pop($historique);
        array_unshift($historique, $suite);
    }

    /** @return list<int> */
    private function positions_alignement(): array
    {
        if ($this->version === 1) {
            return [];
        }
        $nombre = intdiv($this->version, 7) + 2;
        $pas = $this->version === 32 ? 26
            : intdiv($this->version * 4 + 4 + ($nombre * 2 - 2) - 1, $nombre * 2 - 2) * 2; // ceil(…) * 2
        $resultat = [6];
        for ($pos = $this->taille - 7; count($resultat) < $nombre; $pos -= $pas) {
            array_splice($resultat, 1, 0, [$pos]);
        }
        return $resultat;
    }

    private static function nombre_modules_bruts(int $version): int
    {
        $resultat = (16 * $version + 128) * $version + 64;
        if ($version >= 2) {
            $nombre = intdiv($version, 7) + 2;
            $resultat -= (25 * $nombre - 10) * $nombre - 55;
            if ($version >= 7) {
                $resultat -= 36;
            }
        }
        return $resultat;
    }

    private static function nombre_mots_donnees(int $version, int $rang): int
    {
        return intdiv(self::nombre_modules_bruts($version), 8)
            - self::ECC_PAR_BLOC[$rang][$version] * self::NOMBRE_BLOCS[$rang][$version];
    }

    /** @return list<int> */
    private static function rs_diviseur(int $degre): array
    {
        $resultat = array_fill(0, $degre, 0);
        $resultat[$degre - 1] = 1;
        $racine = 1;
        for ($i = 0; $i < $degre; $i++) {
            for ($j = 0; $j < $degre; $j++) {
                $resultat[$j] = self::rs_multiplier($resultat[$j], $racine);
                if ($j + 1 < $degre) {
                    $resultat[$j] ^= $resultat[$j + 1];
                }
            }
            $racine = self::rs_multiplier($racine, 0x02);
        }
        return $resultat;
    }

    /**
     * @param list<int> $donnees
     * @param list<int> $diviseur
     * @return list<int>
     */
    private static function rs_reste(array $donnees, array $diviseur): array
    {
        $resultat = array_fill(0, count($diviseur), 0);
        foreach ($donnees as $octet) {
            $facteur = $octet ^ array_shift($resultat);
            $resultat[] = 0;
            foreach ($diviseur as $i => $coef) {
                $resultat[$i] ^= self::rs_multiplier($coef, $facteur);
            }
        }
        return $resultat;
    }

    /** Produit dans GF(2^8) modulo x^8 + x^4 + x^3 + x^2 + 1. */
    private static function rs_multiplier(int $x, int $y): int
    {
        $z = 0;
        for ($i = 7; $i >= 0; $i--) {
            $z = ($z << 1) ^ (($z >> 7) * 0x11D);
            $z ^= (($y >> $i) & 1) * $x;
        }
        return $z;
    }
}
