<?php
declare(strict_types=1);
namespace App\Security;
use PDO;
final class Login {
 public static function enabled():bool{return (bool)\config('security.mfa_required',false);}
 public static function expired(array $a,?int $now=null):bool {$days=(int)\config('security.password_days',90);return $days>0&&((int)($a['password_changed_at']??0)<=0||($now??time())-(int)$a['password_changed_at']>=$days*86400);}
 public static function begin(PDO $p,string $user):never {
  if(!self::enabled())\App\Auth::finish($p,$user);
  $a=(new \App\Repo\AccountRepo($p))->find($user);if(!$a||!$a['active'])throw new \RuntimeException('Compte indisponible.');
  $q=$p->prepare('SELECT enabled FROM pe_mfa WHERE username=?');$q->execute([$user]);$ttl=$q->fetchColumn()?300:900;
  session_regenerate_id(true);$_SESSION=['preauth'=>['user'=>$user,'version'=>(int)$a['auth_version'],'expires'=>time()+$ttl,'factor'=>false],'csrf'=>bin2hex(random_bytes(32))];\redirect('index.php?action=security');
 }
 public static function gate(PDO $p,array $a):void {
  if(!self::enabled())return;
  if(empty($_SESSION['mfa_ok'])){$_SESSION=[];session_regenerate_id(true);\redirect('index.php');}
  if(self::expired($a)){self::begin($p,$a['username']);}
 }
 public static function audit(PDO $p,string $user,string $event):void {$p->prepare('INSERT INTO pe_security_audit(username,event,created_at) VALUES(?,?,?)')->execute([$user,$event,time()]);}
 public static function factor(PDO $p,string $user,string $code,?string $enrol=null,?int $version=null):array {
  $p->exec('BEGIN IMMEDIATE');
  try {
   $account=(new \App\Repo\AccountRepo($p))->find($user);if(!$account||!$account['active']||($version!==null&&(int)$account['auth_version']!==$version))throw new \InvalidArgumentException('Compte ou authentification périmés.');
   $q=$p->prepare('SELECT * FROM pe_mfa WHERE username=?');$q->execute([$user]);$row=$q->fetch();
   if(!$row){$p->prepare('INSERT INTO pe_mfa(username) VALUES(?)')->execute([$user]);$row=['enabled'=>0,'last_step'=>-1,'failures'=>0,'blocked_until'=>0];}
   if((int)$row['blocked_until']>time())throw new \InvalidArgumentException('Trop de codes incorrects. Réessayez dans dix minutes.');
   $codes=[];$step=null;$ok=false;
   if($row['enabled']){
    $secret=Vault::open($row['secret'],'totp:'.$user);$step=Totp::match($secret,$code,time(),(int)$row['last_step']);$ok=$step!==null;
    if(!$ok&&preg_match('/^[a-f0-9]{32}$/D',$code)){$q=$p->prepare('DELETE FROM pe_recovery WHERE username=? AND hash=?');$q->execute([$user,hash('sha256',$code)]);$ok=$q->rowCount()===1;}
   }elseif($enrol!==null){$step=Totp::match($enrol,$code,time());$ok=$step!==null;}
   if(!$ok){$fail=(int)$row['failures']+1;$p->prepare('UPDATE pe_mfa SET failures=?,blocked_until=? WHERE username=?')->execute([$fail>=5?0:$fail,$fail>=5?time()+600:0,$user]);self::audit($p,$user,'factor_failed');$p->exec('COMMIT');throw new \InvalidArgumentException('Code invalide, déjà utilisé ou expiré.');}
   if(!$row['enabled']){
    if($enrol===null)throw new \RuntimeException('Inscription absente.');
    $p->prepare('UPDATE pe_mfa SET secret=?,enabled=1 WHERE username=? AND enabled=0')->execute([Vault::seal($enrol,'totp:'.$user,true),$user]);
    for($i=0;$i<8;$i++){$c=bin2hex(random_bytes(16));$codes[]=$c;$p->prepare('INSERT INTO pe_recovery(username,hash) VALUES(?,?)')->execute([$user,hash('sha256',$c)]);}
   }
   $p->prepare('UPDATE pe_mfa SET failures=0,blocked_until=0,last_step=MAX(last_step,?) WHERE username=?')->execute([$step??-1,$user]);self::audit($p,$user,$row['enabled']?'factor_verified':'factor_enrolled');$p->exec('COMMIT');return $codes;
  }catch(\Throwable $e){if($p->inTransaction())$p->exec('ROLLBACK');throw $e;}
 }
 public static function password(PDO $p,string $user,string $current,string $new,string $confirmation):void {
  if(mb_strlen($new)<14||strlen($new)>1024||$new!==$confirmation)throw new \InvalidArgumentException('Confirmez un mot de passe d’au moins 14 caractères.');
  $p->exec('BEGIN IMMEDIATE');
  try {
   $a=(new \App\Repo\AccountRepo($p))->find($user);if(!$a||!$a['active']||!password_verify($current,$a['password_hash']))throw new \InvalidArgumentException('Mot de passe actuel incorrect.');
   $q=$p->prepare('SELECT hash FROM pe_password_history WHERE username=? ORDER BY rowid DESC LIMIT 5');$q->execute([$user]);$hashes=[$a['password_hash'],...$q->fetchAll(PDO::FETCH_COLUMN)];foreach($hashes as $h)if(password_verify($new,$h))throw new \InvalidArgumentException('Choisissez un mot de passe différent des cinq derniers.');
   $p->prepare('INSERT INTO pe_password_history(username,hash,created_at) VALUES(?,?,?)')->execute([$user,$a['password_hash'],time()]);
   $p->prepare('DELETE FROM pe_password_history WHERE username=? AND rowid NOT IN (SELECT rowid FROM pe_password_history WHERE username=? ORDER BY rowid DESC LIMIT 4)')->execute([$user,$user]);
   $p->prepare('UPDATE pe_accounts SET password_hash=?,password_changed_at=?,auth_version=auth_version+1,updated_at=? WHERE username=?')->execute([password_hash($new,PASSWORD_DEFAULT),time(),time(),$user]);
   $p->prepare('DELETE FROM pe_account_tokens WHERE username=?')->execute([$user]);self::audit($p,$user,'password_changed');$p->exec('COMMIT');
  }catch(\Throwable $e){if($p->inTransaction())$p->exec('ROLLBACK');throw $e;}
 }
 public static function route(PDO $p):never {
  if(!self::enabled())\redirect('index.php');
  $state=&$_SESSION['preauth'];
  if(!is_array($state)||($state['expires']??0)<time()){$_SESSION=[];session_regenerate_id(true);\redirect('index.php');}
  $a=(new \App\Repo\AccountRepo($p))->find($state['user']);
  if(!$a||!$a['active']||(int)$a['auth_version']!==$state['version']){$_SESSION=[];session_regenerate_id(true);\redirect('index.php');}
  $q=$p->prepare('SELECT enabled FROM pe_mfa WHERE username=?');$q->execute([$a['username']]);$enabled=(bool)$q->fetchColumn();
  $error='';$codes=$state['codes']??[];
  if(!$enabled&&empty($state['secret']))$state['secret']=Totp::encode(random_bytes(20));
  $stage=empty($state['factor'])?($enabled?'verify':'enrol'):($codes?'recovery':(self::expired($a)?'password':'done'));
  if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){
   \csrf_check();
   try {
    $op=(string)($_POST['operation']??'');
    if(in_array($stage,['verify','enrol'],true)&&$op==='factor'){$state['codes']=self::factor($p,$a['username'],trim((string)($_POST['code']??'')),$enabled?null:$state['secret'],$state['version']);$state['factor']=true;$state['expires']=time()+300;unset($state['secret']);session_regenerate_id(true);}
    elseif($stage==='recovery'&&$op==='saved'&&!empty($_POST['saved']))unset($state['codes']);
    elseif($stage==='password'&&$op==='password'){self::password($p,$a['username'],(string)($_POST['current']??''),(string)($_POST['password']??''),(string)($_POST['confirmation']??''));$state['version']++;}
    else throw new \InvalidArgumentException('Action invalide.');
    \redirect('index.php?action=security');
   }catch(\InvalidArgumentException $e){$error=$e->getMessage();}
  }
  if($stage==='done'){\App\Auth::finish($p,$a['username'],true,$state['version']);}
  \render('security',['stage'=>$stage,'error'=>$error,'codes'=>$codes,'secret'=>$stage==='enrol'?$state['secret']:'','account'=>$a],'Sécurité du compte');exit;
 }
}
