<?php
declare(strict_types=1);
namespace App\Security;
use PDO;
/** Offline migration under the application's exclusive maintenance lock. */
final class Migration {
 public static function run(string $root,string $private,string $db,?callable $ready=null):array {
  if(!is_dir($private)||!is_file($db)||is_link($db))throw new \RuntimeException('Stockage privé invalide.');
  $lock=fopen($private.'/security-maintenance.lock','c+');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB))throw new \RuntimeException('Une requête est en cours : réessayez après sa fin.');
  $stamp=gmdate('YmdHis').'-'.bin2hex(random_bytes(4));$stage=$private.'/security-'.$stamp.'.sqlite';$backup=$private.'/security-backup-'.$stamp.'.pe1';
  try {
   $source=new PDO('sqlite:'.$db,null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);$source->exec('PRAGMA busy_timeout=5000; PRAGMA wal_checkpoint(TRUNCATE);');if($source->query('PRAGMA journal_mode=DELETE')->fetchColumn()!=='delete')throw new \RuntimeException('Journal SQLite actif : migration refusée.');
   $source->exec('VACUUM INTO '.$source->quote($stage));$source=null;chmod($stage,0600);
   $raw=(string)file_get_contents($stage);$sealed=Vault::seal($raw,'backup:sqlite',true);if(Vault::open($sealed,'backup:sqlite')!==$raw)throw new \RuntimeException('Sauvegarde non vérifiée.');
   self::atomic($backup,$sealed);unset($raw,$sealed);
   $class=class_exists('Pdo\\Sqlite')?'Pdo\\Sqlite':PDO::class;$p=new $class('sqlite:'.$stage,null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);$p->exec('PRAGMA secure_delete=ON; PRAGMA journal_mode=DELETE;');$count=0;
   $function=method_exists($p,'createFunction')?'createFunction':'sqliteCreateFunction';$p->$function('PE_VALID_CIPHER',fn($v,$s)=>Vault::valid($v,$s),2);
   $p->beginTransaction();
   foreach(Vault::FIELDS as $table=>$fields){
    $rows=$p->query('SELECT rowid AS _rowid,* FROM '.$table)->fetchAll();
    foreach($rows as $row){$values=[];$set=[];foreach($fields as $field){$value=$row[$field];$scope=$table.'.'.$field;if($value!==null){if(str_starts_with($value,'pe1:'))Vault::open($value,$scope);else $value=Vault::seal($value,$scope,true);$set[]=$field.'=?';$values[]=$value;}}
     if($set){$values[]=$row['_rowid'];$p->prepare('UPDATE '.$table.' SET '.implode(',',$set).' WHERE rowid=?')->execute($values);$count++;}
    }
   }
   self::guards($p);$p->commit();$p->exec('VACUUM');if($p->query('PRAGMA integrity_check')->fetchColumn()!=='ok')throw new \RuntimeException('Intégrité SQLite invalide.');$p=null;
   // Every source text and private original is sealed, not only its RAG copy.
   $files=[];foreach(['docs_seed','fiches/textes','fiches/photos','reference-data/originals','sources_originales'] as $dir)if(is_dir($root.'/'.$dir))foreach(new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root.'/'.$dir,\FilesystemIterator::SKIP_DOTS)) as $f)if($f->isFile()&&!$f->isLink())$files[]=$f->getPathname();
   if(is_file($root.'/reference-data/documents.json'))$files[]=$root.'/reference-data/documents.json';
   $fileCount=0;foreach($files as $file){$bytes=(string)file_get_contents($file);$scope='file:'.basename($file);if(str_starts_with($bytes,'pe1:')){Vault::open($bytes,$scope);continue;}$box=Vault::seal($bytes,$scope,true);if(Vault::open($box,$scope)!==$bytes)throw new \RuntimeException('Fichier non vérifié.');self::atomic($file,$box);$fileCount++;}
   foreach(glob($private.'/sessions/sess_*')?:[] as $file){if(is_link($file))throw new \RuntimeException('Session invalide.');$raw=(string)file_get_contents($file);if($raw!==''&&!str_starts_with($raw,'pe1:'))self::atomic($file,(string)Vault::seal($raw,'session:'.substr(basename($file),5),true));}
   // Previous backups and test artefacts in var can contain the same sensitive data.
   foreach(new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($private,\FilesystemIterator::SKIP_DOTS)) as $f){
    if(!$f->isFile()||$f->isLink())continue;$file=$f->getPathname();$relative=substr($file,strlen($private)+1);
    if(in_array($file,[$db,$stage,$backup],true)||in_array($relative,['security-maintenance.lock','security-ready','security-state.json'],true)||preg_match('~^(sessions|stt-limits|preparation-limits)/~',$relative)||in_array($file,[$db.'-wal',$db.'-shm',$db.'-journal'],true))continue;
    $raw=(string)file_get_contents($file);if(str_starts_with($raw,'pe1:')){Vault::open($raw);continue;}self::atomic($file,(string)Vault::seal($raw,'file:'.basename($file),true));$fileCount++;
   }
   if(!rename($stage,$db))throw new \RuntimeException('Remplacement SQLite impossible.');chmod($db,0600);
   self::atomic($private.'/security-ready','v1');if($ready)$ready();return ['status'=>'passed','encrypted_rows'=>$count,'encrypted_files'=>$fileCount,'backup'=>basename($backup),'backup_verified'=>true,'sqlite_integrity'=>'ok'];
  }finally{if(is_file($stage))unlink($stage);flock($lock,LOCK_UN);fclose($lock);}
 }
 public static function guards(PDO $p):void {
  foreach(Vault::FIELDS as $table=>$fields){$bad=[];foreach($fields as $f)$bad[]="PE_VALID_CIPHER(NEW.$f,'$table.$f')<>1";$when=implode(' OR ',$bad);
   foreach(['INSERT','UPDATE'] as $event)$p->exec("CREATE TRIGGER IF NOT EXISTS protect_{$table}_$event BEFORE $event ON $table WHEN $when BEGIN SELECT RAISE(ABORT,'Protected value must be encrypted'); END");
  }
  foreach(['INSERT','UPDATE'] as $event)$p->exec("CREATE TRIGGER IF NOT EXISTS protect_totp_$event BEFORE $event ON pe_mfa WHEN NEW.enabled=1 AND (NEW.secret IS NULL OR PE_VALID_CIPHER(NEW.secret,'totp:'||NEW.username)<>1) BEGIN SELECT RAISE(ABORT,'Protected factor must be encrypted'); END");
 }
 public static function atomic(string $file,string $bytes):void {
  $tmp=$file.'.'.bin2hex(random_bytes(8)).'.tmp';$h=fopen($tmp,'x+b');if(!$h)throw new \RuntimeException('Écriture privée indisponible.');chmod($tmp,0600);
  try{$len=strlen($bytes);$offset=0;while($offset<$len){$n=fwrite($h,substr($bytes,$offset));if(!$n)throw new \RuntimeException('Écriture incomplète.');$offset+=$n;}fflush($h);if(function_exists('fsync'))fsync($h);}finally{fclose($h);}
  if(!rename($tmp,$file)){unlink($tmp);throw new \RuntimeException('Écriture atomique impossible.');}
 }
}
