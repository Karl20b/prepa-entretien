<?php
declare(strict_types=1);
namespace App\Security;
/** Native file locking and strict-session validation retained by SessionHandler. */
final class EncryptedSession extends \SessionHandler implements \SessionUpdateTimestampHandlerInterface {
 public function read(string $id):string|false {$raw=parent::read($id);if($raw===false||$raw==='')return $raw;return Vault::open($raw,'session:'.$id);}
 public function write(string $id,string $data):bool {return parent::write($id,(string)Vault::seal($data,'session:'.$id));}
 public function validateId(string $id):bool {$path=(string)\config('app.private_dir').'/sessions/sess_'.$id;return preg_match('/^[a-zA-Z0-9,-]{1,128}$/D',$id)===1&&is_file($path)&&!is_link($path);}
 public function updateTimestamp(string $id,string $data):bool {return $this->write($id,$data);}
}
