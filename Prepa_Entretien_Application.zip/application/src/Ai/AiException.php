<?php
declare(strict_types=1);

namespace App\Ai;

final class AiException extends \RuntimeException {}
