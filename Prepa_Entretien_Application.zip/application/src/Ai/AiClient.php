<?php
declare(strict_types=1);

namespace App\Ai;

interface AiClient
{
    /**
     * @param list<array{role:'user'|'assistant',content:string}> $messages
     * @throws AiException
     */
    public function chat(string $system, array $messages): string;

    /** Libellé fournisseur/modèle, stocké avec chaque réponse pour la traçabilité. */
    public function name(): string;
}
