<?php
declare(strict_types=1);

namespace App\Ai;

/**
 * Fournisseur fictif (ai.provider = 'demo') : permet de tester l'application
 * et le RAG sans clé API. Renvoie les sources reçues au lieu d'une vraie réponse.
 */
final class DemoClient implements AiClient
{
    public function chat(string $system, array $messages): string
    {
        $last = end($messages)['content'] ?? '';
        preg_match_all('/^\[(S\d+)\] (.+)$/mu', $last, $m, PREG_SET_ORDER);
        $out = "## Mode démonstration\n\nAucun appel à une IA n'a été fait. Voici les extraits que le RAG aurait transmis :\n\n";
        foreach ($m as $hit) {
            $out .= "- [{$hit[1]}] {$hit[2]}\n";
        }
        if ($m === []) {
            $out .= "- *(aucun extrait trouvé — alimentez la base documentaire)*\n";
        }
        return $out . "\nConfigurez `ai.provider` et une clé API dans `config/config.php` pour obtenir une vraie préparation.";
    }

    public function name(): string
    {
        return 'demo';
    }
}
