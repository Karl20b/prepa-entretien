<?php
declare(strict_types=1);

namespace App\Ai;

/** Toute API au format « chat/completions » (Infomaniak AI Tools, Mistral, Azure, Ollama…). */
final class OpenAiCompatibleClient implements AiClient
{
    public function __construct(
        private readonly string $endpoint,
        private readonly string $apiKey,
        private readonly string $model,
        private readonly int $maxTokens,
        private readonly int $timeout,
        private readonly ?float $temperature = null,
    ) {}

    public function chat(string $system, array $messages): string
    {
        $body = [
            'model'      => $this->model,
            'max_tokens' => $this->maxTokens,
            'messages'   => [['role' => 'system', 'content' => $system], ...$messages],
        ];
        if ($this->temperature !== null) {
            $body['temperature'] = $this->temperature;
        }

        $data = Http::postJson($this->endpoint, ['Authorization: Bearer ' . $this->apiKey], $body, $this->timeout);

        $text = (string) ($data['choices'][0]['message']['content'] ?? '');
        if ($text === '') {
            throw new AiException('Réponse IA vide.');
        }
        if (($data['choices'][0]['finish_reason'] ?? '') === 'length') {
            $text .= "\n\n*(Réponse tronquée : augmenter ai.max_tokens dans la configuration.)*";
        }
        return $text;
    }

    public function name(): string
    {
        return 'openai_compatible:' . $this->model;
    }
}
