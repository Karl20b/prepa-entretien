<?php
declare(strict_types=1);
namespace App\Ai;
final class Http {
 public static function postJson(string $url,array $headers,array $body,int $timeout):array {
  if(parse_url($url,PHP_URL_SCHEME)!=='https' || parse_url($url,PHP_URL_HOST)!=='api.infomaniak.com') throw new AiException('Adresse du service IA invalide.');
  $ch=curl_init($url);
  curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>$timeout,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_HTTPHEADER=>array_merge(['Content-Type: application/json','Accept: application/json'],$headers),CURLOPT_POSTFIELDS=>json_encode($body,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)]);
  $raw=curl_exec($ch); $status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); curl_close($ch);
  if($raw===false) throw new AiException('Le service IA est injoignable. Votre situation reste enregistrée ; réessayez plus tard.');
  $data=json_decode($raw,true);
  if($status<200 || $status>=300 || !is_array($data)) throw new AiException('Le service IA n’a pas pu répondre (HTTP '.$status.'). Votre situation reste enregistrée.');
  return $data;
 }
}
