<?php
declare(strict_types=1);

namespace App\Ai;

final class AiFactory
{
    public static function make(): AiClient
    {
        $provider = (string) config('ai.provider', 'anthropic');
        if ($provider === 'demo') {
            return new DemoClient();
        }
        $c = config('ai.' . $provider);
        if (!is_array($c) || empty($c['api_key'])) {
            throw new AiException("Fournisseur IA « {$provider} » non configuré (clé API manquante dans config.php).");
        }
        $temperature = config('ai.temperature');
        $args = [
            (string) $c['endpoint'],
            (string) $c['api_key'],
            (string) $c['model'],
            (int) config('ai.max_tokens', 4000),
            (int) config('ai.timeout', 120),
            $temperature === null ? null : (float) $temperature,
        ];

        return match ($provider) {
            'anthropic'         => new AnthropicClient(...$args),
            'openai_compatible' => new OpenAiCompatibleClient(...$args),
            default             => throw new AiException("Fournisseur IA inconnu : {$provider}"),
        };
    }
}
