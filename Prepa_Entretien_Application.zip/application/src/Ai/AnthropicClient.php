<?php
declare(strict_types=1);

namespace App\Ai;

/** API Messages d'Anthropic (Claude). */
final class AnthropicClient implements AiClient
{
    public function __construct(
        private readonly string $endpoint,
        private readonly string $apiKey,
        private readonly string $model,
        private readonly int $maxTokens,
        private readonly int $timeout,
        private readonly ?float $temperature = null,
    ) {}

    public function chat(string $system, array $messages): string
    {
        $body = [
            'model'      => $this->model,
            'max_tokens' => $this->maxTokens,
            'system'     => $system,
            'messages'   => $messages,
        ];
        if ($this->temperature !== null) {
            $body['temperature'] = $this->temperature;
        }

        $data = Http::postJson($this->endpoint, [
            'x-api-key: ' . $this->apiKey,
            'anthropic-version: 2023-06-01',
        ], $body, $this->timeout);

        $text = '';
        foreach ($data['content'] ?? [] as $block) {
            if (($block['type'] ?? '') === 'text') {
                $text .= $block['text'];
            }
        }
        if ($text === '') {
            throw new AiException('Réponse IA vide.');
        }
        if (($data['stop_reason'] ?? '') === 'max_tokens') {
            $text .= "\n\n*(Réponse tronquée : augmenter ai.max_tokens dans la configuration.)*";
        }
        return $text;
    }

    public function name(): string
    {
        return 'anthropic:' . $this->model;
    }
}
