<?php
declare(strict_types=1);
namespace App\Reference;
use PDO;
final class Sources {
 public function __construct(private readonly PDO $pdo){}
 public function search(array $s,string $query,int $limit,array $categories=[]):array {
  $generic=(new \App\Rag\FulltextRetriever($this->pdo))->search($query,$limit,$categories);
  $role=RoleCatalog::get($s['cdc_role']??null);if(!$role)return $generic;
  $st=$this->pdo->prepare("SELECT c.id,c.contenu,d.titre,d.categorie,d.source FROM pe_chunks c JOIN pe_documents d ON d.id=c.document_id JOIN pe_reference_docs r ON r.document_id=d.id WHERE d.actif=1 AND r.resource='cdc' AND r.profile=? ORDER BY d.id,c.ordre");$st->execute([$role['scope']]);$cdc=$st->fetchAll();
  foreach($cdc as &$c){$c['id']=(int)$c['id'];$c['score']=1.0;}unset($c);
  $a=$this->pdo->query("SELECT c.id,c.contenu,d.titre,d.categorie,d.source FROM pe_chunks c JOIN pe_documents d ON d.id=c.document_id JOIN pe_reference_docs r ON r.document_id=d.id WHERE d.actif=1 AND r.source_key='annual-preparation' ORDER BY c.ordre")->fetchAll();
  foreach($a as &$c){$c['id']=(int)$c['id'];$c['score']=1.0;}unset($c);
  $seen=array_fill_keys(array_column([...$cdc,...$a],'id'),true);$generic=array_values(array_filter($generic,static fn($c)=>!isset($seen[$c['id']])));
  // Toutes les pages actives du seul CDC choisi précèdent les compléments de méthode.
  return [...$cdc,...$a,...array_slice($generic,0,3)];
 }
}
