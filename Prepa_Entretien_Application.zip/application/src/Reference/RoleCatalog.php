<?php
declare(strict_types=1);
namespace App\Reference;
final class RoleCatalog {
 public static function all():array {return json_decode(file_get_contents(APP_ROOT.'/reference-data/roles.json'),true,16,JSON_THROW_ON_ERROR);}
 public static function clean(mixed $role):?string {
  if($role===null||$role==='')return null;
  if(!is_string($role)||!array_key_exists($role,self::all()))throw new \InvalidArgumentException('Choisissez un rôle disposant d’un CDC dans la liste, ou « Sans CDC associé ».');
  return $role;
 }
 public static function get(?string $role):?array {return $role===null||$role===''?null:(self::all()[$role]??null);}
 public static function block(array $s):string {
  $r=self::get($s['cdc_role']??null);
  if(!$r)return 'Aucun CDC sélectionné : ne déduis pas un cahier des charges du grade ou de la fonction libre. Demande au cadre le référentiel applicable si nécessaire.';
  return 'Rôle explicitement choisi : '.$r['label'].' (niveau indiqué dans le document : '.$r['level'].'). CDC : '.$r['file'].'. Version : '.$r['version'].'. Si aucun extrait actif du CDC n’est fourni, signale explicitement son indisponibilité et ne reconstruis pas ses exigences de mémoire. Le cadre doit confirmer que cette version correspond au poste et à l’affectation. Utilise uniquement le CDC choisi parmi les sources, jamais les exigences d’un autre rôle. Ne transforme pas « peut être appelé », « sur ordre », « sous conduite » ou « souhaité » en obligation permanente. Le niveau d’autonomie et les responsabilités doivent rester ceux du texte. Le CDC décrit des attentes, pas la performance réelle de la personne. Prépare des questions et des éléments observables, sans attribuer de note A/B/C/D, de diagnostic, de décision de promotion ni d’appréciation automatique. Les exigences médicales ou physiques du modèle ne permettent aucune inférence sur la santé d’une personne.';
 }
 public static function serve():never {
  if(!in_array($_SERVER['REQUEST_METHOD']??'GET',['GET','HEAD'],true)){http_response_code(405);exit;}
  $key=(string)($_GET['file']??'');$files=[];
  foreach(self::all() as $role=>$r)$files[$role]=$r['file'];
  if(!isset($files[$key]))not_found();$f=APP_ROOT.'/reference-data/originals/'.$files[$key];if(!is_file($f))not_found();
  header('Content-Type: '.match(strtolower(pathinfo($f,PATHINFO_EXTENSION))){'pdf'=>'application/pdf','xlsx'=>'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',default=>'text/plain; charset=utf-8'});
  $bytes=\App\Security\Vault::read($f);header('Content-Length: '.strlen($bytes));header('Content-Disposition: attachment; filename="'.basename($f).'"');session_write_close();
  if(($_SERVER['REQUEST_METHOD']??'GET')!=='HEAD')print($bytes);exit;
 }
}
