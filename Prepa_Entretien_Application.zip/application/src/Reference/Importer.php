<?php
declare(strict_types=1);
namespace App\Reference;
use PDO;
final class Importer {
 public static function run(PDO $pdo,string $actor='import-references'):array {
  $docs=json_decode(file_get_contents(APP_ROOT.'/reference-data/documents.json'),true,32,JSON_THROW_ON_ERROR);$count=0;$chunks=0;
  $index=new \App\Rag\DocumentIndexer($pdo,new \App\Rag\Chunker(1200,200));$pdo->beginTransaction();
  try{
   foreach($docs as $d){
    $q=$pdo->prepare('SELECT document_id FROM pe_reference_docs WHERE source_key=?');$q->execute([$d['key']]);$id=$q->fetchColumn();
    if($id){$pdo->prepare('UPDATE pe_documents SET titre=?,categorie=?,source=?,contenu=?,updated_at=NOW() WHERE id=?')->execute([$d['title'],$d['category'],$d['source'],$d['text'],$id]);}
    else{$pdo->prepare('INSERT INTO pe_documents(titre,categorie,source,contenu,created_by) VALUES(?,?,?,?,?)')->execute([$d['title'],$d['category'],$d['source'],$d['text'],$actor]);$id=(int)$pdo->lastInsertId();$pdo->prepare('INSERT INTO pe_reference_docs(document_id,source_key,resource,profile,page) VALUES(?,?,?,?,?)')->execute([$id,$d['key'],$d['resource'],$d['profile'],$d['page']]);}
    $chunks+=$index->index((int)$id);$count++;
   }
   $pdo->commit();return ['documents'=>$count,'chunks'=>$chunks];
  }catch(\Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
 }
}
