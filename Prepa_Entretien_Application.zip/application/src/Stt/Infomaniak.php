<?php
declare(strict_types=1);
namespace App\Stt;
final class Infomaniak {
 private string $base; private string $key;
 public function __construct(array $cfg, private mixed $transport=null) {
  $endpoint=(string)($cfg['ai']['openai_compatible']['endpoint']??'');
  if(!preg_match('~^https://api\.infomaniak\.com/2/ai/([0-9]+)/openai/v1/chat/completions/?$~D',$endpoint,$m))throw new \RuntimeException('La connexion au service de transcription doit être configurée.');
  $this->base='https://api.infomaniak.com/1/ai/'.$m[1];$this->key=(string)($cfg['ai']['openai_compatible']['api_key']??'');
  if($this->key==='')throw new \RuntimeException('Le service de transcription est indisponible.');
 }
 public function submit(string $path,string $mime):string {
  $json=$this->request('/openai/audio/transcriptions',['file'=>new \CURLFile($path,$mime,'dictee.'.($mime==='audio/mp4'?'m4a':($mime==='audio/wav'?'wav':'webm'))),'model'=>'whisper','language'=>'fr','response_format'=>'json']);
  $id=$json['batch_id']??null;
  if(!is_string($id)||!preg_match('/^[a-zA-Z0-9_-]{1,200}$/D',$id))throw new \RuntimeException('Réponse de transcription inattendue.');return $id;
 }
 public function poll(string $id):array {
  if(!preg_match('/^[a-zA-Z0-9_-]{1,200}$/D',$id))throw new \RuntimeException('Référence invalide.');
  $j=$this->request('/results/'.rawurlencode($id));$status=$j['status']??'';
  if(in_array($status,['pending','queued','processing','running','submitted'],true))return ['status'=>'pending'];
  if(!in_array($status,['completed','success','succeeded','done'],true))throw new \RuntimeException('La transcription n’a pas abouti. Vous pouvez saisir le texte manuellement.');
  $data=$j['data']??null;if(is_string($data)){$parsed=json_decode($data,true);$data=is_array($parsed)?$parsed:['text'=>$data];}
  $text=is_array($data)?($data['text']??''):'';
  if(!is_string($text)||trim($text)===''||strlen($text)>100000)throw new \RuntimeException('Aucun texte exploitable. Vérifiez la prise de son.');
  return ['status'=>'completed','text'=>trim($text)];
 }
 private function request(string $path,?array $payload=null):array {
  if($this->transport)return ($this->transport)($path,$payload);
  $ch=curl_init($this->base.$path);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$this->key,'Accept: application/json'],CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>60,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS]);
  if($payload!==null)curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$payload]);
  $body=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_close($ch);
  if(!is_string($body)||$code<200||$code>=300)throw new \RuntimeException('Le service de transcription est momentanément indisponible. Aucune nouvelle transmission automatique ne sera faite.');
  $j=json_decode($body,true);if(!is_array($j))throw new \RuntimeException('Réponse du service de transcription illisible.');return $j;
 }
}
