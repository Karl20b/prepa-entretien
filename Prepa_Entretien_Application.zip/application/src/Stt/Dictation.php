<?php
declare(strict_types=1);
namespace App\Stt;
final class Dictation {
 public const FIELDS=['contexte','faits','objectif_manager','enjeux'];
 public const MAX_BYTES=8388608;
 public static function validateAudio(array $file):string {
  $path=(string)($file['tmp_name']??'');
  if(($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK||!is_file($path))throw new \InvalidArgumentException('Audio absent ou trop volumineux (8 Mo maximum).');
  $size=filesize($path);if($size<12||$size>self::MAX_BYTES)throw new \InvalidArgumentException('Audio vide ou trop volumineux (8 Mo maximum).');
  $header=file_get_contents($path,false,null,0,16);
  if(substr($header,0,4)==="\x1a\x45\xdf\xa3")return 'audio/webm';
  if(substr($header,4,4)==='ftyp')return 'audio/mp4';
  if(substr($header,0,4)==='RIFF'&&substr($header,8,4)==='WAVE')return 'audio/wav';
  throw new \InvalidArgumentException('Format audio non reconnu. Utilisez un navigateur récent.');
 }
 public static function submit(array &$state,string $user,string $field,string $nonce,array $file,Infomaniak $engine,callable $reserve):array {
  $path=(string)($file['tmp_name']??'');
  try {
   if(!in_array($field,self::FIELDS,true)||!preg_match('/^[a-f0-9]{32}$/D',$nonce))throw new \InvalidArgumentException('Champ ou prise audio invalide.');
   self::prune($state);$key=hash('sha256',$user.':'.$nonce);
   if(isset($state[$key]))return self::publicJob($state[$key]);
   $mime=self::validateAudio($file);$reserve();
   // Le verrou de session sérialise les doublons. Une prise ne part jamais deux fois.
   $job=['owner'=>$user,'field'=>$field,'created'=>time(),'status'=>'failed','job'=>bin2hex(random_bytes(16))];$state[$key]=$job;
   $state[$key]['external']=$engine->submit($path,$mime);$state[$key]['status']='pending';
   return self::publicJob($state[$key]);
  }finally{if($path!==''&&is_file($path))unlink($path);}
 }
 public static function poll(array &$state,string $user,string $job,Infomaniak $engine):array {
  self::prune($state);
  foreach($state as &$item){
   if($item['owner']!==$user||!hash_equals($item['job'],$job))continue;
   if($item['status']==='failed')throw new \RuntimeException('Cette prise n’est plus disponible. Relisez votre texte ou refaites une dictée.');
   if($item['status']==='pending'){
    if(time()-(int)($item['last_poll']??0)<3)return self::publicJob($item);
    $item['last_poll']=time();
    try{$result=$engine->poll($item['external']);$item=array_merge($item,$result);}catch(\RuntimeException $e){$item['status']='failed';throw $e;}
   }
   return self::publicJob($item);
  }
  throw new \RuntimeException('La transcription a expiré. Refaites une dictée si nécessaire.');
 }
 private static function publicJob(array $job):array {return array_intersect_key($job,array_flip(['job','field','status','text']));}
 private static function prune(array &$state):void {foreach($state as $k=>$v)if(time()-(int)$v['created']>1200)unset($state[$k]);}
 public static function reserve(string $user,string $dir):void {
  if(!is_dir($dir)&&!mkdir($dir,0700,true)&&!is_dir($dir))throw new \RuntimeException('La dictée est indisponible.');
  $f=fopen($dir.'/'.hash('sha256',$user).'.json','c+');if(!$f)throw new \RuntimeException('La dictée est indisponible.');
  try{if(!flock($f,LOCK_EX))throw new \RuntimeException('La dictée est indisponible.');$v=json_decode(stream_get_contents($f),true)?:[];$now=time();$v=array_values(array_filter($v,fn($t)=>is_int($t)&&$t>$now-3600));if(count($v)>=12)throw new \RuntimeException('Limite de 12 dictées par heure atteinte. Vous pouvez continuer à saisir le texte.');$v[]=$now;ftruncate($f,0);rewind($f);fwrite($f,json_encode($v));fflush($f);chmod($dir.'/'.hash('sha256',$user).'.json',0600);}finally{flock($f,LOCK_UN);fclose($f);}
 }
 public static function serve(string $action,string $user):never {
  header('Content-Type: application/json; charset=utf-8');
  try {
   if(($_SERVER['REQUEST_METHOD']??'')!=='POST'){http_response_code(405);throw new \InvalidArgumentException('Méthode non autorisée.');}
   $state=&$_SESSION['dictation'];if(!is_array($state))$state=[];
   $engine=new Infomaniak($GLOBALS['config']);set_time_limit(75);
   if($action==='stt_submit'){
    $file=$_FILES['audio']??[];
    if(!is_uploaded_file((string)($file['tmp_name']??'')))throw new \InvalidArgumentException('Audio absent. Vérifiez la taille et votre connexion.');
    $result=self::submit($state,$user,(string)($_POST['field']??''),(string)($_POST['nonce']??''),$file,$engine,fn()=>self::reserve($user,(string)config('app.private_dir').'/stt-limits'));
   }else $result=self::poll($state,$user,(string)($_POST['job']??''),$engine);
   echo json_encode(['ok'=>true]+$result,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
  }catch(\InvalidArgumentException|\RuntimeException $e){if(http_response_code()===200)http_response_code(400);echo json_encode(['ok'=>false,'error'=>$e->getMessage()],JSON_UNESCAPED_UNICODE);}
  finally{foreach($_FILES as $file)if(is_array($file)&&is_uploaded_file((string)($file['tmp_name']??'')))unlink($file['tmp_name']);}
  exit;
 }
}
