<?php
declare(strict_types=1);
namespace App\Rag;
use PDO;
/** Recherche lexicale BM25 locale, sans embeddings ni appel externe. Corpus privé borné. */
final class FulltextRetriever implements Retriever {
    public function __construct(private readonly PDO $pdo) {}
    private const STOP = ['les','des','une','pour','dans','par','sur','avec','sans','est','sont','qui','que','quoi','dont','aux','ces','cet','cette','ses','son','leur','leurs','nous','vous','ils','elle','elles','mais','donc','car','pas','plus','tout','tous','toute','toutes','fait','faire','ete','etre','avoir','avait','comme','aussi','tres','entre','depuis','lors','chez','mon','mes','ton','tes','notre','votre','quel','quelle','comment','pourquoi','quand','peut','doit','veut','ont'];
    private function words(string $s): array {
        $s = mb_strtolower($s);
        $s = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s) ?: $s;
        return array_values(array_filter(preg_split('/[^a-z0-9]+/', $s, -1, PREG_SPLIT_NO_EMPTY) ?: [], static fn($w)=>strlen($w)>=3 && !in_array($w,self::STOP,true)));
    }
    public function search(string $query, int $limit, array $boostCategories=[]): array {
        $terms = array_slice(array_values(array_unique($this->words(mb_substr($query,0,12000)))),0,60);
        if (!$terms) return [];
        $rows=$this->pdo->query('SELECT c.id,c.contenu,d.titre,d.categorie,d.source FROM pe_chunks c JOIN pe_documents d ON d.id=c.document_id WHERE d.actif=1 ORDER BY c.id LIMIT 10000')->fetchAll();
        if (!$rows) return [];
        $bags=[]; $df=array_fill_keys($terms,0); $total=0;
        foreach ($rows as $i=>$r) {
            $words=$this->words($r['contenu']); $total+=count($words); $counts=array_count_values($words); $freq=[];
            foreach($terms as $t) {
                $freq[$t]=0;
                foreach($counts as $w=>$n) if((string)$w===(string)$t || (strlen((string)$t)>=5 && strlen((string)$w)>=4 && (str_starts_with((string)$w,rtrim((string)$t,'s')) || str_starts_with((string)$t,rtrim((string)$w,'s'))))) $freq[$t]+=$n;
                if($freq[$t]>0) $df[$t]++;
            }
            $bags[$i]=[count($words),$freq];
        }
        $avg=max(1,$total/count($rows)); $scored=[];
        foreach($rows as $i=>$r) {
            [$len,$freq]=$bags[$i]; $score=0.0;
            foreach($terms as $t) if($freq[$t]>0) {
                $idf=log(1+(count($rows)-$df[$t]+0.5)/($df[$t]+0.5)); $tf=$freq[$t];
                $score+=$idf*($tf*2.2)/($tf+1.2*(0.25+0.75*$len/$avg));
            }
            if($score<=0) continue;
            if(in_array($r['categorie'],$boostCategories,true)) $score*=1.5;
            $r['score']=$score; $r['id']=(int)$r['id']; $scored[]=$r;
        }
        usort($scored,static fn($a,$b)=>($b['score']<=>$a['score']) ?: ($a['id']<=>$b['id']));
        return array_slice($scored,0,max(1,min(20,$limit)));
    }
}
