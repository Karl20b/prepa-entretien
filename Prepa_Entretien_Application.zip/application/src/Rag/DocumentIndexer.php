<?php
declare(strict_types=1);

namespace App\Rag;

use App\Domain\Categorie;
use PDO;

/** Découpe les documents en fragments et (ré)alimente pe_chunks. */
final class DocumentIndexer
{
    public function __construct(
        private readonly PDO $pdo,
        private readonly Chunker $chunker,
    ) {}

    /** @return int nombre de fragments créés */
    public function index(int $documentId): int
    {
        $stmt = $this->pdo->prepare('SELECT titre, contenu FROM pe_documents WHERE id = ?');
        $stmt->execute([$documentId]);
        $doc = $stmt->fetch();
        if (!$doc) {
            return 0;
        }

        $this->pdo->beginTransaction();
        try {
            $this->pdo->prepare('DELETE FROM pe_chunks WHERE document_id = ?')->execute([$documentId]);
            $insert = $this->pdo->prepare(
                'INSERT INTO pe_chunks (document_id, ordre, contenu) VALUES (?, ?, ?)'
            );
            $n = 0;
            foreach ($this->chunker->split($doc['contenu']) as $i => $chunk) {
                // Le titre est répété dans chaque fragment : améliore la recherche et le contexte IA
                $insert->execute([$documentId, $i + 1, $doc['titre'] . "\n" . $chunk]);
                $n++;
            }
            $this->pdo->commit();
            return $n;
        } catch (\Throwable $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }

    public function reindexAll(): int
    {
        $total = 0;
        foreach ($this->pdo->query('SELECT id FROM pe_documents')->fetchAll(PDO::FETCH_COLUMN) as $id) {
            $total += $this->index((int) $id);
        }
        return $total;
    }

    /**
     * Importe les fichiers .md d'un dossier (en-tête --- titre / categorie / source ---).
     * Un document de même titre est mis à jour plutôt que dupliqué.
     * @return int nombre de documents importés
     */
    public function importDirectory(string $dir, string $user): int
    {
        $count = 0;
        foreach (glob(rtrim($dir, '/') . '/*.md') ?: [] as $file) {
            [$meta, $body] = self::parseFrontMatter((string) file_get_contents($file));
            $titre = $meta['titre'] ?? basename($file, '.md');
            $categorie = Categorie::fromValue($meta['categorie'] ?? null)->value;

            $stmt = $this->pdo->prepare('SELECT id FROM pe_documents WHERE titre = ?');
            $stmt->execute([$titre]);
            $id = $stmt->fetchColumn();
            if ($id) {
                $this->pdo->prepare('UPDATE pe_documents SET updated_at = NOW(), categorie = ?, source = ?, contenu = ? WHERE id = ?')
                    ->execute([$categorie, $meta['source'] ?? null, $body, $id]);
            } else {
                $this->pdo->prepare('INSERT INTO pe_documents (titre, categorie, source, contenu, created_by) VALUES (?, ?, ?, ?, ?)')
                    ->execute([$titre, $categorie, $meta['source'] ?? null, $body, $user]);
                $id = $this->pdo->lastInsertId();
            }
            $this->index((int) $id);
            $count++;
        }
        return $count;
    }

    /** @return array{0: array<string,string>, 1: string} */
    public static function parseFrontMatter(string $raw): array
    {
        $raw = str_replace(["\r\n", "\r"], "\n", $raw);
        if (!preg_match('/^---\n(.*?)\n---\n?(.*)$/su', $raw, $m)) {
            return [[], trim($raw)];
        }
        $meta = [];
        foreach (explode("\n", $m[1]) as $line) {
            if (str_contains($line, ':')) {
                [$k, $v] = array_map('trim', explode(':', $line, 2));
                $meta[mb_strtolower($k)] = $v;
            }
        }
        return [$meta, trim($m[2])];
    }
}
