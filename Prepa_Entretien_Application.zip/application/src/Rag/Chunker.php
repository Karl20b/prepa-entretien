<?php
declare(strict_types=1);

namespace App\Rag;

/**
 * Découpe un texte en fragments d'environ $size caractères,
 * en respectant paragraphes puis phrases, avec recouvrement.
 */
final class Chunker
{
    public function __construct(
        private readonly int $size = 1200,
        private readonly int $overlap = 200,
    ) {}

    /** @return list<string> */
    public function split(string $text): array
    {
        $text = trim(str_replace(["\r\n", "\r"], "\n", $text));
        if ($text === '') {
            return [];
        }

        $chunks = [];
        $current = '';
        foreach ($this->units($text) as $unit) {
            if ($current !== '' && mb_strlen($current) + 2 + mb_strlen($unit) > $this->size) {
                $chunks[] = $current;
                $tail = $this->tail($current);
                $current = $tail === '' ? $unit : $tail . "\n\n" . $unit;
            } else {
                $current = $current === '' ? $unit : $current . "\n\n" . $unit;
            }
        }
        if ($current !== '') {
            $chunks[] = $current;
        }
        return $chunks;
    }

    /** Paragraphes, eux-mêmes redécoupés en phrases s'ils sont trop longs. @return list<string> */
    private function units(string $text): array
    {
        $units = [];
        foreach (preg_split('/\n\s*\n/u', $text) ?: [] as $para) {
            $para = trim($para);
            if ($para === '') {
                continue;
            }
            if (mb_strlen($para) <= $this->size) {
                $units[] = $para;
                continue;
            }
            $buffer = '';
            foreach (preg_split('/(?<=[.!?…])\s+/u', $para) ?: [] as $sentence) {
                while (mb_strlen($sentence) > $this->size) {
                    if ($buffer !== '') {
                        $units[] = $buffer;
                        $buffer = '';
                    }
                    $units[] = mb_substr($sentence, 0, $this->size);
                    $sentence = mb_substr($sentence, $this->size);
                }
                if ($buffer !== '' && mb_strlen($buffer) + 1 + mb_strlen($sentence) > $this->size) {
                    $units[] = $buffer;
                    $buffer = $sentence;
                } else {
                    $buffer = $buffer === '' ? $sentence : $buffer . ' ' . $sentence;
                }
            }
            if ($buffer !== '') {
                $units[] = $buffer;
            }
        }
        return $units;
    }

    private function tail(string $chunk): string
    {
        if ($this->overlap <= 0 || mb_strlen($chunk) <= $this->overlap) {
            return '';
        }
        $tail = mb_substr($chunk, -$this->overlap);
        $pos = mb_strpos($tail, ' ');
        return '… ' . ($pos === false ? $tail : mb_substr($tail, $pos + 1));
    }
}
