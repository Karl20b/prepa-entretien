<?php
declare(strict_types=1);

namespace App\Rag;

/**
 * Contrat de recherche documentaire.
 * Implémentation actuelle : FulltextRetriever (BM25 lexical local SQLite).
 * Évolution possible : VectorRetriever (embeddings + VECTOR MariaDB 11.7+),
 * ou hybride (fusion des deux classements).
 */
interface Retriever
{
    /**
     * @param list<string> $boostCategories catégories à favoriser
     * @return list<array{id:int,contenu:string,titre:string,categorie:string,source:?string,score:float}>
     */
    public function search(string $query, int $limit, array $boostCategories = [], string $corpus = 'metier'): array;
}
