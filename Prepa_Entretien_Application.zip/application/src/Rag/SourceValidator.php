<?php
declare(strict_types=1);
namespace App\Rag;
use App\Ai\AiException;
/** Valide la présence et l’existence des références ; la fidélité reste à relire. */
final class SourceValidator {
 public static function check(string $answer,array $sources):void {
  if($sources===[])return;
  preg_match_all('/\[(S[0-9]+)\]/',$answer,$m);
  if(!$m[1])throw new AiException('La réponse de l’IA ne cite pas les documents fournis. Elle n’a pas été enregistrée. Relancez la préparation.');
  if(array_diff(array_unique($m[1]),array_column($sources,'ref')))throw new AiException('La réponse contient une référence documentaire inconnue. Elle n’a pas été enregistrée. Relancez la préparation.');
 }
}
