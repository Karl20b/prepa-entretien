<?php
declare(strict_types=1);
namespace App;
final class Media {
 public static function serve():never {
  if(!in_array($_SERVER['REQUEST_METHOD']??'GET',['GET','HEAD'],true)){http_response_code(405);exit;}
  $id=(string)($_GET['id']??'');$kind=(string)($_GET['kind']??'mp4');
  if(!in_array($id,['01','02','03','04','05'],true) || !in_array($kind,['mp4','vtt','poster','transcript'],true))not_found();
  $suffix=['mp4'=>'.mp4','vtt'=>'.vtt','poster'=>'.webp','transcript'=>'.txt'][$kind];
  $file=APP_ROOT.'/media/guide-'.$id.$suffix;
  if(!is_file($file))not_found('Cette capsule est momentanément indisponible.');
  $size=filesize($file);$start=0;$end=$size-1;
  header('Content-Type: '.['mp4'=>'video/mp4','vtt'=>'text/vtt; charset=utf-8','poster'=>'image/webp','transcript'=>'text/plain; charset=utf-8'][$kind]);
  header('Accept-Ranges: bytes');
  if(!empty($_SERVER['HTTP_RANGE'])) {
   if(!preg_match('/^bytes=(\d*)-(\d*)$/D',$_SERVER['HTTP_RANGE'],$m) || ($m[1]===''&&$m[2]==='')){http_response_code(416);header('Content-Range: bytes */'.$size);exit;}
   if($m[1]==='')$start=max(0,$size-(int)$m[2]);
   else {$start=(int)$m[1];if($m[2]!=='')$end=min($end,(int)$m[2]);}
   if($start>$end||$start>=$size){http_response_code(416);header('Content-Range: bytes */'.$size);exit;}
   http_response_code(206);header("Content-Range: bytes $start-$end/$size");
  }
  header('Content-Length: '.($end-$start+1));
  if($kind==='transcript')header('Content-Disposition: attachment; filename="guide-'.$id.'.txt"');
  session_write_close();
  if(($_SERVER['REQUEST_METHOD']??'GET')==='HEAD')exit;
  $f=fopen($file,'rb');fseek($f,$start);$remaining=$end-$start+1;
  while($remaining>0&&!feof($f)){ $chunk=fread($f,min(65536,$remaining));if($chunk===false)break;echo $chunk;$remaining-=strlen($chunk);if(connection_aborted())break; }
  fclose($f);exit;
 }
}
