<?php
declare(strict_types=1);
namespace App;
use PDO;
use App\Repo\AccountRepo;
final class Auth {
 public static function gate(PDO $pdo):void {
  if(($_GET['action']??'')==='security')\App\Security\Login::route($pdo);
  if(($_GET['action']??'')==='activate'){self::activation($pdo);return;}
  $repo=new AccountRepo($pdo);$now=time();
  if(!empty($_SESSION['user'])) {
   $a=$repo->find((string)$_SESSION['user']);
   $valid=$a && (bool)$a['active'] && $now-(int)($_SESSION['last_seen']??0)<=1800 && $now-(int)($_SESSION['signed_at']??0)<=28800;
   // Les sessions v1 déjà authentifiées reçoivent leur version lors de la première lecture.
   if($valid && isset($_SESSION['auth_version']) && (int)$_SESSION['auth_version']!==(int)$a['auth_version'])$valid=false;
   if($valid){$_SESSION['auth_version']=(int)$a['auth_version'];$_SESSION['last_seen']=$now;\App\Security\Login::gate($pdo,$a);return;}
   $_SESSION=[];session_regenerate_id(true);
  }
  if(in_array($_GET['action']??'', ['stt_submit','stt_poll','preparation_chat'],true)){http_response_code(401);header('Content-Type: application/json');echo json_encode(['ok'=>false,'error'=>'Votre session a expiré. Reconnectez-vous.']);exit;}
  $setup=(int)$pdo->query('SELECT COUNT(*) FROM pe_accounts')->fetchColumn()===0;$error='';
  if(($_SERVER['REQUEST_METHOD']??'GET')==='POST') {
   csrf_check();
   if(self::blocked($pdo)){http_response_code(429);$error='Trop de tentatives. Réessayez dans quinze minutes.';}
   else {
    $password=(string)($_POST['password']??'');
    if($setup) {
     $token=(string)($_POST['activation']??'');$row=$pdo->query('SELECT * FROM pe_setup WHERE id=1')->fetch();
     if($row && (int)$row['expires_at']>$now && $token!=='' && hash_equals($row['token_hash'],hash('sha256',$token)) && mb_strlen($password)>=14 && strlen($password)<=1024 && $password===(string)($_POST['confirmation']??'') && !empty($_POST['exercise_only'])) {
      $username=(string)config('app.setup_username','administrateur');$displayName=(string)config('app.setup_display_name','Administrateur');
       if(!preg_match('/^[a-z0-9][a-z0-9._-]{2,39}$/D',$username))throw new \RuntimeException('Identifiant initial invalide.');
       $passwordHash=password_hash($password,PASSWORD_DEFAULT);$pdo->beginTransaction();
      try {
       $s=$pdo->prepare('DELETE FROM pe_setup WHERE id=1 AND token_hash=? AND expires_at>? AND NOT EXISTS(SELECT 1 FROM pe_accounts)');$s->execute([hash('sha256',$token),$now]);
       if($s->rowCount()!==1)throw new \RuntimeException('Activation déjà utilisée.');
       $pdo->prepare("INSERT INTO pe_accounts(username,password_hash,created_at,display_name,role,active,updated_at) VALUES(?,?,?,?, 'admin',1,?)")->execute(\App\Security\Vault::values('pe_accounts',['username','password_hash','created_at','display_name','updated_at'],[$username,$passwordHash,$now,$displayName,$now]));
       $pdo->prepare('UPDATE pe_accounts SET password_changed_at=? WHERE username=?')->execute([time(),$username]);$pdo->commit();self::clearLimit($pdo);self::signed($pdo,$username);
      }catch(\Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$error='Activation impossible. Rechargez la page et réessayez.';}
     }else $error='Vérifiez le code d’activation, les deux mots de passe (14 caractères minimum) et la confirmation d’usage.';
    }else {
     $username=mb_strtolower(trim((string)($_POST['username']??'')));$a=strlen($username)<=40?$repo->find($username):null;
     if($a && $a['active'] && $a['password_hash']!=='' && strlen($password)<=1024 && password_verify($password,$a['password_hash'])){self::clearLimit($pdo);self::signed($pdo,$a['username']);}
     $error='Connexion impossible. Vérifiez votre identifiant et votre mot de passe, ou contactez un administrateur.';
    }
    self::failed($pdo);
   }
  }
  if(($_GET['action']??'')==='constellation_save'){http_response_code(401);header('Content-Type: application/json');echo json_encode(['ok'=>false,'error'=>'Votre session a expiré. Reconnectez-vous avant d’enregistrer.']);exit;}
  render('login',['setup'=>$setup,'error'=>$error],$setup?'Activer mon espace':'Connexion');exit;
 }
 private static function activation(PDO $pdo):never {
  $error='';
  if(($_SERVER['REQUEST_METHOD']??'GET')==='POST') {
   csrf_check();
   if(self::blocked($pdo)){http_response_code(429);$error='Trop de tentatives. Réessayez dans quinze minutes.';}
   else {try{
    $username=(new AccountRepo($pdo))->accept((string)($_POST['activation']??''),(string)($_POST['password']??''),(string)($_POST['confirmation']??''),!empty($_POST['exercise_only']));
    self::clearLimit($pdo);self::signed($pdo,$username);
   }catch(\InvalidArgumentException $e){$error=$e->getMessage();self::failed($pdo);}}
  }
  render('activation',['error'=>$error],'Définir mon mot de passe');exit;
 }
 public static function signed(PDO $pdo,string $username):never {\App\Security\Login::begin($pdo,$username);}
 public static function finish(PDO $pdo,string $username,bool $mfa=false,?int $expectedVersion=null):never {
  $a=(new AccountRepo($pdo))->find($username);if(!$a || !$a['active']||($expectedVersion!==null&&(int)$a['auth_version']!==$expectedVersion))throw new \RuntimeException('Compte indisponible.');
  session_regenerate_id(true);$_SESSION=['mfa_ok'=>$mfa,'user'=>$username,'signed_at'=>time(),'last_seen'=>time(),'auth_version'=>(int)$a['auth_version'],'csrf'=>bin2hex(random_bytes(32))];redirect('index.php');
 }
 private static function key():string {return hash_hmac('sha256',(string)($_SERVER['REMOTE_ADDR']??'cli'),(string)config('app.rate_key'));}
 private static function blocked(PDO $pdo):bool {$s=$pdo->prepare('SELECT failures FROM pe_auth_limits WHERE key_hash=? AND window_start>?');$s->execute([self::key(),time()-900]);return (int)$s->fetchColumn()>=8;}
 private static function failed(PDO $pdo):void {
  $now=time();$pdo->prepare('INSERT INTO pe_auth_limits(key_hash,failures,window_start) VALUES(?,1,?) ON CONFLICT(key_hash) DO UPDATE SET failures=CASE WHEN window_start>? THEN failures+1 ELSE 1 END,window_start=CASE WHEN window_start>? THEN window_start ELSE excluded.window_start END')->execute([self::key(),$now,$now-900,$now-900]);
 }
 private static function clearLimit(PDO $pdo):void {$pdo->prepare('DELETE FROM pe_auth_limits WHERE key_hash=?')->execute([self::key()]);}
 public static function logout():never {csrf_check();$_SESSION=[];session_regenerate_id(true);redirect('index.php');}
}
