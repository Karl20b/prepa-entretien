<?php
declare(strict_types=1);
namespace App\Repo;
use App\Atelier\Grille;
use PDO;
final class AtelierRepo {
 public function __construct(private readonly PDO $pdo){}
 private function owner(int $sid,string $user):void {
  if(!(new SituationRepo($this->pdo))->find($sid,$user))throw new \InvalidArgumentException('Situation introuvable.');
 }
 public function find(int $sid,string $kind,string $user):?array {
  $this->owner($sid,$user);Grille::fields($kind);
  $st=$this->pdo->prepare('SELECT * FROM pe_ateliers WHERE situation_id=? AND kind=?');$st->execute([$sid,$kind]);$r=$st->fetch();
  if(!$r)return null;
  $r['data']=json_decode($r['data'],true,512,JSON_THROW_ON_ERROR);
  $r['sources']=json_decode($r['sources']??'[]',true,512,JSON_THROW_ON_ERROR);return $r;
 }
 public function save(int $sid,string $kind,string $user,array $input,int $expected):array {
  $this->owner($sid,$user);$data=Grille::clean($kind,$input);$json=json_encode($data,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
  if($expected===0){
   $st=$this->pdo->prepare('INSERT OR IGNORE INTO pe_ateliers(situation_id,kind,data) VALUES(?,?,?)');$st->execute([$sid,$kind,\App\Security\Vault::seal($json,'pe_ateliers.data')]);
  }else{
   $st=$this->pdo->prepare('UPDATE pe_ateliers SET data=?,revision=revision+(PE_DEC(data)<>?),updated_at=NOW() WHERE situation_id=? AND kind=? AND revision=?');$st->execute([\App\Security\Vault::seal($json,'pe_ateliers.data'),$json,$sid,$kind,$expected]);
  }
  if($st->rowCount()!==1)throw new \RuntimeException('Ce parcours a été modifié dans un autre onglet. Copiez votre texte, rechargez puis fusionnez vos modifications.');
  return $this->find($sid,$kind,$user);
 }
 public function saveAnalysis(int $sid,string $kind,string $user,int $revision,string $hash,string $answer,array $sources,string $provider):bool {
  $this->owner($sid,$user);
  if(\App\Atelier\Grille::contextHash((new SituationRepo($this->pdo))->find($sid,$user)??[])!==$hash)return false;
  $st=$this->pdo->prepare('UPDATE pe_ateliers SET analysis=?,sources=?,provider=?,analysis_revision=?,context_hash=?,analysis_at=NOW() WHERE situation_id=? AND kind=? AND revision=?');
  $st->execute(\App\Security\Vault::values('pe_ateliers',['analysis','sources','provider','analysis_revision','context_hash','situation_id','kind','revision'],[$answer,json_encode($sources,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),$provider,$revision,$hash,$sid,$kind,$revision]));return $st->rowCount()===1;
 }
 public function context(int $sid,string $user):string {
  $parts=[];foreach(['eogi','feedback'] as $k){$r=$this->find($sid,$k,$user);if($r)$parts[]=Grille::block($k,$r['data']);}return implode("\n\n",$parts);
 }
}
