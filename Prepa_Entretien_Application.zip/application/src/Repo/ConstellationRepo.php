<?php
declare(strict_types=1);

namespace App\Repo;

use App\Constellation\ConstellationData;
use PDO;

/** Constellations, cloisonnées par utilisateur comme les situations. */
final class ConstellationRepo
{
    public function __construct(private readonly PDO $pdo) {}

    public function all(string $user): array
    {
        $stmt = $this->pdo->prepare(
            'SELECT c.id, c.titre, c.situation_id, c.updated_at, c.analyse_at, c.data, s.titre AS situation_titre
               FROM pe_constellations c LEFT JOIN pe_situations s ON s.id = c.situation_id
              WHERE c.created_by = ? ORDER BY c.updated_at DESC'
        );
        $stmt->execute([$user]);
        return array_map(function (array $r) {
            $d = json_decode($r['data'], true) ?: [];
            $r['nb_images'] = count($d['images'] ?? []);
            $r['nb_elements'] = count($d['images'][0]['elements'] ?? []);
            unset($r['data']);
            return $r;
        }, $stmt->fetchAll());
    }

    public function find(int $id, string $user): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM pe_constellations WHERE id = ? AND created_by = ?');
        $stmt->execute([$id, $user]);
        $r = $stmt->fetch();
        if (!$r) {
            return null;
        }
        $r['data'] = json_decode($r['data'], true) ?: ConstellationData::empty();
        $r['analyse_sources'] = $r['analyse_sources'] ? (json_decode($r['analyse_sources'], true) ?: []) : [];
        return $r;
    }

    /** @return list<array> constellations liées à une situation (plus récente en premier) */
    public function forSituation(int $situationId, string $user): array
    {
        $stmt = $this->pdo->prepare(
            'SELECT id, titre, question, data, updated_at FROM pe_constellations
              WHERE situation_id = ? AND created_by = ? ORDER BY updated_at DESC'
        );
        $stmt->execute([$situationId, $user]);
        return array_map(function (array $r) {
            $r['data'] = json_decode($r['data'], true) ?: ConstellationData::empty();
            return $r;
        }, $stmt->fetchAll());
    }

    public function create(string $user, string $titre, ?int $situationId): int
    {
        $this->pdo->prepare('INSERT INTO pe_constellations (titre, situation_id, data, created_by) VALUES (?, ?, ?, ?)')
            ->execute([$titre, $situationId, json_encode(ConstellationData::empty(), JSON_UNESCAPED_UNICODE), $user]);
        return (int) $this->pdo->lastInsertId();
    }

    public function save(int $id, string $user, string $titre, ?string $question, ?int $situationId, array $data): void
    {
        $this->pdo->prepare(
            'UPDATE pe_constellations SET updated_at = NOW(), titre = ?, question = ?, situation_id = ?, data = ? WHERE id = ? AND created_by = ?'
        )->execute([$titre, $question, $situationId, json_encode($data, JSON_UNESCAPED_UNICODE), $id, $user]);
    }

    public function saveAnalyse(int $id, string $user, string $text, array $sources, string $provider): void
    {
        $this->pdo->prepare(
            'UPDATE pe_constellations SET updated_at = NOW(), analyse = ?, analyse_sources = ?, analyse_fournisseur = ?, analyse_at = NOW()
              WHERE id = ? AND created_by = ?'
        )->execute([$text, json_encode($sources, JSON_UNESCAPED_UNICODE), $provider, $id, $user]);
    }

    public function delete(int $id, string $user): void
    {
        $this->pdo->prepare('DELETE FROM pe_constellations WHERE id = ? AND created_by = ?')->execute([$id, $user]);
    }
}
