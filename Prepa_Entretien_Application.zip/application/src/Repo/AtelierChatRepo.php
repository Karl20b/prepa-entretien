<?php
declare(strict_types=1);
namespace App\Repo;
use PDO;
final class AtelierChatRepo {
 public function __construct(private readonly PDO $pdo){}
 private function owner(int $sid,string $kind,string $user):void {
  \App\Atelier\Grille::fields($kind);
  if(!(new \App\Repo\SituationRepo($this->pdo))->find($sid,$user))throw new \InvalidArgumentException('Situation introuvable.');
 }
 public function history(int $sid,string $kind,string $user,int $limit=12):array {
  $this->owner($sid,$kind,$user);$limit=max(2,min(40,$limit));
  $st=$this->pdo->prepare('SELECT * FROM (SELECT * FROM pe_atelier_messages WHERE situation_id=? AND kind=? ORDER BY id DESC LIMIT ?) ORDER BY id');
  $st->bindValue(1,$sid,PDO::PARAM_INT);$st->bindValue(2,$kind);$st->bindValue(3,$limit,PDO::PARAM_INT);$st->execute();
  $rows=$st->fetchAll();foreach($rows as &$r)$r['sources']=json_decode($r['sources']??'[]',true,512,JSON_THROW_ON_ERROR);return $rows;
 }
 public function exchange(int $sid,string $kind,string $user,int $revision,string $hash,string $question,string $answer,array $sources,string $provider):void {
  $this->owner($sid,$kind,$user);
  $this->pdo->beginTransaction();
  try {
   $row=(new AtelierRepo($this->pdo))->find($sid,$kind,$user);
   if(!$row || (int)$row['revision']!==$revision || \App\Atelier\Grille::contextHash((new \App\Repo\SituationRepo($this->pdo))->find($sid,$user)??[])!==$hash)throw new \RuntimeException('La grille a changé pendant la réponse. Rechargez puis reposez votre question sur la version actuelle.');
   $st=$this->pdo->prepare('INSERT INTO pe_atelier_messages(situation_id,kind,role,content,sources,provider,revision,context_hash) VALUES(?,?,?,?,?,?,?,?)');
   $st->execute(\App\Security\Vault::values('pe_atelier_messages',['situation_id','kind','role','content','sources','provider','revision','context_hash'],[$sid,$kind,'user',$question,null,null,$revision,$hash]));
   $st->execute(\App\Security\Vault::values('pe_atelier_messages',['situation_id','kind','role','content','sources','provider','revision','context_hash'],[$sid,$kind,'assistant',$answer,json_encode($sources,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),$provider,$revision,$hash]));
   $this->pdo->commit();
  }catch(\Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
 }
}
