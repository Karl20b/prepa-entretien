<?php
declare(strict_types=1);

namespace App\Repo;

use PDO;

final class MessageRepo
{
    public function __construct(private readonly PDO $pdo) {}

    public function forSituation(int $situationId): array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM pe_messages WHERE situation_id = ? ORDER BY id');
        $stmt->execute([$situationId]);
        return array_map(function (array $r) {
            $r['sources'] = $r['sources'] ? (json_decode($r['sources'], true) ?: []) : [];
            return $r;
        }, $stmt->fetchAll());
    }

    public function add(int $situationId, string $role, string $content, array $sources = [], ?string $provider = null): void
    {
        $this->pdo->prepare(
            'INSERT INTO pe_messages (situation_id, role, contenu, sources, fournisseur) VALUES (?, ?, ?, ?, ?)'
        )->execute([
            $situationId, $role, $content,
            $sources === [] ? null : json_encode($sources, JSON_UNESCAPED_UNICODE),
            $provider,
        ]);
    }

    public function clear(int $situationId): void
    {
        $this->pdo->prepare('DELETE FROM pe_messages WHERE situation_id = ?')->execute([$situationId]);
    }
}
