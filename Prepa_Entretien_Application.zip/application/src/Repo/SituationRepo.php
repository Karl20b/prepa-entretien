<?php
declare(strict_types=1);

namespace App\Repo;

use PDO;

/** Chaque manager ne voit que ses propres situations (données RH sensibles). */
final class SituationRepo
{
    public const FIELDS = [
        'titre', 'type_entretien', 'collaborateur_ref', 'fonction', 'date_entretien',
        'cdc_role', 'contexte', 'faits', 'objectif_manager', 'enjeux', 'statut',
    ];

    public function __construct(private readonly PDO $pdo) {}

    public function all(string $user): array
    {
        $stmt = $this->pdo->prepare(
            'SELECT s.*, (SELECT COUNT(*) FROM pe_messages m WHERE m.situation_id = s.id) AS nb_messages
               FROM pe_situations s WHERE s.created_by = ? ORDER BY s.updated_at DESC'
        );
        $stmt->execute([$user]);
        return $stmt->fetchAll();
    }

    public function find(int $id, string $user): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM pe_situations WHERE id = ? AND created_by = ?');
        $stmt->execute([$id, $user]);
        return $stmt->fetch() ?: null;
    }

    public function save(array $data, string $user, ?int $id = null): int
    {
        if($id!==null&&!array_key_exists('cdc_role',$data))$data['cdc_role']=$this->find($id,$user)['cdc_role']??null;
        $data['cdc_role']=\App\Reference\RoleCatalog::clean($data['cdc_role']??null);
        $values = [];
        foreach (self::FIELDS as $f) {
            $v = isset($data[$f]) ? trim((string) $data[$f]) : '';
            $values[$f] = $v === '' ? null : $v;
        }
        $values['statut'] ??= 'brouillon';
        $values['type_entretien'] ??= 'autre';

        if ($id === null) {
            $cols = implode(', ', self::FIELDS);
            $marks = implode(', ', array_fill(0, count(self::FIELDS), '?'));
            $this->pdo->prepare("INSERT INTO pe_situations ($cols, created_by) VALUES ($marks, ?)")
                ->execute([...array_values($values), $user]);
            return (int) $this->pdo->lastInsertId();
        }

        $set = implode(', ', array_map(fn($f) => "$f = ?", self::FIELDS));
        $this->pdo->prepare("UPDATE pe_situations SET updated_at = NOW(), $set WHERE id = ? AND created_by = ?")
            ->execute([...array_values($values), $id, $user]);
        return $id;
    }

    public function setStatut(int $id, string $statut, string $user): void
    {
        $this->pdo->prepare('UPDATE pe_situations SET updated_at = NOW(), statut = ? WHERE id = ? AND created_by = ?')
            ->execute([$statut, $id, $user]);
    }

    public function delete(int $id, string $user): void
    {
        $this->pdo->prepare('DELETE FROM pe_situations WHERE id = ? AND created_by = ?')->execute([$id, $user]);
    }
}
