<?php
declare(strict_types=1);
namespace App\Repo;
use PDO;
use InvalidArgumentException;
final class AccountRepo {
 public function __construct(private readonly PDO $pdo) {}
 public function all():array {return $this->pdo->query("SELECT username,display_name,role,active,created_at,updated_at,CASE WHEN password_hash='' THEN 1 ELSE 0 END AS pending FROM pe_accounts ORDER BY role,username")->fetchAll();}
 public function find(string $username):?array {$s=$this->pdo->prepare('SELECT * FROM pe_accounts WHERE username=?');$s->execute([$username]);return $s->fetch()?:null;}
 public function requireAdmin(string $actor):void {$a=$this->find($actor);if(!$a || !$a['active'] || $a['role']!=='admin')throw new InvalidArgumentException('Cette action est réservée aux administrateurs actifs.');}
 public function create(string $actor,string $username,string $name,string $role):string {
  $this->requireAdmin($actor);$username=mb_strtolower(trim($username));$name=trim($name);
  if(!preg_match('/^[a-z0-9][a-z0-9._-]{2,39}$/D',$username))throw new InvalidArgumentException('Identifiant : 3 à 40 caractères, sans espace ni accent. Commencez par une lettre a-z ou un chiffre, puis utilisez a-z, 0-9, point, tiret ou trait de soulignement.');
  if(mb_strlen($name)>100 || !in_array($role,['user','admin'],true))throw new InvalidArgumentException('Nom ou rôle invalide.');
  $this->pdo->beginTransaction();
  try {
   if($this->find($username))throw new InvalidArgumentException('Cet identifiant existe déjà.');
   $this->pdo->prepare("INSERT INTO pe_accounts(username,password_hash,created_at,display_name,role,active,updated_at) VALUES(?,'',?,?,?,0,?)")->execute([$username,time(),$name?:$username,$role,time()]);
   $token=$this->newToken($username,'activate',172800);$this->audit($actor,$username,'created:'.$role);$this->pdo->commit();return $token;
  }catch(\Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
 }
 public function update(string $actor,string $username,string $name,string $role,bool $active):void {
  if(!in_array($role,['user','admin'],true)||mb_strlen(trim($name))>100)throw new InvalidArgumentException('Nom ou rôle invalide.');
  // Le verrou d’écriture est acquis avant la lecture du dernier administrateur.
  $this->pdo->exec('BEGIN IMMEDIATE');
  try {
   $this->requireAdmin($actor);$a=$this->find($username);if(!$a)throw new InvalidArgumentException('Compte introuvable.');
   if($a['password_hash']==='' && $active)throw new InvalidArgumentException('Ce compte doit d’abord être activé par son titulaire.');
   if($a['role']==='admin' && $a['active'] && ($role!=='admin'||!$active)) {
    $count=(int)$this->pdo->query("SELECT COUNT(*) FROM pe_accounts WHERE role='admin' AND active=1 AND password_hash<>''")->fetchColumn();
    if($count<=1)throw new InvalidArgumentException('Conservez au moins un administrateur actif.');
   }
   $changed=$a['role']!==$role || (bool)$a['active']!==$active;
   $this->pdo->prepare('UPDATE pe_accounts SET display_name=?,role=?,active=?,auth_version=auth_version+?,updated_at=? WHERE username=?')->execute([trim($name)?:$username,$role,(int)$active,(int)$changed,time(),$username]);
   if(!$active && $a['password_hash']!=='')$this->pdo->prepare('DELETE FROM pe_account_tokens WHERE username=?')->execute([$username]);
   $this->audit($actor,$username,'updated:'.$role.':'.(int)$active);$this->pdo->exec('COMMIT');
  }catch(\Throwable $e){$this->pdo->exec('ROLLBACK');throw $e;}
 }
 public function issueToken(string $actor,string $username,string $kind):string {
  $this->requireAdmin($actor);$a=$this->find($username);if(!$a)throw new InvalidArgumentException('Compte introuvable.');
  if($kind==='activate' && $a['password_hash']!=='')throw new InvalidArgumentException('Ce compte est déjà activé.');
  if($kind==='reset' && (!$a['active'] || $a['password_hash']===''))throw new InvalidArgumentException('La réinitialisation concerne un compte actif déjà activé.');
  if(!in_array($kind,['activate','reset'],true))throw new InvalidArgumentException('Type de lien invalide.');
  $this->pdo->beginTransaction();
  try{$token=$this->newToken($username,$kind,$kind==='activate'?172800:3600);$this->audit($actor,$username,'link:'.$kind);$this->pdo->commit();return $token;}
  catch(\Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
 }
 private function newToken(string $username,string $kind,int $ttl):string {
  $token=bin2hex(random_bytes(32));$this->pdo->prepare('INSERT OR REPLACE INTO pe_account_tokens(username,token_hash,expires_at,kind) VALUES(?,?,?,?)')->execute([$username,hash('sha256',$token),time()+$ttl,$kind]);return $token;
 }
 public function accept(string $token,string $password,string $confirmation,bool $exercise):string {
  if(strlen($token)>200 || mb_strlen($password)<14 || strlen($password)>1024 || $password!==$confirmation || !$exercise)throw new InvalidArgumentException('Vérifiez le code, les deux mots de passe (14 caractères minimum) et la confirmation d’usage.');
  $hash=hash('sha256',$token);$s=$this->pdo->prepare('SELECT * FROM pe_account_tokens WHERE token_hash=? AND expires_at>?');$s->execute([$hash,time()]);$t=$s->fetch();
  if(!$t)throw new InvalidArgumentException('Ce lien est invalide, expiré ou déjà utilisé. Demandez un nouveau lien à un administrateur.');
  $passwordHash=password_hash($password,PASSWORD_DEFAULT);
  $this->pdo->exec('BEGIN IMMEDIATE');
  try {
   $s=$this->pdo->prepare('SELECT * FROM pe_account_tokens WHERE token_hash=? AND expires_at>?');$s->execute([$hash,time()]);$t=$s->fetch();
   if(!$t)throw new InvalidArgumentException('Ce lien est invalide, expiré ou déjà utilisé.');
   $a=$this->find($t['username']);
   if(!$a || ($t['kind']==='reset' && !$a['active']))throw new InvalidArgumentException('Ce compte ne peut pas être activé.');
   $this->pdo->prepare('UPDATE pe_accounts SET password_hash=?,active=1,auth_version=auth_version+1,updated_at=? WHERE username=?')->execute([$passwordHash,time(),$t['username']]);
   $this->pdo->prepare('DELETE FROM pe_account_tokens WHERE username=?')->execute([$t['username']]);$this->audit($t['username'],$t['username'],'accepted:'.$t['kind']);
   $this->pdo->exec('COMMIT');return $t['username'];
  }catch(\Throwable $e){$this->pdo->exec('ROLLBACK');throw $e;}
 }
 private function audit(string $actor,string $subject,string $action):void {$this->pdo->prepare('INSERT INTO pe_account_audit(actor,subject,action,created_at) VALUES(?,?,?,?)')->execute([$actor,$subject,$action,time()]);}
 public function auditRecent():array {return $this->pdo->query('SELECT actor,subject,action,created_at FROM pe_account_audit ORDER BY id DESC LIMIT 30')->fetchAll();}
}
