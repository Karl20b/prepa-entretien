<?php
declare(strict_types=1);

namespace App\Repo;

use PDO;

final class DocumentRepo
{
    public function __construct(private readonly PDO $pdo) {}

    public function all(): array
    {
        return $this->pdo->query(
            'SELECT d.id, d.titre, d.categorie, d.source, d.actif, d.updated_at,
                    CHAR_LENGTH(d.contenu) AS taille,
                    (SELECT COUNT(*) FROM pe_chunks c WHERE c.document_id = d.id) AS nb_chunks
               FROM pe_documents d ORDER BY d.categorie, PE_DEC(d.titre)'
        )->fetchAll();
    }

    public function find(int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM pe_documents WHERE id = ?');
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function save(array $d, string $user, ?int $id = null): int
    {
        $params = [trim($d['titre']), $d['categorie'], trim((string) ($d['source'] ?? '')) ?: null, $d['contenu']];
        $params=\App\Security\Vault::values('pe_documents',['titre','categorie','source','contenu'],$params);
        if ($id === null) {
            $this->pdo->prepare('INSERT INTO pe_documents (titre, categorie, source, contenu, created_by) VALUES (?, ?, ?, ?, ?)')
                ->execute([...$params, $user]);
            return (int) $this->pdo->lastInsertId();
        }
        $this->pdo->prepare('UPDATE pe_documents SET updated_at = NOW(), titre = ?, categorie = ?, source = ?, contenu = ? WHERE id = ?')
            ->execute([...$params, $id]);
        return $id;
    }

    public function toggle(int $id): void
    {
        $this->pdo->prepare('UPDATE pe_documents SET updated_at = NOW(), actif = 1 - actif WHERE id = ?')->execute([$id]);
    }

    public function delete(int $id): void
    {
        $this->pdo->prepare('DELETE FROM pe_documents WHERE id = ?')->execute([$id]);
    }

    public function chunks(int $id): array
    {
        $stmt = $this->pdo->prepare('SELECT ordre, contenu FROM pe_chunks WHERE document_id = ? ORDER BY ordre');
        $stmt->execute([$id]);
        return $stmt->fetchAll();
    }
}
