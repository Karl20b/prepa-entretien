<?php
declare(strict_types=1);

namespace App\Domain;

/** Catégories de la base documentaire. Ajouter un cas ici suffit à l'exposer dans l'interface. */
enum Categorie: string
{
    case Systemique = 'systemique';
    case Grow        = 'grow';
    case Smart       = 'smart';
    case Ecoute      = 'ecoute';
    case Feedback    = 'feedback';
    case Recadrage   = 'recadrage';
    case Evaluation  = 'evaluation';
    case Conflit     = 'conflit';
    case Preparation = 'preparation';
    case Constellation = 'constellation';
    case Cadre       = 'cadre';
    case Autre       = 'autre';

    public function label(): string
    {
        return match ($this) {
            self::Systemique => 'Analyse systémique EOGI',
            self::Grow        => 'GROW',
            self::Smart       => 'SMART',
            self::Ecoute      => 'Écoute active',
            self::Feedback    => 'Feedback',
            self::Recadrage   => 'Recadrage',
            self::Evaluation  => 'Évaluation',
            self::Conflit     => 'Conflit',
            self::Preparation => 'Préparation d\'entretien',
            self::Constellation => 'Constellation systémique',
            self::Cadre       => 'Cadre RH / directives',
            self::Autre       => 'Autre',
        };
    }

    public static function fromValue(?string $value): self
    {
        return self::tryFrom((string) $value) ?? self::Autre;
    }
}
