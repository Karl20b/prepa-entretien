<?php
declare(strict_types=1);

namespace App\Domain;

/** Types d'entretien et catégories documentaires à privilégier dans le RAG. */
enum TypeEntretien: string
{
    case Objectifs  = 'objectifs';
    case Evaluation = 'evaluation';
    case Feedback   = 'feedback';
    case Recadrage  = 'recadrage';
    case Difficulte = 'difficulte';
    case Conflit    = 'conflit';
    case Retour     = 'retour';
    case Autre      = 'autre';

    public function label(): string
    {
        return match ($this) {
            self::Objectifs  => 'Fixation d\'objectifs',
            self::Evaluation => 'Entretien d\'appréciation / évaluation',
            self::Feedback   => 'Feedback / reconnaissance',
            self::Recadrage  => 'Recadrage',
            self::Difficulte => 'Collaborateur en difficulté',
            self::Conflit    => 'Gestion de conflit',
            self::Retour     => 'Entretien de retour (après absence)',
            self::Autre      => 'Autre',
        };
    }

    /** @return list<string> catégories boostées lors de la recherche */
    public function categories(): array
    {
        return match ($this) {
            self::Objectifs  => ['grow', 'smart', 'preparation'],
            self::Evaluation => ['evaluation', 'smart', 'feedback', 'ecoute', 'preparation'],
            self::Feedback   => ['feedback', 'ecoute'],
            self::Recadrage  => ['recadrage', 'feedback', 'ecoute', 'preparation'],
            self::Difficulte => ['systemique', 'ecoute', 'grow', 'preparation'],
            self::Conflit    => ['systemique', 'conflit', 'ecoute', 'recadrage'],
            self::Retour     => ['ecoute', 'preparation'],
            self::Autre      => ['preparation'],
        };
    }

    public static function fromValue(?string $value): self
    {
        return self::tryFrom((string) $value) ?? self::Autre;
    }
}
