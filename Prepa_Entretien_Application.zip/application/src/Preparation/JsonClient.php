<?php
declare(strict_types=1);
namespace App\Preparation;
use App\Ai\AiException;
/** Sortie JSON réservée à l’accompagnement ; les autres assistants restent inchangés. */
final class JsonClient {
 public static function chat(string $system,array $messages,?callable $transport=null,string $mode='resume',array $refs=[]):string {
  if(config('ai.provider')!=='openai_compatible')throw new AiException('Le service d’accompagnement doit être configuré pour les réponses structurées.');
  $c=config('ai.openai_compatible',[]);if(!is_array($c)||empty($c['api_key'])||empty($c['endpoint'])||empty($c['model']))throw new AiException('Le service d’accompagnement est indisponible.');
  $object=static function(array $keys):array{return ['type'=>'object','properties'=>$keys===[]?(object)[]:array_fill_keys($keys,['type'=>'string','maxLength'=>1000]),'required'=>$keys,'additionalProperties'=>false];};
  $schema=['type'=>'object','properties'=>['reply'=>['type'=>'string'],'questions'=>['type'=>'array','items'=>['type'=>'string']],'fields'=>$object($mode==='resume'?array_keys(Assistant::FIELDS):[]),'eogi'=>$object($mode==='eogi'?array_keys(\App\Atelier\Grille::fields('eogi')):[])],'required'=>['reply','questions','fields','eogi'],'additionalProperties'=>false];
  $valid=array_values(array_filter($refs,static fn($ref)=>is_string($ref)&&preg_match('/^S[0-9]+$/D',$ref)));
  $schema['properties']['used_refs']=$valid!==[]&&in_array($mode,['eogi','trame'],true)?['type'=>'array','items'=>['type'=>'string','enum'=>$valid],'minItems'=>1,'maxItems'=>count($valid)]:['type'=>'array','items'=>['type'=>'string'],'maxItems'=>0];
  $schema['required'][]='used_refs';
  $schema['properties']['questions']['maxItems']=$mode==='preciser'?3:2;
  $schema['properties']['reply']['maxLength']=match($mode){'resume'=>1200,'preciser'=>200,'eogi'=>1000,'trame'=>3500,default=>1200};
  $schema['properties']['questions']['items']['maxLength']=320;
  if($mode==='eogi')foreach($schema['properties']['eogi']['properties'] as &$property)$property['maxLength']=500;unset($property);
  $body=['model'=>(string)$c['model'],'max_tokens'=>min(5000,max(2000,(int)config('ai.max_tokens',4000))),'temperature'=>0.1,'response_format'=>['type'=>'json_schema','json_schema'=>['name'=>'preparation_guidee_v1','strict'=>true,'schema'=>$schema]],'messages'=>[['role'=>'system','content'=>$system],...$messages]];
  $data=$transport?$transport($body):\App\Ai\Http::postJson((string)$c['endpoint'],['Authorization: Bearer '.$c['api_key']],$body,(int)config('ai.timeout',120));
  if(($data['choices'][0]['finish_reason']??'')==='length')throw new AiException('La proposition dépasse la longueur prévue. Demandez une version plus courte.');
  $text=$data['choices'][0]['message']['content']??'';if(!is_string($text)||trim($text)==='')throw new AiException('La proposition est vide. Aucun champ n’a été modifié.');return $text;
 }
}
