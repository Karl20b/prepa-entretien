<?php
declare(strict_types=1);
namespace App\Preparation;
use PDO;
use App\Repo\SituationRepo;
use App\Repo\AtelierRepo;
use App\Atelier\Grille;
final class Controller {
 public static function answer(PDO $pdo,string $user,array $post,array &$sessions,callable $chat,callable $reserve):array {
  foreach($sessions as $k=>$s)if(($s['expires']??0)<time())unset($sessions[$k]);
  $tab=(string)($post['draft_id']??'');$request=(string)($post['request_id']??'');$mode=(string)($post['mode']??'');
  if(!preg_match('/^[a-f0-9]{32}$/D',$tab)||!preg_match('/^[a-f0-9]{32}$/D',$request)||!in_array($mode,Assistant::MODES,true))throw new \InvalidArgumentException('Demande d’accompagnement invalide.');
  $sid=(int)($post['id']??0);if($sid<0||($sid>0&&!(new SituationRepo($pdo))->find($sid,$user)))throw new \InvalidArgumentException('Situation introuvable.');
  $question=$post['question']??'';if(!is_string($question)||mb_strlen($question)>4000)throw new \InvalidArgumentException('Message limité à 4 000 caractères.');
  $raw=$post['draft']??'';if(!is_string($raw)||strlen($raw)>200000)throw new \InvalidArgumentException('Situation trop longue.');
  try{$draft=json_decode($raw,true,8,JSON_THROW_ON_ERROR);}catch(\JsonException $e){throw new \InvalidArgumentException('Situation illisible.');}
  if(!is_array($draft))throw new \InvalidArgumentException('Situation invalide.');$draft=Assistant::clean($draft);$hash=Assistant::hash($draft);$key=hash('sha256',$user.':'.$tab);
  if(isset($sessions[$key])&&$sessions[$key]['sid']!==$sid)throw new \InvalidArgumentException('Une discussion appartient à une seule situation.');
  if(!isset($sessions[$key])){while(count($sessions)>=4)array_shift($sessions);$sessions[$key]=['sid'=>$sid,'user'=>$user,'hash'=>$hash,'history'=>[],'requests'=>[],'tokens'=>[],'expires'=>time()+3600];}
  $state=&$sessions[$key];$inputHash=hash('sha256',$mode."\0".$hash."\0".$question);
  if(isset($state['requests'][$request])){$r=$state['requests'][$request];if($r['hash']!==$inputHash)throw new \InvalidArgumentException('Référence déjà utilisée pour une autre demande.');if(!isset($r['result']))throw new \RuntimeException('Cette demande a échoué ou son résultat est incertain. Aucun nouvel appel automatique n’est effectué. Modifiez votre demande pour relancer volontairement.');return $r['result'];}
  if($state['hash']!==$hash){$state['hash']=$hash;$state['history']=[];}
  $state['expires']=time()+3600;$reserve();while(count($state['requests'])>=8)array_shift($state['requests']);$state['requests'][$request]=['hash'=>$inputHash];
  $sources=[];$block='';
  if(in_array($mode,['eogi','trame'],true)){
   $query=$mode==='eogi'?'EOGI analyse systémique environnement organisation groupe individu interactions hypothèses':(new \App\Prompt\PromptBuilder())->searchQuery($draft).' trame entretien GROW SMART questions ouvertes';
   $chunks=(new \App\Reference\Sources($pdo))->search($draft,$query,6,$mode==='eogi'?['systemique']:\App\Domain\TypeEntretien::fromValue($draft['type_entretien'])->categories());
   [$block,$sources]=(new \App\Prompt\PromptBuilder(24000))->sources($chunks);
  }
  [$system,$messages]=Assistant::request($mode,$draft,trim($question),$state['history'],$block);$rawAnswer=$chat($system,$messages,$mode,$sources);$result=Assistant::parse($rawAnswer,$mode,$sources);$sources=array_values(array_filter($sources,static fn($source)=>in_array($source['ref'],$result['used_refs'],true)));
  $token=bin2hex(random_bytes(24));while(count($state['tokens'])>=6)array_shift($state['tokens']);$state['tokens'][$token]=['mode'=>$mode,'reply'=>$result['reply'],'draft_hash'=>$hash,'sources'=>$sources,'cdc_role'=>$draft['cdc_role'],'expires'=>time()+3600];
  $result+=['mode'=>$mode,'sources'=>$sources,'token'=>$token];
  $state['history'][]=['message_du_cadre'=>trim($question),'questions_de_clarification'=>$result['questions']];$state['history']=array_slice($state['history'],-6);$state['requests'][$request]['result']=$result;
  return $result;
 }
 public static function quota(string $user,string $private):void {
  $dir=$private.'/preparation-limits';if(!is_dir($dir)&&!mkdir($dir,0700,true)&&!is_dir($dir))throw new \RuntimeException('Accompagnement indisponible.');
  $path=$dir.'/'.hash('sha256',$user).'.json';$f=fopen($path,'c+');if(!$f)throw new \RuntimeException('Accompagnement indisponible.');
  try{if(!flock($f,LOCK_EX))throw new \RuntimeException('Accompagnement indisponible.');$times=json_decode(stream_get_contents($f),true)?:[];$times=array_values(array_filter($times,fn($t)=>is_int($t)&&$t>time()-3600));if(count($times)>=30)throw new \RuntimeException('Limite de 30 demandes par heure atteinte. Vous pouvez continuer votre préparation au clavier.');$times[]=time();ftruncate($f,0);rewind($f);fwrite($f,json_encode($times));fflush($f);chmod($path,0600);}finally{flock($f,LOCK_UN);fclose($f);}
 }
 public static function serve(PDO $pdo,string $user):never {
  header('Content-Type: application/json; charset=utf-8');
  try{if(($_SERVER['REQUEST_METHOD']??'')!=='POST'){http_response_code(405);throw new \InvalidArgumentException('Méthode non autorisée.');}
   $sessions=&$_SESSION['preparation_chats'];if(!is_array($sessions))$sessions=[];set_time_limit(150);
   $result=self::answer($pdo,$user,$_POST,$sessions,fn($system,$messages,$mode,$sources)=>JsonClient::chat($system,$messages,null,$mode,array_column($sources,'ref')),fn()=>self::quota($user,(string)config('app.private_dir')));
   echo json_encode(['ok'=>true]+$result,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
  }catch(\InvalidArgumentException|\RuntimeException $e){if(http_response_code()===200)http_response_code(400);echo json_encode(['ok'=>false,'error'=>$e->getMessage()],JSON_UNESCAPED_UNICODE);}
  exit;
 }
 private static function origin(string $user,int $sid,string $token,string $mode):?array {
  foreach($_SESSION['preparation_chats']??[] as $state){
   if(($state['user']??null)!==$user||!in_array((int)$state['sid'],[0,$sid],true))continue;
   $candidate=$state['tokens'][$token]??null;if($candidate&&$candidate['expires']>time()&&$candidate['mode']===$mode)return $candidate;
  }return null;
 }
 /** Prépare puis applique uniquement les reprises explicitement retenues. Appeler dans la transaction du formulaire. */
 public static function saveAdditions(PDO $pdo,string $user,int $sid,array $post):void {
  $s=(new SituationRepo($pdo))->find($sid,$user);if(!$s)throw new \InvalidArgumentException('Situation introuvable.');
  $raw=$post['prepa_eogi']??'';
  if(is_string($raw)&&$raw!==''){
   if(strlen($raw)>50000)throw new \InvalidArgumentException('Reprise EOGI trop longue.');
   try{$payload=json_decode($raw,true,8,JSON_THROW_ON_ERROR);}catch(\JsonException $e){throw new \InvalidArgumentException('Reprise EOGI illisible.');}
   if(!is_array($payload)||!is_array($payload['fields']??null)||!is_int($payload['revision']??null)||!is_array($payload['replace']??null)||array_diff(array_keys($payload['fields']),array_keys(Grille::fields('eogi'))))throw new \InvalidArgumentException('Reprise EOGI invalide.');
   $repo=new AtelierRepo($pdo);$row=$repo->find($sid,'eogi',$user);$revision=(int)($row['revision']??0);if($revision!==$payload['revision'])throw new \RuntimeException('Votre grille EOGI a changé dans un autre onglet. Retirez la reprise EOGI, puis rechargez et rapprochez vos textes.');
   $data=$row['data']??[];
   foreach($payload['fields'] as $key=>$value){if(!is_string($value)||trim($value)===''||mb_strlen($value)>4000)throw new \InvalidArgumentException('Texte EOGI invalide.');if(trim((string)($data[$key]??''))!==''&&!in_array($key,$payload['replace'],true))throw new \InvalidArgumentException('Le remplacement d’un champ EOGI existant doit être confirmé.');$data[$key]=trim($value);}
   if($payload['fields']!==[]){
    $origin=self::origin($user,$sid,(string)($payload['token']??''),'eogi');
    if(!$origin||($origin['cdc_role']??null)!==($s['cdc_role']??null))throw new \InvalidArgumentException('La proposition EOGI a expiré ou le CDC a changé. Retirez la reprise et demandez une actualisation.');
    if(!hash_equals((string)($origin['draft_hash']??''),Assistant::hash(Assistant::clean($s))))throw new \InvalidArgumentException('La situation a changé après la proposition EOGI. Retirez sa reprise et demandez une actualisation.');
    $allText=implode("\n",$payload['fields']);preg_match_all('/\[(S[0-9]+)\]/',$allText,$refs);if(array_diff(array_unique($refs[1]),array_column($origin['sources'],'ref')))throw new \InvalidArgumentException('Une référence EOGI est inconnue. Vérifiez le texte repris.');
    $saved=$repo->save($sid,'eogi',$user,$data,$revision);
    $st=$pdo->prepare('INSERT INTO pe_atelier_messages(situation_id,kind,role,content,sources,provider,revision,context_hash) VALUES(?,?,?,?,?,?,?,?)');
    $context=Grille::contextHash($s);
    $st->execute(\App\Security\Vault::values('pe_atelier_messages',['situation_id','kind','role','content','sources','provider','revision','context_hash'],[$sid,'eogi','user','Reprise EOGI relue et retenue depuis l’accompagnement.',null,null,(int)$saved['revision'],$context]));
    $st->execute(\App\Security\Vault::values('pe_atelier_messages',['situation_id','kind','role','content','sources','provider','revision','context_hash'],[$sid,'eogi','assistant',$origin['reply'],json_encode($origin['sources'],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),'Accompagnement guidé · proposition source',(int)$saved['revision'],$context]));
   }
  }
  $text=$post['prepa_trame']??'';
  if(!is_string($text)||mb_strlen($text)>16000)throw new \InvalidArgumentException('Trame limitée à 16 000 caractères.');
  if(trim($text)!==''){
   $token=(string)($post['prepa_trame_token']??'');$origin=null;
   $origin=self::origin($user,$sid,$token,'trame');
   if(!$origin||($origin['cdc_role']??null)!==($s['cdc_role']??null))throw new \InvalidArgumentException('La trame a expiré ou le CDC a changé. Retirez sa reprise et demandez une trame actualisée.');
   if(!hash_equals((string)($origin['draft_hash']??''),Assistant::hash(Assistant::clean($s))))throw new \InvalidArgumentException('La situation a changé après la proposition de trame. Retirez sa reprise et demandez une actualisation.');
   preg_match_all('/\[(S[0-9]+)\]/',$text,$refs);if(array_diff(array_unique($refs[1]),array_column($origin['sources'],'ref')))throw new \InvalidArgumentException('Une référence de la trame est inconnue.');
   \App\Rag\SourceValidator::check($text,$origin['sources']);
   (new \App\Repo\MessageRepo($pdo))->add($sid,'assistant',"## Trame relue et retenue par le cadre\n\n".trim($text),$origin['sources'],'Relue et validée par le cadre',$s['cdc_role']??null);
  }
 }
}
