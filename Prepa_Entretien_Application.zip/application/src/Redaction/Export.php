<?php
declare(strict_types=1);
namespace App\Redaction;
final class Export {
 public static function plain(string $s):string{return preg_replace('/\*\*(.*?)\*\*|__(.*?)__|`([^`]+)`/u','$1$2$3',$s)??$s;}
 public static function blocks(string $text):array {
  $out=[];$para=[];$table=[];
  $flush=function()use(&$out,&$para,&$table){if($para){$out[]=['p',implode("\n",$para)];$para=[];}if($table){$out[]=['table',$table];$table=[];}};
  foreach(explode("\n",str_replace("\r",'',$text)) as $line){$line=trim($line);if($line===''){$flush();continue;}
   if(str_starts_with($line,'|')){if($para)$flush();if(!preg_match('/^\|?\s*:?-{2,}/',$line))$table[]=array_map('trim',explode('|',trim($line," |")));continue;}
   if($table)$flush();
   if(preg_match('/^#{1,6}\s+(.+)$/u',$line,$m)){$flush();$out[]=['h',$m[1]];}
   elseif(preg_match('/^(?:[-*•]|\d+[.)])\s+(.+)$/u',$line,$m)){$flush();$out[]=['li',$m[1]];}
   elseif(preg_match('/^(?:---+|\*\*\*+)$/',$line)){$flush();}
   else $para[]=$line;
  }$flush();return $out;
 }
 private static function x(string $s):string{return htmlspecialchars(preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/u','',$s)??'',ENT_XML1|ENT_QUOTES,'UTF-8');}
 private static function runs(string $s):string {
  $s=self::plain($s);$out='';foreach(explode("\n",$s) as $i=>$line){if($i)$out.='<w:r><w:br/></w:r>';$out.='<w:r><w:t xml:space="preserve">'.self::x($line).'</w:t></w:r>';}return $out;
 }
 private static function paragraph(string $s,string $style='Normal'):string{return '<w:p><w:pPr><w:pStyle w:val="'.$style.'"/></w:pPr>'.self::runs($s).'</w:p>';}
 public static function docx(string $title,string $text,array $sources=[],bool $stale=false):string {
  $body=self::paragraph($title,'Title').self::paragraph('Document de préparation · '.date('d.m.Y').' · Version de travail','Subtitle');
  if($stale)$body.=self::paragraph('À réexaminer : la situation ou la proposition a évolué depuis cette version.');
  foreach(self::blocks($text) as [$kind,$value]){
   if($kind==='table'){$body.='<w:tbl><w:tblPr><w:tblCellMar><w:top w:w="120" w:type="dxa"/><w:left w:w="120" w:type="dxa"/><w:bottom w:w="60" w:type="dxa"/><w:right w:w="120" w:type="dxa"/></w:tblCellMar><w:tblW w:w="0" w:type="auto"/><w:tblBorders><w:top w:val="single" w:sz="4" w:color="D3DDE3"/><w:left w:val="single" w:sz="4" w:color="D3DDE3"/><w:bottom w:val="single" w:sz="4" w:color="D3DDE3"/><w:right w:val="single" w:sz="4" w:color="D3DDE3"/><w:insideH w:val="single" w:sz="4" w:color="D3DDE3"/><w:insideV w:val="single" w:sz="4" w:color="D3DDE3"/></w:tblBorders></w:tblPr>';
    foreach($value as $i=>$row){$body.='<w:tr>'.($i===0?'<w:trPr><w:tblHeader/></w:trPr>':'');foreach($row as $cell)$body.='<w:tc><w:tcPr><w:tcW w:w="'.intdiv(9360,max(1,count($row))).'" w:type="dxa"/>'.($i===0?'<w:shd w:fill="EDF3F4"/>':'').'</w:tcPr>'.self::paragraph($cell).'</w:tc>';$body.='</w:tr>';}$body.='</w:tbl>'.self::paragraph('');
   }else $body.=self::paragraph(($kind==='li'?'• ':'').$value,$kind==='h'?'Heading1':'Normal');
  }
  if($sources){$body.=self::paragraph('Références à vérifier','Heading1');foreach($sources as $s)$body.=self::paragraph('['.($s['ref']??'').'] '.($s['titre']??'').' — '.($s['source']??''));}
  $body.=self::paragraph('Support de préparation : relire les faits, distinguer les hypothèses et convenir des engagements avec la personne.','Subtitle');
  $body.='<w:sectPr><w:footerReference w:type="default" r:id="rIdFooter"/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1273" w:bottom="1134" w:left="1273" w:header="567" w:footer="567"/></w:sectPr>';
  $xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
  $parts=[
   '[Content_Types].xml'=>$xml.'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/footer.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>',
   '_rels/.rels'=>$xml.'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>',
   'word/document.xml'=>$xml.'<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><w:body>'.$body.'</w:body></w:document>',
   'word/_rels/document.xml.rels'=>$xml.'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rIdFooter" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer.xml"/></Relationships>',
   'word/styles.xml'=>$xml.'<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/><w:sz w:val="22"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="160" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style><w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:after="200"/></w:pPr><w:rPr><w:b/><w:color w:val="000000"/><w:sz w:val="40"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Subtitle"><w:name w:val="Subtitle"/><w:basedOn w:val="Normal"/><w:rPr><w:color w:val="52666D"/><w:sz w:val="19"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="260" w:after="120"/><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/><w:color w:val="203D44"/><w:sz w:val="28"/></w:rPr></w:style></w:styles>',
   'word/footer.xml'=>$xml.'<w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:p><w:pPr><w:jc w:val="right"/></w:pPr><w:r><w:t>Prépa Entretien · </w:t></w:r><w:fldSimple w:instr="PAGE"/></w:p></w:ftr>'
  ];return self::zip($parts);
 }
 private static function zip(array $parts):string {
  $body='';$central='';$count=0;foreach($parts as $name=>$data){$crc=crc32($data);$size=strlen($data);$offset=strlen($body);$body.=pack('VvvvvvVVVvv',0x04034b50,20,0,0,0,33,$crc,$size,$size,strlen($name),0).$name.$data;$central.=pack('VvvvvvvVVVvvvvvVV',0x02014b50,20,20,0,0,0,33,$crc,$size,$size,strlen($name),0,0,0,0,0,$offset).$name;$count++;}return $body.$central.pack('VvvvvVVv',0x06054b50,0,0,$count,$count,strlen($central),strlen($body),0);
 }
 public static function pdf(string $title,string $text,array $sources=[],bool $stale=false):string {
  require_once APP_ROOT.'/vendor/tfpdf/tfpdf.php';
  $pdf=new class extends \tFPDF {public function Footer(){ $this->SetY(-15);$this->SetFont('DejaVu','',8);$this->SetTextColor(90,105,110);$this->Cell(0,6,'Prépa Entretien · '.$this->PageNo().'/{nb}',0,0,'R');}};
  $pdf->AddFont('DejaVu','','DejaVuSansCondensed.ttf',true);$pdf->AddFont('DejaVu','B','DejaVuSansCondensed-Bold.ttf',true);$pdf->SetMargins(22,20,22);$pdf->SetAutoPageBreak(true,22);$pdf->AliasNbPages();$pdf->AddPage();$pdf->SetTitle($title,true);$pdf->SetAuthor('Prépa Entretien',true);
  $p=function(string $text,bool $heading=false)use($pdf){if($heading&&$pdf->GetY()>245)$pdf->AddPage();$pdf->SetFont('DejaVu',$heading?'B':'',$heading?13:10);$pdf->SetTextColor(...($heading?[32,61,68]:[30,40,45]));$pdf->MultiCell(0,$heading?7:5.3,self::plain($text),0,'L');$pdf->Ln($heading?3:2);};
  $pdf->SetFont('DejaVu','B',20);$pdf->SetTextColor(32,61,68);$pdf->MultiCell(0,10,$title,0,'L');$pdf->Ln(3);$p('Document de préparation · '.date('d.m.Y').' · Version de travail');
  if($stale)$p('À réexaminer : la situation ou la proposition a évolué depuis cette version.');
  foreach(self::blocks($text) as [$kind,$value]){
   if($kind==='table'){$heads=array_shift($value);foreach($value as $row){foreach($row as $i=>$cell)$p(($heads[$i]??'Rubrique').' : '.$cell);$pdf->Ln(2);}}
   else $p(($kind==='li'?'• ':'').$value,$kind==='h');
  }
  if($sources){$p('Références à vérifier',true);foreach($sources as $s)$p('['.($s['ref']??'').'] '.($s['titre']??'').' — '.($s['source']??''));}
  $p('Support de préparation : relire les faits, distinguer les hypothèses et convenir des engagements avec la personne.');return $pdf->Output('S');
 }
 public static function send(string $format,string $title,string $text,array $sources,bool $stale,string $filename):never {
  $bytes=$format==='pdf'?self::pdf($title,$text,$sources,$stale):self::docx($title,$text,$sources,$stale);
  header('Content-Type: '.($format==='pdf'?'application/pdf':'application/vnd.openxmlformats-officedocument.wordprocessingml.document'));header('Content-Disposition: attachment; filename="'.$filename.'.'.$format.'"');header('Cache-Control: no-store, private');header('Pragma: no-cache');header('X-Content-Type-Options: nosniff');header('Content-Length: '.strlen($bytes));session_write_close();echo $bytes;exit;
 }
}
