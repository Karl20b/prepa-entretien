<?php
declare(strict_types=1);
namespace App\Redaction;
final class Controller {
 public static function serve(\PDO $pdo,string $user,string $action,int $id):never {
  $kind=(string)($_POST['kind']??$_GET['kind']??'entretien');$repo=new Repository($pdo);
  try{$source=$repo->source($id,$kind,$user);$draft=$repo->find($id,$kind,$user);}catch(\InvalidArgumentException){\not_found();}
  $text=($_GET['use_source']??'')==='1'?$source['text']:($draft['contenu']??$source['text']);$prepared=false;if($kind==='feedback'&&!FeedbackDossier::complete($text)){$text=FeedbackDossier::build($source,$text);$prepared=true;}$error='';$json=str_contains($_SERVER['HTTP_ACCEPT']??'','application/json');
  if($action==='redaction_download'){
   if(!in_array($_SERVER['REQUEST_METHOD']??'GET',['GET','HEAD'],true)){http_response_code(405);exit;}
   $format=(string)($_GET['format']??'');if(!$draft||!in_array($format,['docx','pdf'],true))\not_found();
   if($kind==='feedback'&&!FeedbackDossier::complete($draft['contenu'])){\flash('Votre ancienne trame est reprise dans une fiche complète. Relisez-la et enregistrez-la avant le téléchargement.','success');\redirect('index.php?action=redaction&id='.$id.'&kind=feedback');}
   Export::send($format,Repository::label($kind).' — '.$source['s']['titre'],$draft['contenu'],$draft['sources'],Repository::stale($draft,$source),'prepa-'.$kind.'-'.$id);
  }
  if($action==='redaction_save'){
   if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST'){http_response_code(405);exit;}
   $text=is_string($_POST['contenu']??null)?$_POST['contenu']:'';
   try{
    if(isset($_POST['sections']))$text=Text::compose($_POST['sections']);
    $format=(string)($_POST['format']??'save');if(!in_array($format,['save','docx','pdf'],true))throw new \InvalidArgumentException('Format inconnu.');
    if($kind==='feedback'&&$format!=='save'&&!FeedbackDossier::complete($text))throw new \InvalidArgumentException('Rouvrez la fiche de feed-back pour compléter et relire le document avant son export.');
    $draft=$repo->save($id,$kind,$user,$text,(int)($_POST['revision']??0),(string)($_POST['source_hash']??''),(string)($_POST['context_hash']??''));
    if($json){header('Content-Type: application/json');header('Cache-Control: no-store');echo json_encode(['ok'=>true,'revision'=>$draft['revision'],'download'=>$format==='save'?null:'index.php?action=redaction_download&id='.$id.'&kind='.$kind.'&format='.$format]);exit;}
    if($format!=='save')Export::send($format,Repository::label($kind).' — '.$source['s']['titre'],$draft['contenu'],$draft['sources'],Repository::stale($draft,$source),'prepa-'.$kind.'-'.$id);
    \flash('Votre version de travail est enregistrée. Les réponses IA d’origine sont conservées.','success');\redirect('index.php?action=redaction&id='.$id.'&kind='.$kind);
   }catch(\InvalidArgumentException|\RuntimeException $e){$error=$e->getMessage();http_response_code($e instanceof \InvalidArgumentException?422:409);if($json){header('Content-Type: application/json');echo json_encode(['ok'=>false,'error'=>$error]);exit;}}
  }
  \render('redaction',['source'=>$source,'draft'=>$draft,'text'=>$text,'kind'=>$kind,'error'=>$error,'prepared'=>$prepared],Repository::label($kind).' · Modifier');exit;
 }
}
