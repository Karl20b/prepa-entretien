<?php
declare(strict_types=1);
namespace App\Redaction;
/** Presentation-only adapter. Canonical storage stays plain Markdown, never HTML. */
final class Text {
 public static function sections(string $text):array {
  $sections=[];$title='';$lines=[];
  $flush=static function()use(&$sections,&$title,&$lines){if($title!==''||$lines)$sections[]=['title'=>$title,'body'=>trim(implode("\n",$lines))];$lines=[];};
  foreach(Export::blocks($text) as [$kind,$v]){
   if($kind==='h'){$flush();$title=Export::plain($v);}
   elseif($kind==='table'){$heads=array_shift($v);foreach($v as $row){$parts=[];foreach($row as $i=>$cell)$parts[]=Export::plain(($heads[$i]??'Rubrique').' : '.$cell);$lines[]=implode(' — ',$parts);$lines[]='';}}
   else{$lines[]=($kind==='li'?'• ':'').Export::plain($v);$lines[]='';}
  }$flush();return $sections?:[['title'=>'Votre texte','body'=>'']];
 }
 public static function compose(mixed $sections):string {
  if(!is_array($sections)||count($sections)>120)throw new \InvalidArgumentException('Document invalide ou trop de rubriques.');
  $out=[];foreach($sections as $s){if(!is_array($s)||!is_string($s['title']??null)||!is_string($s['body']??null))throw new \InvalidArgumentException('Une rubrique contient une valeur non valide.');$title=trim(str_replace(["\r","\n"],' ',$s['title']));if(mb_strlen($title)>300)throw new \InvalidArgumentException('Titre trop long.');$body=trim(str_replace("\r",'',$s['body']));$out[]=($title!==''?'## '.$title."\n":'').$body;}
  $text=trim(implode("\n\n",$out));return $text;
 }
}
