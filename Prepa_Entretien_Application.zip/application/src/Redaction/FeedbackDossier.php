<?php
declare(strict_types=1);
namespace App\Redaction;

/** Fiche éditable préparée sans appel IA et sans inventer les éléments manquants. */
final class FeedbackDossier {
 public static function complete(string $text):bool {
  return str_contains($text,'## Repères pour conduire le feed-back') && str_contains($text,'## Trace de l’entretien et suivi');
 }
 public static function hasContent(string $text):bool {
  foreach(Export::blocks($text) as [$kind,$v])if($kind!=='h'&&($kind==='table'||trim(Export::plain($v))!==''))return true;
  return false;
 }
 private static function value(mixed $v,string $missing='À compléter avant l’entretien'):string {
  return trim((string)$v)!==''?trim((string)$v):$missing;
 }
 public static function build(array $source,string $working):string {
  if(self::complete($working))return $working;
  if(!self::hasContent($working)&&self::hasContent($source['text']??''))$working=$source['text'];
  $s=$source['s'];$grid=$source['feedback_data']??[];
  $mode=match($grid['mode']??''){'amelioration'=>'amélioration','valorisation'=>'valorisation',default=>'à choisir avant l’entretien'};
  $steps=array_fill(1,6,[]);$other=[];
  $proposal=trim((string)($source['feedback_proposal']??''));if($proposal!==''&&self::hasContent($proposal)&&trim($working)!==$proposal)$other[]='Proposition complète de l’assistant à confronter à vos corrections'.(($source['stale']??false)?' — ancienne proposition à réexaminer':'')."\n".$proposal;
  foreach(Text::sections($working) as $part){
   if(trim($part['body'])==='')continue;
   if(preg_match('/^\s*([1-6])(?:\s|[.·:)\-])/u',$part['title'],$m))$steps[(int)$m[1]][]=$part['body'];
   else $other[]=($part['title']!==''?$part['title']."\n":'').$part['body'];
  }
  $out=["## Repères pour conduire le feed-back\nSupport personnel du cadre pour préparer les formulations, écouter la personne et convenir de la suite. Les propositions ci-dessous sont à adapter ; les réponses et accords seront renseignés pendant l’entretien.",
   "Situation : ".self::value($s['titre']??null)."\nType de feed-back : ".$mode."\nCollaborateur ou référence : ".self::value($s['collaborateur_ref']??null)."\nFonction : ".self::value($s['fonction']??null)."\nDate de l’entretien : ".self::value($s['date_entretien']??null,'À convenir')."\nLieu et durée prévus : à préciser",
   "## Situation et intention du cadre\nContexte rapporté\n".self::value($s['contexte']??null)."\n\nFaits observés rapportés dans la situation\n".self::value($s['faits']??null)."\n\nCe que le cadre souhaite obtenir\n".self::value($s['objectif_manager']??null)."\n\nEnjeux perçus par le cadre\n".self::value($s['enjeux']??null),
   "## Ouverture proposée à adapter\n".($mode==='amélioration'
    ?'« Je souhaite revenir avec vous sur une situation précise, comprendre votre point de vue et chercher ensemble une manière de progresser. Je vais présenter les faits et leurs effets, puis vous laisser les compléter. »'
    :($mode==='valorisation'?'« Je souhaite prendre un moment pour reconnaître une contribution précise, comprendre ce qui vous a aidé et voir ensemble comment prolonger cette réussite. »':'« Je souhaite échanger avec vous sur une situation de travail, écouter votre point de vue et convenir ensemble de la suite. »'))."\n\nAvant de commencer, confirmer le temps disponible et le sujet de l’échange. Choisir un cadre permettant de parler sans interruption."];
  $keys=['faits','effets','ecoute','attentes','suite','suivi'];
  $titles=['Exposer les faits','Informer des effets','Questionner et écouter','Reformuler et clarifier les attentes','Co-construire la suite','Valoriser et assurer le suivi'];
  $guides=[
   "Présenter une situation datée et un comportement observable. Séparer l’observation de son interprétation et préciser si le fait est observé directement ou rapporté.\n\nFormulation à adapter\n« Lors de [situation et date], j’ai observé [comportement précis]. Est-ce également ce que vous avez constaté ? Souhaitez-vous compléter ou corriger ce point ? »\n\nÀ noter pendant l’échange\nFaits confirmés, corrections et points restant à vérifier : …",
   "Expliquer ce que le comportement a produit concrètement sur le travail, l’équipe ou le service. Nommer séparément le ressenti du cadre et les risques possibles ; ne pas présenter ces derniers comme des conséquences déjà survenues.\n\nFormulation à adapter\n« L’effet que j’ai constaté est [effet observable]. De votre côté, quels effets avez-vous remarqués ? »\n\nÀ noter pendant l’échange\nEffets reconnus et autres conséquences signalées : …",
   "Poser une question à la fois, laisser un silence et écouter avant de chercher une solution. Demander des exemples et reformuler sans attribuer d’intention.\n\nQuestions possibles\n• Comment avez-vous vécu cette situation ?\n• Qu’est-ce qui vous a aidé ou freiné dans votre travail ?\n• Qu’auriez-vous besoin de clarifier ou de recevoir comme soutien ?\n\nPropos réellement recueillis\n…\n\nInformations nouvelles et points de désaccord\n…",
   "Vérifier la compréhension mutuelle avant d’énoncer l’attente. Relier celle-ci à une tâche, un rôle ou une exigence connue, en vérifiant le CDC applicable. Éviter les jugements sur la personnalité.\n\nFormulation à adapter\n« Si je vous comprends bien, [reformulation de ce qui vient d’être dit]. Est-ce juste ? Pour la suite, j’attends [comportement ou résultat observable]. Comment comprenez-vous cette attente ? »\n\nAttente clarifiée et compréhension exprimée\n…",
   "Explorer les options avant de retenir une action. Distinguer ce qui dépend du collaborateur, du cadre et de l’organisation. Vérifier les moyens, la charge de travail et les éventuelles contraintes.\n\nQuestions possibles\n• Quelle première action vous paraît réalisable ?\n• De quels moyens ou appuis auriez-vous besoin ?\n• Quel résultat observable permettrait de voir un progrès, et à quelle échéance ?\n\nOptions proposées et choix réellement convenus\n…\n\nSi aucun accord n’est obtenu, noter le désaccord et la prochaine étape ; ne pas inscrire une proposition comme un engagement.",
   "Reconnaître une contribution précise ou un effort effectivement constaté. Récapituler ce qui a été convenu et demander à la personne de le reformuler. Fixer ensemble un point de retour et la manière d’observer les progrès.\n\nFormulation à adapter\n« Nous retenons [action convenue], avec [soutien] et un retour le [date à convenir]. Qu’en retenez-vous ? Que devons-nous encore préciser ? »\n\nConclusion et soutien proposés par le cadre\n…"
  ];
  foreach($keys as $i=>$key){
   $n=$i+1;$parts=["## $n ".$titles[$i]];
   if($steps[$n])$parts[]="Formulation ou notes de votre version de travail\n".implode("\n\n",$steps[$n]);
   $v=trim((string)($grid[$key]??''));
   if($v!==''&&!in_array($v,$steps[$n],true))$parts[]="Éléments renseignés dans la grille\n".$v;
   if(!$steps[$n]&&$v==='')$parts[]='Éléments propres à la situation à préciser avant ou pendant l’entretien.';
   $parts[]=$guides[$i];$out[]=implode("\n\n",$parts);
  }
  if($other)$out[]="## Propositions et notes complémentaires à relire\n".implode("\n\n",$other);
  $out[]="## Points de vigilance pour le cadre\n• Distinguer les faits, les perceptions et les hypothèses. Vérifier les informations incertaines avec la personne.\n• Ne pas supposer ses motivations, ses réponses ou son accord. Conserver la place pour son point de vue.\n• Vérifier les références utilisées et le CDC applicable. Si un point dépasse votre rôle, identifier l’interlocuteur compétent.\n• Ne noter que les éléments utiles à l’échange et conserver ce document dans un espace privé.";
  $out[]="## Trace de l’entretien et suivi\nÀ compléter avec les propos et engagements réellement recueillis.\n\n| Élément à consigner | Ce qui a été convenu ou reste à préciser |\n| --- | --- |\n| Compréhension commune et éventuels désaccords | À renseigner pendant l’entretien |\n| Action retenue et personne responsable | À convenir |\n| Soutien et moyens apportés par le cadre | À convenir |\n| Résultat attendu et indicateur observable | À convenir |\n| Échéance et date du point de suivi | À convenir |\n| Points non résolus et prochaine étape | À préciser |\n\nNotes après l’entretien\n…\n\nÉléments à communiquer et destinataires convenus\n…";
  return implode("\n\n",$out);
 }
}
