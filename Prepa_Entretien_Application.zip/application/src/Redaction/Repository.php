<?php
declare(strict_types=1);
namespace App\Redaction;
use App\Security\Vault;
use App\Repo\SituationRepo;
use PDO;
final class Repository {
 public function __construct(private readonly PDO $p){}
 public function source(int $id,string $kind,string $user):array {
  if(!in_array($kind,['entretien','eogi','feedback'],true))throw new \InvalidArgumentException('Document inconnu.');
  $s=(new SituationRepo($this->p))->find($id,$user);if(!$s)throw new \InvalidArgumentException('Situation introuvable.');
  $context=\App\Atelier\Grille::contextHash($s);$text='';$sources=[];$stale=false;$messageId=null;
  if($kind==='entretien'){
   $generation=false;$fallback=null;foreach((new \App\Repo\MessageRepo($this->p))->forSituation($id) as $m){if($m['role']==='user'){$generation=str_starts_with($m['contenu'],"Préparer l");continue;}if($m['role']==='assistant'&&($m['cdc_role']??null)===($s['cdc_role']??null)){$fallback=$m;if($generation){$text=$m['contenu'];$sources=$m['sources'];$messageId=(int)$m['id'];}}}if(!$text&&$fallback){$text=$fallback['contenu'];$sources=$fallback['sources'];$messageId=(int)$fallback['id'];}
  }else{
   $row=(new \App\Repo\AtelierRepo($this->p))->find($id,$kind,$user);
   if($row){$text=$row['analysis']??'';$sources=$row['sources'];$stale=(bool)$text&&((int)$row['analysis_revision']!==(int)$row['revision']||$row['context_hash']!==$context);$context=hash('sha256',$context.':'.$row['revision']);}
   if(!$text){$parts=[];foreach(\App\Atelier\Grille::fields($kind) as $k=>[$label,$help])$parts[]='## '.$label."\n".($row['data'][$k]??'');$text=implode("\n\n",$parts);}
  }
  if(!$text)$text="## Lecture de la situation\n".($s['contexte']??'')."\n\n## Faits observés\n".($s['faits']??'')."\n\n## Objectif de l’entretien\n".($s['objectif_manager']??'')."\n\n## Questions et déroulement\n\n## Suite et suivi à convenir\n";
  return ['s'=>$s,'text'=>$text,'sources'=>$sources,'hash'=>hash('sha256',$text.json_encode($sources)),'context'=>$context,'stale'=>$stale,'message_id'=>$messageId];
 }
 public function find(int $id,string $kind,string $user):?array {
  if(!(new SituationRepo($this->p))->find($id,$user))throw new \InvalidArgumentException('Situation introuvable.');
  $q=$this->p->prepare('SELECT * FROM pe_redactions WHERE situation_id=? AND kind=?');$q->execute([$id,$kind]);$r=$q->fetch();if(!$r)return null;$r['sources']=json_decode($r['sources'],true,512,JSON_THROW_ON_ERROR);return $r;
 }
 public function save(int $id,string $kind,string $user,string $text,int $revision,string $sourceHash,string $context):array {
  $text=trim(str_replace("\r",'', $text));if($text===''||mb_strlen($text)>60000)throw new \InvalidArgumentException('Le document doit contenir entre 1 et 60 000 caractères.');
  $this->p->exec('BEGIN IMMEDIATE');
  try{
   $source=$this->source($id,$kind,$user);if(!hash_equals($source['hash'],$sourceHash)||!hash_equals($source['context'],$context))throw new \RuntimeException('La situation, la grille ou la proposition a changé. Copiez vos corrections et rechargez pour rapprocher les versions.');
   $values=Vault::values('pe_redactions',['contenu','sources','source_hash','context_hash'],[$text,json_encode($source['sources'],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),$source['hash'],$context]);
   if($revision===0){$q=$this->p->prepare('INSERT OR IGNORE INTO pe_redactions(contenu,sources,source_hash,context_hash,situation_id,kind) VALUES(?,?,?,?,?,?)');$q->execute([...$values,$id,$kind]);}
   else{$q=$this->p->prepare('UPDATE pe_redactions SET contenu=?,sources=?,source_hash=?,context_hash=?,revision=revision+1,updated_at=NOW() WHERE situation_id=? AND kind=? AND revision=?');$q->execute([...$values,$id,$kind,$revision]);}
   if($q->rowCount()!==1)throw new \RuntimeException('Votre version de travail a été modifiée dans un autre onglet. Copiez vos corrections puis rechargez.');
   $r=$this->find($id,$kind,$user);$this->p->exec('COMMIT');return $r;
  }catch(\Throwable $e){if($this->p->inTransaction())$this->p->rollBack();throw $e;}
 }
 public static function stale(array $row,array $source):bool{return $source['stale']||$row['source_hash']!==$source['hash']||$row['context_hash']!==$source['context'];}
 public static function label(string $kind):string{return ['entretien'=>'Préparation de l’entretien','eogi'=>'Analyse EOGI','feedback'=>'Trame de feed-back'][$kind]??'Document de travail';}
}
