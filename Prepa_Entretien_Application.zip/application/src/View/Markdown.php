<?php
declare(strict_types=1);

namespace App\View;

/** Rendu Markdown minimal et sûr (tout est échappé avant mise en forme). */
final class Markdown
{
    public static function render(string $md): string
    {
        $html = '';
        $list = null;
        $para = [];
        $table = [];

        $flushPara = function () use (&$para, &$html): void {
            if ($para) {
                $html .= '<p>' . implode('<br>', $para) . '</p>';
                $para = [];
            }
        };
        $closeList = function () use (&$list, &$html): void {
            if ($list) {
                $html .= "</{$list}>";
                $list = null;
            }
        };
        $flushTable = function () use (&$table, &$html): void {
            if (!$table) {
                return;
            }
            $html .= '<table class="md-table">';
            foreach ($table as $i => $row) {
                if (preg_match('/^\|?\s*:?-{2,}/', $row)) {
                    continue;
                }
                $cells = array_map('trim', explode('|', trim($row, " |")));
                $tag = $i === 0 ? 'th' : 'td';
                $html .= '<tr>' . implode('', array_map(fn($c) => "<{$tag}>" . self::inline($c) . "</{$tag}>", $cells)) . '</tr>';
            }
            $html .= '</table>';
            $table = [];
        };

        foreach (explode("\n", str_replace("\r", '', $md)) as $line) {
            $t = trim($line);
            if (str_starts_with($t, '|')) {
                $flushPara();
                $closeList();
                $table[] = $t;
                continue;
            }
            $flushTable();

            if ($t === '') {
                $flushPara();
                $closeList();
            } elseif (preg_match('/^-{3,}$|^\*{3,}$/', $t)) {
                $flushPara();
                $closeList();
                $html .= '<hr>';
            } elseif (preg_match('/^(#{1,4})\s+(.+)$/u', $t, $m)) {
                $flushPara();
                $closeList();
                $lvl = min(6, strlen($m[1]) + 1);
                $html .= "<h{$lvl}>" . self::inline($m[2]) . "</h{$lvl}>";
            } elseif (preg_match('/^[-*•]\s+(.+)$/u', $t, $m) || preg_match('/^\d+[.)]\s+(.+)$/u', $t, $m)) {
                $flushPara();
                $type = ctype_digit($t[0]) ? 'ol' : 'ul';
                if ($list !== $type) {
                    $closeList();
                    $html .= "<{$type}>";
                    $list = $type;
                }
                $html .= '<li>' . self::inline($m[1]) . '</li>';
            } else {
                $closeList();
                $para[] = self::inline($t);
            }
        }
        $flushTable();
        $flushPara();
        $closeList();
        return $html;
    }

    private static function inline(string $s): string
    {
        $s = htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $s = preg_replace('/\*\*(.+?)\*\*/u', '<strong>$1</strong>', $s);
        $s = preg_replace('/(?<![*\w])\*(?!\s)(.+?)(?<!\s)\*(?![*\w])/u', '<em>$1</em>', $s);
        $s = preg_replace('/`([^`]+)`/u', '<code>$1</code>', $s);
        return preg_replace('/\[(S\d+)\]/u', '<span class="src-ref">$1</span>', $s);
    }
}
