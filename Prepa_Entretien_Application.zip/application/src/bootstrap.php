<?php
declare(strict_types=1);
define('APP_ROOT',dirname(__DIR__));
spl_autoload_register(static function(string $class):void {
 if(!str_starts_with($class,'App\\'))return;
 $file=APP_ROOT.'/src/'.str_replace('\\','/',substr($class,4)).'.php';if(is_file($file))require $file;
});
$configFile=APP_ROOT.'/config/config.php';
if(!is_file($configFile)){http_response_code(503);exit('Cet espace est en cours d’installation.');}
$GLOBALS['config']=require $configFile;
date_default_timezone_set('Europe/Zurich');mb_internal_encoding('UTF-8');
ini_set('display_errors','0');ini_set('session.use_strict_mode','1');
set_exception_handler(static function(Throwable $e):void {
 http_response_code(500);error_log('Prepa Entretien: '.get_class($e));
 echo '<!doctype html><html lang="fr"><meta charset="utf-8"><title>Prépa Entretien</title><h1>Une erreur est survenue</h1><p>Votre action n’a pas pu être terminée. Rechargez la page ou réessayez plus tard.</p></html>';
});
require APP_ROOT.'/src/helpers.php';
if(PHP_SAPI!=='cli') {
 header('Cache-Control: no-store, private');header('X-Content-Type-Options: nosniff');header('X-Frame-Options: DENY');header('Referrer-Policy: no-referrer');header('X-Robots-Tag: noindex, nofollow');
 header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
 $sessionDir=(string)config('app.private_dir').'/sessions';
 if(!is_dir($sessionDir) && !mkdir($sessionDir,0700,true) && !is_dir($sessionDir)) throw new RuntimeException('Sessions indisponibles.');
 session_save_path($sessionDir);
 session_name('PREPA_ENTRETIEN_PRIVATE');
 session_set_cookie_params(['lifetime'=>0,'path'=>rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME']??'/')),'/').'/', 'httponly'=>true,'secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','samesite'=>'Strict']);
 session_start();
}

