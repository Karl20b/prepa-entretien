<?php
declare(strict_types=1);
namespace App;
use PDO;
final class Schema {
 public static function migrate(PDO $pdo):void {
  $pdo->exec('CREATE TABLE IF NOT EXISTS pe_migrations(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)');
  foreach([2=>'002_comptes.sql',3=>'003_ateliers.sql',4=>'004_assistance.sql'] as $version=>$file){
   if($pdo->query('SELECT 1 FROM pe_migrations WHERE version='.$version)->fetchColumn())continue;
   $pdo->beginTransaction();
   try {
    $pdo->exec(file_get_contents(APP_ROOT.'/sql/'.$file));
    $pdo->prepare('INSERT INTO pe_migrations(version,applied_at) VALUES(?,?)')->execute([$version,time()]);
    $pdo->commit();
   }catch(\Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
  }
 }
}
