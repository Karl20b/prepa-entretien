<?php
// Copier vers config/config.php hors de la racine publique. Aucun secret livré.
return [
 'app'=>['name'=>'Prépa Entretien','setup_username'=>'administrateur','setup_display_name'=>'Administrateur','base_url'=>'https://entretiens.exemple.ch','rate_key'=>'GENERER_UNE_CLE_ALEATOIRE','private_dir'=>dirname(__DIR__).'/var'],
 'db'=>['path'=>dirname(__DIR__).'/var/prepa.sqlite'],
 'ai'=>['provider'=>'openai_compatible','timeout'=>120,'max_tokens'=>4000,'temperature'=>0.3,
  'openai_compatible'=>['endpoint'=>'https://api.infomaniak.com/2/ai/{PRODUCT_ID}/openai/v1/chat/completions','api_key'=>'','model'=>'mistralai/Ministral-3-14B-Instruct-2512']],
 'rag'=>['chunk_size'=>1200,'chunk_overlap'=>200,'top_k'=>6,'max_context_chars'=>9000,'history_messages'=>10],
 'upload'=>['max_bytes'=>2000000,'extensions'=>['txt','md']],
];
