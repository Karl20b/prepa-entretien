---
titre: Guide P1-P7 — Z — Mesurer le temps et entretenir les sources
categorie: aide_utilisation
source: Aide Prépa Entretien | processus P1-P7 et chaîne de valeur V2 | v1.0 | 23.11.2026 | prototype
---
Gain net en minutes = temps total sans IA moins temps total avec IA. Les deux durées couvrent toute la préparation P1 à P5 : recherche, lecture, rédaction, contrôle, corrections, reprises et attentes. Compter chaque durée une seule fois. Le contrôle P4 est déjà inclus ; ne pas le déduire de nouveau.

Comparer des cas fictifs de difficulté comparable, avec les mêmes exigences de qualité et références disponibles ; alterner l’ordre. Un gain négatif indique un surcroît de temps. Les 120 minutes déclarées sont une estimation non chronométrée, pas une référence mesurée. Un temps gagné représente une capacité disponible ; une économie budgétaire demande une preuve distincte.

L’administrateur entretient la base selon ses droits. Qualifier, dater, actualiser ou désactiver les sources périmées ; le rôle éditorial RH reste à désigner. Cette aide doit rester classée « Aide à l’utilisation ». Ne pas la reclasser en CDC ou méthode d’entretien.
