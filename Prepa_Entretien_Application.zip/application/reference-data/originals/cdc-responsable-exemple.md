# Responsable d’équipe — exemple fictif

Exemple entièrement fictif, à remplacer par un référentiel autorisé.

Missions : clarifier les priorités, répartir la charge de travail et soutenir le développement de l’équipe. Compétences : coordination, écoute et suivi des actions. Autonomie : dans le périmètre délégué, sans présumer de pouvoirs supplémentaires.
