# Collaborateur·trice — exemple fictif

Exemple entièrement fictif, à remplacer par un référentiel autorisé.

Missions : traiter les dossiers confiés, signaler les difficultés et documenter les résultats. Compétences : organisation, communication et respect des procédures. Autonomie : dans le cadre des responsabilités convenues avec le responsable.
