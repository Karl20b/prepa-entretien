<?php
declare(strict_types=1);
define('APP_ROOT',dirname(__DIR__));spl_autoload_register(static function($c){if(str_starts_with($c,'App\\'))require APP_ROOT.'/src/'.str_replace('\\','/',substr($c,4)).'.php';});require APP_ROOT.'/src/helpers.php';date_default_timezone_set('Europe/Zurich');
$GLOBALS['config']=['db'=>['path'=>':memory:']];$p=App\Db::pdo();$p->exec(file_get_contents(APP_ROOT.'/sql/schema-sqlite.sql'));App\Schema::migrate($p);App\Schema::migrate($p);$checks=[];
function ck(bool $v,string $n):void{global $checks;if(!$v)throw new RuntimeException($n);$checks[]=$n;}
ck((int)$p->query('SELECT COUNT(*) FROM pe_migrations')->fetchColumn()===3,'Migrations 2 à 4 idempotentes');
$srepo=new App\Repo\SituationRepo($p);$sid=$srepo->save(['titre'=>'Exercice','faits'=>'Retard constaté'],'alice');$repo=new App\Repo\AtelierRepo($p);
$r=$repo->save($sid,'eogi','alice',['question'=>'Comprendre le retard','environnement'=>'Délai externe','individu'=>'<script>exercice</script>'],0);ck($r['revision']===1,'Brouillon EOGI enregistré');
ck($repo->find($sid,'feedback','alice')===null,'Parcours indépendants');
foreach(['find','save','saveAnalysis','context'] as $method){try{match($method){'find'=>$repo->find($sid,'eogi','bob'),'save'=>$repo->save($sid,'eogi','bob',[],0),'saveAnalysis'=>$repo->saveAnalysis($sid,'eogi','bob',1,'h','x',[],'demo'),'context'=>$repo->context($sid,'bob')};ck(false,$method);}catch(InvalidArgumentException $e){ck(true,'Isolation propriétaire : '.$method);}}
try{$repo->save($sid,'eogi','alice',[],0);ck(false,'Doublon');}catch(RuntimeException $e){ck(true,'Deux créations concurrentes ne s’écrasent pas');}
try{$repo->save($sid,'eogi','alice',['question'=>str_repeat('x',4001)],1);ck(false,'Limite');}catch(InvalidArgumentException $e){ck(true,'Champ trop long refusé sans mutation');}
try{$repo->save($sid,'feedback','alice',['mode'=>'invalide'],0);ck(false,'Mode');}catch(InvalidArgumentException $e){ck(true,'Mode feed-back non autorisé refusé');}
try{$repo->save($sid,'eogi','alice',['question'=>['x']],1);ck(false,'Tableau');}catch(InvalidArgumentException $e){ck(true,'Champ tableau refusé');}
$hash=App\Atelier\Grille::contextHash($srepo->find($sid,'alice'));ck($repo->saveAnalysis($sid,'eogi','alice',1,$hash,'Hypothèse [S1]',[['ref'=>'S1']],'demo'),'Analyse et sources conservées');
$r=$repo->save($sid,'eogi','alice',['question'=>'Nouvelle question'],1);ck($r['revision']===2 && $r['analysis_revision']===1,'Analyse ancienne repérable après modification');
ck(!$repo->saveAnalysis($sid,'eogi','alice',1,$hash,'Écrasement',[],'demo'),'Résultat généré sur ancienne révision refusé');
ck($repo->find($sid,'eogi','alice')['analysis']==='Hypothèse [S1]','Proposition antérieure conservée');
try{$repo->save($sid,'eogi','alice',[],1);ck(false,'Concurrence');}catch(RuntimeException $e){ck(true,'Édition concurrente refusée');}
$r=$repo->save($sid,'feedback','alice',['mode'=>'amelioration','faits'=>'Voix haussée observée'],0);ck($r['data']['mode']==='amelioration','Feed-back d’amélioration enregistré');
ck(str_contains($repo->context($sid,'alice'),'Nouvelle question')&&str_contains($repo->context($sid,'alice'),'Voix haussée'),'Deux grilles transmises comme contexte');
$srepo->save(['titre'=>'Autre contexte','faits'=>'Nouveau fait'],'alice',$sid);ck(App\Atelier\Grille::contextHash($srepo->find($sid,'alice'))!==$hash,'Modification de situation détectée');
$index=new App\Rag\DocumentIndexer($p,new App\Rag\Chunker(1200,200));ck($index->importDirectory(APP_ROOT.'/fiches/textes','alice')===5,'Cinq fiches importées');$ret=new App\Rag\FulltextRetriever($p);
foreach(['EOGI environnement organisation groupe individu'=>'systemique','feed-back amélioration six étapes'=>'feedback','constellation équipe représentation'=>'constellation'] as $q=>$cat){$rows=$ret->search($q,5,[$cat]);ck(count(array_filter($rows,fn($r)=>$r['categorie']===$cat))>0,'RAG : '.$cat);}
ck(count(App\Atelier\Fiches::all($p))===5,'Bibliothèque documentaire active');$p->exec('UPDATE pe_documents SET actif=0');ck(App\Atelier\Fiches::all($p)===[],'Fiches désactivées exclues de la bibliothèque');
$srepo->delete($sid,'alice');ck((int)$p->query('SELECT COUNT(*) FROM pe_ateliers')->fetchColumn()===0,'Suppression en cascade des ateliers personnels');
echo json_encode(['status'=>'passed','checks'=>count($checks),'tests'=>$checks],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT),"\n";
