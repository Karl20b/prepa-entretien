<?php
declare(strict_types=1);
$root = sys_get_temp_dir().'/prepa-assets-'.bin2hex(random_bytes(6));
$source = dirname(__DIR__).'/public/assets';
$script = dirname(__DIR__).'/bin/verifier-assets.php';
$checks = 0;
function check(bool $condition, string $label): void {
    global $checks;
    if (!$condition) throw new RuntimeException($label);
    $checks++;
}
function runTool(array $args): int {
    global $script;
    $p=proc_open(array_merge([PHP_BINARY,$script],$args),[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);
    fclose($pipes[0]); stream_get_contents($pipes[1]); fclose($pipes[1]); stream_get_contents($pipes[2]); fclose($pipes[2]);
    return proc_close($p);
}
function modeOf(string $p): int { clearstatcache(true,$p); return fileperms($p)&0777; }
mkdir($root,0700);
try {
    $assets=$root.'/assets'; mkdir($assets,0700);
    foreach (glob($source.'/*') as $f) { copy($f,$assets.'/'.basename($f)); chmod($assets.'/'.basename($f),0600); }
    file_put_contents($root.'/config.php','FICTITIOUS_PRIVATE_CONFIG'); chmod($root.'/config.php',0600);
    file_put_contents($root.'/storage.key','FICTITIOUS_PRIVATE_KEY'); chmod($root.'/storage.key',0600);
    check(runTool([$assets])===2,'Permissions 0600 détectées');
    check(modeOf($assets.'/constellation.js')===0600,'Contrôle sans mutation');
    check(runTool([$assets,'--corriger-permissions'])===0,'Correction acceptée');
    check(runTool([$assets])===0,'Nouvelle vérification conforme');
    foreach (glob($source.'/*') as $f) {
        $to=$assets.'/'.basename($f);
        check(modeOf($to)===0644,'Asset public lisible');
        check(hash_file('sha256',$to)===hash_file('sha256',$f),'Contenu inchangé');
    }
    check(modeOf($root.'/config.php')===0600 && file_get_contents($root.'/config.php')==='FICTITIOUS_PRIVATE_CONFIG','Configuration privée préservée');
    check(modeOf($root.'/storage.key')===0600 && file_get_contents($root.'/storage.key')==='FICTITIOUS_PRIVATE_KEY','Clé privée préservée');
    check(runTool([$assets,'--inconnu'])===1,'Option inconnue refusée');
    chmod($assets.'/constellation.js',0600);
    file_put_contents($assets.'/redaction.js','PERSONNALISATION_FICTIVE');
    check(runTool([$assets,'--corriger-permissions'])===1,'Fichier différent refusé');
    check(modeOf($assets.'/constellation.js')===0600,'Aucune correction partielle si contenu différent');
    copy($source.'/redaction.js',$assets.'/redaction.js');
    unlink($assets.'/redaction.js');
    check(runTool([$assets,'--corriger-permissions'])===1,'Fichier manquant refusé');
    symlink($root.'/config.php',$assets.'/redaction.js');
    check(runTool([$assets,'--corriger-permissions'])===1,'Lien fichier refusé');
    check(modeOf($root.'/config.php')===0600,'Cible privée du lien préservée');
    symlink($assets,$root.'/alias');
    check(runTool([$root.'/alias','--corriger-permissions'])===1,'Dossier lié refusé');
    echo json_encode(['status'=>'passed','checks'=>$checks],JSON_PRETTY_PRINT),PHP_EOL;
} finally {
    foreach (glob($root.'/assets/*')?:[] as $f) unlink($f);
    if(is_link($root.'/alias'))unlink($root.'/alias');
    foreach (glob($root.'/*')?:[] as $f) { if(is_dir($f))rmdir($f);else unlink($f); }
    rmdir($root);
}
