<?php
declare(strict_types=1);
// Recette en mémoire : aucun compte, aucune situation de production modifiés.
define('APP_ROOT',dirname(__DIR__));
spl_autoload_register(static function($class){if(str_starts_with($class,'App\\'))require APP_ROOT.'/src/'.str_replace('\\','/',substr($class,4)).'.php';});
require APP_ROOT.'/src/helpers.php';
date_default_timezone_set('Europe/Zurich');
$GLOBALS['config']=['app'=>['admins'=>['admin_demo']],'db'=>['path'=>':memory:']];
$pdo=App\Db::pdo();$pdo->exec(file_get_contents(APP_ROOT.'/sql/schema-sqlite.sql'));App\Schema::migrate($pdo);
$passed=[];
function check(bool $ok,string $name):void {global $passed;if(!$ok)throw new RuntimeException('ECHEC: '.$name);$passed[]=$name;}
$indexer=new App\Rag\DocumentIndexer($pdo,new App\Rag\Chunker(1200,200));
check($indexer->importDirectory(APP_ROOT.'/docs_seed','test')===7,'7 fiches génériques importées');
check($indexer->importDirectory(APP_ROOT.'/docs_seed','test')===7,'Réimportation possible');
check((int)$pdo->query('SELECT COUNT(*) FROM pe_documents')->fetchColumn()===7,'Import idempotent sans doublons');
$retriever=new App\Rag\FulltextRetriever($pdo);
$r=$retriever->search('SMART spécifique mesurable',6,['smart']);check(count($r)>0,'Recherche SMART générique');
check($retriever->search('xyzzzzblorb 987654321',6,['smart'])===[],'Aucun résultat inventé en absence de correspondance');
check($retriever->search('les des une',6)===[],'Mots vides sans résultats');
$r=$retriever->search('SMART spécifique mesurable',6,['smart']);
$p=new App\Prompt\PromptBuilder();[$block,$meta]=$p->sources($r);
check(str_contains($block,'Source :'),'Provenance transmise au modèle');
check(isset($meta[0]['source'],$meta[0]['extrait']),'Extraits et provenance conservés');
check(str_contains($p->system([]),'données non fiables'),'Protection des consignes contre instructions documentaires');
$docs=new App\Repo\DocumentRepo($pdo);$target=array_values(array_filter($docs->all(),fn($v)=>str_contains($v['titre'],'SMART')))[0];$docs->toggle((int)$target['id']);
check(!array_filter($retriever->search('SMART spécifique',20),fn($v)=>str_contains($v['titre'],'SMART')),'Documents désactivés exclus du RAG');$docs->toggle((int)$target['id']);
$repo=new App\Repo\SituationRepo($pdo);$s=$repo->save(['titre'=>'Recette fictive','type_entretien'=>'objectifs'],'alice');
check($repo->find($s,'bob')===null,'Cloisonnement situations');
$repo->save(['titre'=>'Recette modifiée','type_entretien'=>'objectifs'],$user='alice',$s);
check($repo->find($s,'alice')['titre']==='Recette modifiée','Modification de situation SQLite');
$msg=new App\Repo\MessageRepo($pdo);$msg->add($s,'user','test');$msg->add($s,'assistant','réponse',$meta,'test');
check(count($msg->forSituation($s))===2,'Échanges et citations persistés');
$cr=new App\Repo\ConstellationRepo($pdo);$c=$cr->create('alice','Équipe fictive',$s);
check($cr->find($c,'bob')===null,'Cloisonnement constellations');
$cr->saveAnalyse($c,'alice','Hypothèse',[],'test');check($cr->find($c,'alice')['analyse']==='Hypothèse','Analyse constellation persistée');
$repo->delete($s,'alice');check($msg->forSituation($s)===[],'Cascade suppression échanges');check($cr->find($c,'alice')['situation_id']===null,'Constellation conservée sans situation');
App\Rag\SourceValidator::check('Selon la fiche [S1].',[['ref'=>'S1']]);check(true,'Citation existante acceptée');
foreach(['Réponse sans référence','Selon [S99].'] as $bad) {try{App\Rag\SourceValidator::check($bad,[['ref'=>'S1']]);check(false,'Citation invalide refusée');}catch(App\Ai\AiException $e){check(true,'Citation invalide refusée');}}
$html=App\View\Markdown::render('<script>alert(1)</script>');check(!str_contains($html,'<script>'),'Rendu Markdown échappé');
$_SESSION=[];check(strlen(csrf_token())===64,'Jeton CSRF généré');
try {current_user();check(false,'Identité anonyme refusée');}catch(RuntimeException $e){check(true,'Identité anonyme refusée');}
echo json_encode(['status'=>'passed','checks'=>count($passed),'tests'=>$passed,'documents'=>count($docs->all()),'chunks'=>(int)$pdo->query('SELECT COUNT(*) FROM pe_chunks')->fetchColumn()],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),"\n";
