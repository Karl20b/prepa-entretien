<?php
declare(strict_types=1);
define('APP_ROOT',dirname(__DIR__));spl_autoload_register(static function($c){if(str_starts_with($c,'App\\'))require APP_ROOT.'/src/'.str_replace('\\','/',substr($c,4)).'.php';});require APP_ROOT.'/src/helpers.php';
$GLOBALS['config']=['db'=>['path'=>':memory:']];$p=App\Db::pdo();$p->exec(file_get_contents(APP_ROOT.'/sql/schema-sqlite.sql'));App\Schema::migrate($p);App\Schema::migrate($p);$checks=[];
function ck(bool $ok,string $n):void{global $checks;if(!$ok)throw new RuntimeException($n);$checks[]=$n;}
ck(count(App\Reference\RoleCatalog::all())===2,'Deux exemples fictifs');
$r=App\Reference\Importer::run($p);ck($r['documents']===2,'Import des deux exemples');App\Reference\Importer::run($p);ck((int)$p->query('SELECT COUNT(*) FROM pe_reference_docs')->fetchColumn()===2,'Import idempotent');
foreach(App\Reference\RoleCatalog::all() as $key=>$role){$rows=(new App\Reference\Sources($p))->search(['cdc_role'=>$key],'missions compétences',6);ck(count($rows)>0,'CDC disponible');ck(!array_filter($rows,fn($c)=>str_starts_with($c['titre'],'CDC ')&&!str_starts_with($c['titre'],'CDC '.$role['scope'].' —')),'Aucun autre rôle dans les sources');ck(is_file(APP_ROOT.'/reference-data/originals/'.$role['file']),'Original fictif disponible');}
ck(!(new App\Rag\FulltextRetriever($p))->search('missions compétences',20),'Sans rôle aucun CDC');
try{App\Reference\RoleCatalog::clean('../../config/config.php');throw new RuntimeException('Accepté');}catch(InvalidArgumentException){ck(true,'Rôle inconnu refusé');}
$p->exec("UPDATE pe_documents SET actif=0");App\Reference\Importer::run($p);ck(!(new App\Reference\Sources($p))->search(['cdc_role'=>'collaborateur-exemple'],'missions',6),'Réimport ne réactive pas les références');
echo json_encode(['status'=>'passed','checks'=>count($checks),'tests'=>$checks],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT),"\n";
