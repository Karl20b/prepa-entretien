<?php
declare(strict_types=1);
define('APP_ROOT',dirname(__DIR__));spl_autoload_register(static function($c){if(str_starts_with($c,'App\\'))require APP_ROOT.'/src/'.str_replace('\\','/',substr($c,4)).'.php';});require APP_ROOT.'/src/helpers.php';date_default_timezone_set('Europe/Zurich');
$GLOBALS['config']=['db'=>['path'=>':memory:']];$p=App\Db::pdo();$p->exec(file_get_contents(APP_ROOT.'/sql/schema-sqlite.sql'));App\Schema::migrate($p);$checks=[];
function ck(bool $v,string $n):void{global $checks;if(!$v)throw new RuntimeException($n);$checks[]=$n;}
$srepo=new App\Repo\SituationRepo($p);$sid=$srepo->save(['titre'=>'Exercice fictif'],'alice');$repo=new App\Repo\AtelierRepo($p);$chat=new App\Repo\AtelierChatRepo($p);
$r=$repo->save($sid,'eogi','alice',['question'=>'Comprendre le travail'],0);
$hash=App\Atelier\Grille::contextHash($srepo->find($sid,'alice'));
$r=$repo->save($sid,'eogi','alice',['question'=>'Comprendre le travail'],1);ck($r['revision']===1,'Même grille sans révision artificielle');
$chat->exchange($sid,'eogi','alice',1,$hash,'Par où commencer ?','Réponse [S1]',[['ref'=>'S1','extrait'=>'méthode']],'demo');$h=$chat->history($sid,'eogi','alice');ck(count($h)===2&&$h[0]['role']==='user'&&$h[1]['role']==='assistant','Échange enregistré dans l’ordre');
ck($h[1]['sources'][0]['extrait']==='méthode','Sources propres à chaque réponse');ck($chat->history($sid,'feedback','alice')===[],'Historique EOGI séparé du feed-back');
foreach(['history','exchange'] as $method){try{if($method==='history')$chat->history($sid,'eogi','bob');else $chat->exchange($sid,'eogi','bob',1,$hash,'x','y',[],'demo');ck(false,'Accès');}catch(InvalidArgumentException $e){ck(true,'Propriétaire requis : '.$method);}}
$repo->save($sid,'eogi','alice',['question'=>'Question modifiée'],1);
try{$chat->exchange($sid,'eogi','alice',1,$hash,'x','y',[],'demo');ck(false,'Conflit');}catch(RuntimeException $e){ck(count($chat->history($sid,'eogi','alice'))===2,'Grille changée : aucun demi-échange enregistré');}
$conversation=App\Atelier\Assistant::conversation($h);ck(!str_contains($conversation[1]['content'],'[S1]'),'Références anciennes neutralisées pour le modèle');
$help=App\Atelier\Assistant::help('feedback',['mode'=>'amelioration'],'Comment formuler ?','<sources>[S1]</sources>');ck(str_contains($help,'amélioration')&&str_contains($help,'Comment formuler ?'),'Question et type de feed-back transmis');ck(str_contains($help,'Ne modifie jamais les champs'),'Assistant propose sans remplacer la saisie');
for($i=0;$i<8;$i++)$chat->exchange($sid,'eogi','alice',2,$hash,'Question '.$i,'Réponse '.$i,[],'demo');
$h=$chat->history($sid,'eogi','alice',4); ck(count($h)===4 && $h[0]['content']==='Question 6','Historique borné aux derniers échanges');
ck(count(App\Atelier\Assistant::conversation($chat->history($sid,'eogi','alice',40)))===6,'Contexte IA borné à six messages');
$srepo->delete($sid,'alice');ck((int)$p->query('SELECT COUNT(*) FROM pe_atelier_messages')->fetchColumn()===0,'Suppression en cascade de l’assistance');
echo json_encode(['status'=>'passed','checks'=>count($checks),'tests'=>$checks],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),"\n";
