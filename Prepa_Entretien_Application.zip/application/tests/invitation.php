<?php
declare(strict_types=1);
define('APP_ROOT',dirname(__DIR__));spl_autoload_register(static function($c){if(str_starts_with($c,'App\\'))require APP_ROOT.'/src/'.str_replace('\\','/',substr($c,4)).'.php';});require APP_ROOT.'/src/helpers.php';
$checks=[];function ck(bool $v,string $n):void{global $checks;if(!$v)throw new RuntimeException($n);$checks[]=$n;}
$link='https://entretiens.exemple.ch/index.php?action=activate#activation=jeton-fictif';
$a=App\Accounts\InvitationMail::compose('lea.martin','Léa Martin',$link,'activate');
ck(str_contains($a['body'],'Bonjour Léa Martin,'),'Salutation personnalisée');ck(str_contains($a['body'],'Votre identifiant : lea.martin'),'Identifiant transmis');ck(str_contains($a['body'],$link),'Lien complet et fragment préservés');ck(str_contains($a['body'],'48 heures à compter de sa création'),'Validité activation claire');ck(str_contains($a['body'],'14 caractères minimum'),'Consigne de mot de passe personnel');
$r=App\Accounts\InvitationMail::compose('lea.martin','',$link,'reset');ck(str_contains($r['subject'],'Réinitialisation')&&str_contains($r['body'],'une heure à compter de sa création'),'Message et durée de réinitialisation');
$a=App\Accounts\InvitationMail::compose('lea.martin',"Léa\r\nMartin",$link,'activate');ck(str_starts_with($a['body'],'Bonjour Léa Martin,'),'Retour de ligne du nom neutralisé');
$encoded='mailto:?subject='.rawurlencode($a['subject']).'&body='.rawurlencode($a['body']);parse_str(parse_url($encoded,PHP_URL_QUERY),$decoded);ck($decoded['body']===$a['body'],'Encodage du courriel sans perte');ck(str_contains($encoded,'%23activation%3Djeton-fictif'),'Fragment encodé dans mailto');
try{App\Accounts\InvitationMail::compose('lea','',$link,'autre');ck(false,'Type');}catch(InvalidArgumentException $e){ck(true,'Type inconnu refusé');}
echo json_encode(['status'=>'passed','checks'=>count($checks),'tests'=>$checks],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT),"\n";
