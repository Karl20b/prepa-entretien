<?php
declare(strict_types=1);
define('APP_ROOT',dirname(__DIR__));
spl_autoload_register(static function($c){if(str_starts_with($c,'App\\'))require APP_ROOT.'/src/'.str_replace('\\','/',substr($c,4)).'.php';});
use App\Redaction\FeedbackDossier as F;
use App\Redaction\Export as E;
use App\Redaction\Text as T;
$checks=[];
function ck17(bool $ok,string $label):void{global $checks;if(!$ok)throw new RuntimeException($label);$checks[]=$label;}
$source=['s'=>['titre'=>'Suivi des comptes rendus fictifs','contexte'=>'Une équipe fictive prépare ses réunions.','faits'=>'Deux comptes rendus fictifs transmis le lundi plutôt que le vendredi prévu.','objectif_manager'=>'Convenir ensemble d’un délai réaliste.','enjeux'=>'Disposer des décisions avant le prochain point.','collaborateur_ref'=>'Collègue fictif A','fonction'=>'Coordination fictive'],'feedback_data'=>['mode'=>'amelioration','faits'=>'FAIT-GRILLE','effets'=>'EFFET-OBSERVE','attentes'=>'ATTENTE-CLARIFIEE','suite'=>'SOUTIEN-CONVENU']];
$working="## 1 · Exposer les faits\nFORMULATION-CORRIGEE-PAR-LE-CADRE\n\n## 3 · Questionner et écouter\nQUESTION-CORRIGEE\n\n## Piste de travail\nPISTE-ASSISTANT-A-VERIFIER";
$text=F::build($source,$working);
ck17(F::complete($text),'Fiche complète reconnue');
ck17(F::build($source,$text)===$text,'Réouverture sans doublonner ni remplacer les corrections');
foreach(['FAIT-GRILLE','EFFET-OBSERVE','ATTENTE-CLARIFIEE','SOUTIEN-CONVENU','FORMULATION-CORRIGEE-PAR-LE-CADRE','QUESTION-CORRIGEE','PISTE-ASSISTANT-A-VERIFIER','Convenir ensemble d’un délai réaliste.'] as $sentinel)ck17(str_contains($text,$sentinel),'Information conservée '.$sentinel);
foreach(range(1,6) as $n)ck17(preg_match('/^## '.$n.' /m',$text)===1,'Étape détaillée '.$n);
ck17(str_contains($text,'Propos réellement recueillis')&&str_contains($text,'À convenir'),'Réponses et accords non inventés');
ck17(!F::hasContent("## 1 · Faits\n\n## 2 · Effets"),'Ancien squelette vide détecté');
ck17(F::hasContent($working),'Correction libre non considérée comme vide');
$blank=F::build(['s'=>['titre'=>'Mise au point'],'feedback_data'=>[]],"## 1 · Faits\n\n## 2 · Effets");
ck17(str_contains($blank,'À compléter avant l’entretien')&&str_contains($blank,'à choisir avant l’entretien'),'Manques explicites sans inventer le contexte ou le type');
$round=T::compose(T::sections($text));ck17(F::complete($round)&&str_contains($round,'QUESTION-CORRIGEE')&&str_contains($round,'Échéance et date du point de suivi'),'Édition conserve contenu et suivi');
ck17(count(array_filter(E::blocks($round),fn($b)=>$b[0]==='table'))===1,'Tableau de suivi conservé après édition');
$recovered=F::build($source+['text'=>$working],"## 1 Faits\n\n## 2 Effets");ck17(str_contains($recovered,'FORMULATION-CORRIGEE-PAR-LE-CADRE'),'Ancien document vide reprend la proposition disponible');
$refs=[['ref'=>'S1','titre'=>'Méthode fictive','source'=>'Fiche A'],['ref'=>'S3','titre'=>'Méthode fictive','source'=>'Fiche A'],['ref'=>'S5','titre'=>'Autre méthode','source'=>'Fiche B']];
$lines=E::referenceLines($refs);ck17(count($lines)===2&&str_contains($lines[0],'S1, S3'),'Références regroupées sans perdre les identifiants');
$docx=E::docx('Fiche de conduite du feed-back',$round,$refs);
$pdf=E::pdf('Fiche de conduite du feed-back',$round,$refs);
ck17(str_starts_with($docx,"PK\x03\x04")&&str_contains($docx,'FORMULATION-CORRIGEE-PAR-LE-CADRE'),'Word contient le texte relu');
ck17(str_starts_with($pdf,'%PDF-'),'PDF complet généré');
if(getenv('PREPA_QA_DIR')){
 $out=getenv('PREPA_QA_DIR');
 file_put_contents($out.'/fiche-feedback-exemple-fictif.docx',$docx);
 file_put_contents($out.'/fiche-feedback-exemple-fictif.pdf',$pdf);
 file_put_contents($out.'/fiche-conduite-feedback.docx',E::docx('Fiche de conduite du feed-back',$blank));
 file_put_contents($out.'/texte-fictif.md',$round);
}
echo json_encode(['status'=>'passed','checks'=>count($checks),'tests'=>$checks],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT),PHP_EOL;
