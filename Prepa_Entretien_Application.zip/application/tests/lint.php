<?php
declare(strict_types=1);
$n=0;foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator(dirname(__DIR__))) as $f){if($f->getExtension()!=='php')continue;token_get_all(file_get_contents($f->getPathname()),TOKEN_PARSE);$n++;}echo "$n fichiers PHP valides\n";
