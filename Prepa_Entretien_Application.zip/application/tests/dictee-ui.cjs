const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const elements={},events={};let sent=0,tracksStopped=0,media,interval;
const el=id=>elements[id]??=( {id,value:'',disabled:false,hidden:true,dataset:{},handlers:{},addEventListener(t,f){this.handlers[t]=f},dispatchEvent(){},focus(){},scrollIntoView(){},textContent:''} );
const triggers=['contexte','faits','objectif_manager','enjeux'].map(f=>{let e=el('trigger-'+f);e.dataset.dictee=f;return e;});
const fields=Object.fromEntries(['contexte','faits','objectif_manager','enjeux'].map(f=>[f,el(f)]));fields.contexte.value='Texte existant.';
const form={handlers:{},elements:{namedItem:n=>fields[n]},querySelector:()=>({value:'fakecsrf'}),addEventListener(t,f){this.handlers[t]=f}};
el('dictee').closest=()=>form;
class Recorder{static isTypeSupported(){return true}constructor(){media=this;this.state='inactive';this.mimeType='audio/webm'}start(){this.state='recording'}pause(){this.state='paused'}resume(){this.state='recording'}stop(){this.state='inactive';this.ondataavailable({data:new Blob(['fakeaudio'])});this.onstop?.()}}
const context={document:{getElementById:el,querySelectorAll:()=>triggers},window:{isSecureContext:true,MediaRecorder:Recorder,dispatchEvent(){},addEventListener(t,f){events[t]=f}},navigator:{mediaDevices:{getUserMedia:async()=>({getTracks:()=>[{stop(){tracksStopped++}}]})}},MediaRecorder:Recorder,crypto:require('crypto').webcrypto,Uint8Array,Blob,FormData,Event:class{},setInterval:f=>(interval=f,1),clearInterval(){},setTimeout,fetch:async(url)=>{sent++;return {ok:true,status:200,json:async()=>url.includes('submit')?{ok:true,job:'test',status:'pending'}:{ok:true,status:'completed',text:'Deux faits dictés.'}}}};
vm.runInNewContext(fs.readFileSync(__dirname+'/../public/assets/dictee.js','utf8'),context);
(async()=>{
 triggers[0].handlers.click();assert.equal(el('dictee').hidden,false);assert.equal(el('dictee-target').textContent,'Contexte');assert.equal(sent,0);
 await el('dictee-start').handlers.click();assert.equal(media.state,'recording');assert.equal(sent,0);assert.equal(triggers[1].disabled,true);
 el('dictee-pause').handlers.click();assert.equal(media.state,'paused');el('dictee-resume').handlers.click();assert.equal(media.state,'recording');
 el('dictee-stop').handlers.click();assert.equal(media.state,'inactive');assert.equal(tracksStopped,1);assert.equal(sent,0);
 let prevented=false;form.handlers.submit({preventDefault(){prevented=true}});assert.equal(prevented,true);
 await el('dictee-send').handlers.click();assert.equal(sent,2);assert.equal(el('dictee-preview').value,'Deux faits dictés.');assert.equal(fields.contexte.value,'Texte existant.');
 el('dictee-preview').value='Texte corrigé.';el('dictee-preview').handlers.input();el('dictee-apply').handlers.click();assert.equal(fields.contexte.value,'Texte existant.\n\nTexte corrigé.');assert.equal(fields.faits.value,'');assert.equal(el('dictee').hidden,true);
 triggers[1].handlers.click();await el('dictee-start').handlers.click();for(let i=0;i<300;i++)interval();assert.equal(media.state,'inactive');el('dictee-discard').handlers.click();assert.equal(fields.faits.value,'');assert.equal(sent,2);
 console.log('Dictée UI : parcours prise/pause/reprise/arrêt, zéro envoi implicite, relecture, correction, ajout conservateur, annulation et limite 300 s vérifiés.');
})().catch(e=>{console.error(e);process.exitCode=1});
