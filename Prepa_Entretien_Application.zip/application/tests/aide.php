<?php
declare(strict_types=1);
define('APP_ROOT',dirname(__DIR__));spl_autoload_register(static function($c){if(str_starts_with($c,'App\\'))require APP_ROOT.'/src/'.str_replace('\\','/',substr($c,4)).'.php';});require APP_ROOT.'/src/helpers.php';date_default_timezone_set('Europe/Zurich');
$GLOBALS['config']=['db'=>['path'=>':memory:']];$p=App\Db::pdo();$p->exec(file_get_contents(APP_ROOT.'/sql/schema-sqlite.sql'));App\Schema::migrate($p);$checks=[];
function ck(bool $ok,string $n):void{global $checks;if(!$ok)throw new RuntimeException($n);$checks[]=$n;}
$i=new App\Rag\DocumentIndexer($p,new App\Rag\Chunker(1200,200));$i->importDirectory(APP_ROOT.'/docs_seed','test');App\Reference\Importer::run($p);$r=new App\Rag\FulltextRetriever($p);$sources=new App\Reference\Sources($p);
$queries=['comment modifier aperçu champs vides','situation EOGI environnement groupe','préparer entretien CDC missions compétences','objectif SMART mesurable'];$before=[];foreach($queries as $q)$before[$q]=$sources->search(['cdc_role'=>'collaborateur-exemple'],$q,8,['systemique']);
ck($i->importDirectory(APP_ROOT.'/help_docs','test')===9,'Neuf parties de la fiche importées');$i->importDirectory(APP_ROOT.'/help_docs','test');ck((int)$p->query("SELECT COUNT(*) FROM pe_documents WHERE categorie='aide_utilisation'")->fetchColumn()===9,'Import idempotent sans doublon');
foreach($queries as $q){ck($sources->search(['cdc_role'=>'collaborateur-exemple'],$q,8,['systemique'])===$before[$q],'Corpus métier et classement inchangés : '.$q);$a=$r->search($q,20,[],'aide');ck(count($a)>0&&!array_filter($a,fn($c)=>$c['categorie']!=='aide_utilisation'),'Aide uniquement : '.$q);}
foreach(['comment modifier aperçu validation'=>'P5','calcul gain net temps total contrôle'=>'Z','réexaminer échéance actions'=>'P7'] as $q=>$step){$rows=$r->search($q,20,[],'aide');ck((bool)array_filter($rows,fn($c)=>str_contains($c['titre'],' — '.$step.' — ')),'Étape pertinente trouvée : '.$step);}
ck(!array_filter($r->search('guide P1 P7 aide entretien',20),fn($c)=>$c['categorie']==='aide_utilisation'),'Recherche par défaut exclut toute aide');
$docs=new App\Repo\DocumentRepo($p);$id=(int)$p->query("SELECT id FROM pe_documents WHERE titre LIKE '% — P5 — %'")->fetchColumn();$docs->toggle($id);ck(!array_filter($r->search('aperçu champs vides',20,[],'aide'),fn($c)=>str_contains($c['titre'],' — P5 — ')),'Aide désactivée exclue');
try{$r->search('test',5,[],'invalide');ck(false,'Corpus invalide');}catch(InvalidArgumentException $e){ck(true,'Corpus inconnu refusé');}
ck($r->search('xyzzzzblorb 987654321',6,[],'aide')===[],'Aucun extrait inventé');ck(App\Domain\Categorie::fromValue('aide_utilisation')->label()==='Aide à l’utilisation','Catégorie explicite');
echo json_encode(['status'=>'passed','checks'=>count($checks),'tests'=>$checks],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT),"\n";
