<?php
declare(strict_types=1);
define('APP_ROOT',dirname(__DIR__));spl_autoload_register(static function($c){if(str_starts_with($c,'App\\'))require APP_ROOT.'/src/'.str_replace('\\','/',substr($c,4)).'.php';});require APP_ROOT.'/src/helpers.php';
use App\Security\Migration as M;use App\Security\Vault as V;
$dir=sys_get_temp_dir().'/prepa-migrate-'.bin2hex(random_bytes(5));mkdir($dir,0700);mkdir($dir.'/var',0700);mkdir($dir.'/docs_seed',0700);mkdir($dir.'/sources_originales',0700);mkdir($dir.'/var/sessions',0700);
file_put_contents($dir.'/key',random_bytes(32));chmod($dir.'/key',0600);$db=$dir.'/var/prepa.sqlite';
$GLOBALS['config']=['app'=>['private_dir'=>$dir.'/var'],'db'=>['path'=>$db],'security'=>['encryption'=>false,'key_file'=>$dir.'/key']];
$p=new PDO('sqlite:'.$db,null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);$p->exec(file_get_contents(APP_ROOT.'/sql/schema-sqlite.sql'));App\Schema::migrate($p);$sentinel='Migration confidentielle 907451';$p->prepare('INSERT INTO pe_situations(titre,contexte,created_by) VALUES(?,?,?)')->execute([$sentinel,$sentinel,'alice']);$p=null;
file_put_contents($dir.'/docs_seed/exemple.md',"---\ntitre: Exemple migration\ncategorie: systemique\nsource: Source fictive\n---\n".$sentinel);
file_put_contents($dir.'/sources_originales/document.pdf',$sentinel);file_put_contents($dir.'/var/sessions/sess_fixture','contexte|s:'.strlen($sentinel).':"'.$sentinel.'";');
$checks=[];function ck(bool $ok,string $n):void{global $checks;if(!$ok)throw new RuntimeException($n);$checks[]=$n;}
try{
 $bytes=file_get_contents($db);$lock=fopen($dir.'/var/security-maintenance.lock','c+');flock($lock,LOCK_EX);try{M::run($dir,$dir.'/var',$db);throw new LogicException('Verrou ignoré');}catch(RuntimeException){ck(true,'Migration refusée sous verrou');}flock($lock,LOCK_UN);fclose($lock);
 file_put_contents($dir.'/sources_originales/bad.pdf','pe1:invalid');try{M::run($dir,$dir.'/var',$db);throw new LogicException('Altération ignorée');}catch(RuntimeException){ck(file_get_contents($db)===$bytes,'Échec avant bascule conserve la base originale');}unlink($dir.'/sources_originales/bad.pdf');
 $result=M::run($dir,$dir.'/var',$db);ck($result['backup_verified'],'Sauvegarde chiffrée relue');ck($result['sqlite_integrity']==='ok','Intégrité SQLite');$GLOBALS['config']['security']['encryption']=true;
 $p=App\Db::pdo();$s=(new App\Repo\SituationRepo($p))->find(1,'alice');ck($s['contexte']===$sentinel,'Contexte conservé après migration');ck(!str_contains(file_get_contents($db),$sentinel),'Aucune sentinelle dans SQLite reconstruit');ck(V::read($dir.'/sources_originales/document.pdf')===$sentinel,'Original chiffré réversible');ck(V::open(file_get_contents($dir.'/var/sessions/sess_fixture'),'session:fixture')==='contexte|s:'.strlen($sentinel).':"'.$sentinel.'";','Session chiffrée sans perte');
 $index=new App\Rag\DocumentIndexer($p,new App\Rag\Chunker(1200,200));ck($index->importDirectory($dir.'/docs_seed','test')===1,'Import source chiffrée');ck((new App\Rag\FulltextRetriever($p))->search('Migration confidentielle',6)!==[],'Recherche après migration');$index->importDirectory($dir.'/docs_seed','test');ck((int)$p->query('SELECT COUNT(*) FROM pe_documents')->fetchColumn()===1,'Réimport chiffré idempotent');
 $backup=V::open(file_get_contents($dir.'/var/'.$result['backup']),'backup:sqlite');file_put_contents($dir.'/restauration.sqlite',$backup);$restore=new PDO('sqlite:'.$dir.'/restauration.sqlite');ck($restore->query('SELECT contexte FROM pe_situations')->fetchColumn()===$sentinel,'Restauration isolée de la sauvegarde vérifiée');$restore=null;
 echo json_encode(['status'=>'passed','checks'=>count($checks),'tests'=>$checks],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT),"\n";
}finally{$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);foreach($it as $f){if($f->isDir())rmdir($f->getPathname());else unlink($f->getPathname());}rmdir($dir);}
