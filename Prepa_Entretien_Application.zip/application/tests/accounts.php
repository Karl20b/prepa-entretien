<?php
declare(strict_types=1);
define('APP_ROOT',dirname(__DIR__));
spl_autoload_register(static function($c){if(str_starts_with($c,'App\\'))require APP_ROOT.'/src/'.str_replace('\\','/',substr($c,4)).'.php';});
require APP_ROOT.'/src/helpers.php';date_default_timezone_set('Europe/Zurich');
$GLOBALS['config']=['db'=>['path'=>':memory:']];$p=App\Db::pdo();$p->exec(file_get_contents(APP_ROOT.'/sql/schema-sqlite.sql'));
$original=password_hash('Mot-de-passe-fictif-2026!',PASSWORD_DEFAULT);$p->prepare('INSERT INTO pe_accounts(username,password_hash,created_at) VALUES(?,?,?)')->execute(['administrateur',$original,time()]);
$r=new App\Repo\SituationRepo($p);$p->exec("INSERT INTO pe_situations(titre,type_entretien,created_by) VALUES('Situation existante fictive','objectifs','administrateur')");$sid=(int)$p->lastInsertId();
$passed=[];function ck(bool $v,string $n):void {global $passed;if(!$v)throw new RuntimeException($n);$passed[]=$n;}
function refused(callable $f,string $n):void {try{$f();throw new RuntimeException('Non refusé : '.$n);}catch(InvalidArgumentException $e){ck(true,$n);}}
App\Schema::migrate($p);App\Schema::migrate($p);$p->exec("UPDATE pe_accounts SET role='admin' WHERE username='administrateur'");$a=new App\Repo\AccountRepo($p);
ck($a->find('administrateur')['password_hash']===$original,'Mot de passe existant conservé');ck($a->find('administrateur')['role']==='admin','Propriétaire existant administrateur');ck($r->find($sid,'administrateur')['titre']==='Situation existante fictive','Situation existante conservée');
refused(fn()=>$a->update('administrateur','administrateur','Karl','user',true),'Dernier administrateur non rétrogradable');
refused(fn()=>$a->update('administrateur','administrateur','Karl','admin',false),'Dernier administrateur non désactivable');
$token=$a->create('administrateur','alice','Alice fictive','user');ck(!$a->find('alice')['active'],'Compte créé en attente');ck(!str_contains(json_encode($p->query('SELECT * FROM pe_account_tokens')->fetchAll()),$token),'Jeton brut absent de la base');
refused(fn()=>$a->accept($token,'court','court',true),'Mot de passe court refusé');
ck($a->accept($token,'Mot-de-passe-fictif-2026!','Mot-de-passe-fictif-2026!',true)==='alice','Activation du titulaire');
refused(fn()=>$a->accept($token,'Mot-de-passe-fictif-2026!','Mot-de-passe-fictif-2026!',true),'Lien utilisé une seule fois');
refused(fn()=>$a->create('alice','intrus','Intrus','admin'),'Utilisateur non autorisé à créer un administrateur');
refused(fn()=>$a->update('alice','administrateur','Karl','user',true),'Utilisateur non autorisé à changer les rôles');
refused(fn()=>$a->issueToken('alice','administrateur','reset'),'Utilisateur non autorisé à réinitialiser un compte');
$token1=$a->create('administrateur','rita','Rita fictive','admin');$token2=$a->issueToken('administrateur','rita','activate');
refused(fn()=>$a->accept($token1,'Mot-de-passe-fictif-2026!','Mot-de-passe-fictif-2026!',true),'Ancien lien remplacé invalidé');
$a->accept($token2,'Mot-de-passe-fictif-2026!','Mot-de-passe-fictif-2026!',true);$version=$a->find('rita')['auth_version'];$a->update('administrateur','rita','Rita fictive','user',true);ck($a->find('rita')['auth_version']===$version+1,'Changement de rôle invalide la version de session');
$before=$a->find('alice');$reset=$a->issueToken('administrateur','alice','reset');$a->accept($reset,'Un-autre-mot-de-passe-fictif!','Un-autre-mot-de-passe-fictif!',true);$after=$a->find('alice');ck($after['auth_version']>$before['auth_version'],'Réinitialisation invalide les anciennes sessions');ck(password_verify('Un-autre-mot-de-passe-fictif!',$after['password_hash']),'Nouveau mot de passe haché');
$a->update('administrateur','alice','Alice fictive','user',false);ck(!$a->find('alice')['active'],'Désactivation persistée');refused(fn()=>$a->issueToken('administrateur','alice','reset'),'Compte désactivé sans nouveau lien de connexion');
refused(fn()=>$a->create('administrateur','alice','Doublon','user'),'Identifiant doublon refusé');refused(fn()=>$a->create('administrateur','x/y','Invalide','user'),'Identifiant invalide refusé');
refused(fn()=>$a->create('administrateur','valide','Invalide','root'),'Rôle inconnu refusé');
$t=$a->create('administrateur','expire','Exercice','user');$p->exec("UPDATE pe_account_tokens SET expires_at=1 WHERE username='expire'");refused(fn()=>$a->accept($t,'Mot-de-passe-fictif-2026!','Mot-de-passe-fictif-2026!',true),'Lien expiré refusé');
$_SESSION=['user'=>'rita'];ck(!is_admin(),'Droits administrateur relus en base');$_SESSION=['user'=>'administrateur'];ck(is_admin(),'Administrateur actif reconnu');
ck($r->find($sid,'rita')===null,'Administrateur ou utilisateur ne lit pas la situation d’autrui');
ck(!str_contains(json_encode($a->auditRecent()),$token),'Audit sans jeton personnel');
echo json_encode(['status'=>'passed','checks'=>count($passed),'tests'=>$passed],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),"\n";
