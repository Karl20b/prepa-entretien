<?php
declare(strict_types=1);
define('APP_ROOT',dirname(__DIR__));spl_autoload_register(static function($c){if(str_starts_with($c,'App\\'))require APP_ROOT.'/src/'.str_replace('\\','/',substr($c,4)).'.php';});require APP_ROOT.'/src/helpers.php';
$dir=sys_get_temp_dir().'/prepa-edit-'.bin2hex(random_bytes(5));mkdir($dir,0700);file_put_contents($dir.'/key',random_bytes(32));chmod($dir.'/key',0600);$GLOBALS['config']=['db'=>['path'=>$dir.'/test.sqlite'],'security'=>['encryption'=>true,'key_file'=>$dir.'/key']];
$p=App\Db::pdo();$p->exec(file_get_contents(APP_ROOT.'/sql/schema-sqlite.sql'));App\Schema::migrate($p);App\Security\Migration::guards($p);$checks=[];
function ck(bool $ok,string $n){global $checks;if(!$ok)throw new RuntimeException($n);$checks[]=$n;}
function denied(callable $f,string $n){try{$f();}catch(Throwable){ck(true,$n);return;}throw new RuntimeException($n);}
try{
 $sit=new App\Repo\SituationRepo($p);$sid=$sit->save(['titre'=>'Exercice fictif','contexte'=>'Contexte fictif','faits'=>'Un fait observable'],'alice');$m=new App\Repo\MessageRepo($p);$m->add($sid,'user',"Préparer l'entretien");$m->add($sid,'assistant',"## Lecture de la situation\nUn exemple fictif.");$m->add($sid,'user','Préciser une question');$m->add($sid,'assistant','Réponse de précision.');
 $repo=new App\Redaction\Repository($p);$src=$repo->source($sid,'entretien','alice');ck(str_contains($src['text'],'Lecture de la situation'),'La préparation complète reste la source après une question');
 $text="## Lecture de la situation\nVersion corrigée SENTINELLE-REDACTION.\n\n## Questions\n- Comment avez-vous vécu l’échange ?\n\n| Attente | Question |\n| --- | --- |\n| Écoute | Quel soutien ? |";
 $row=$repo->save($sid,'entretien','alice',$text,0,$src['hash'],$src['context']);ck($row['contenu']===$text,'Texte corrigé conservé');ck($m->forSituation($sid)[1]['contenu']!==$text,'Proposition originale conservée');
 denied(fn()=>$repo->find($sid,'entretien','bob'),'Lecture d’un autre propriétaire refusée');denied(fn()=>$repo->save($sid,'entretien','bob','Texte',0,$src['hash'],$src['context']),'Écriture d’un autre propriétaire refusée');
 denied(fn()=>$repo->save($sid,'entretien','alice','Autre version',0,$src['hash'],$src['context']),'Création concurrente refusée');
 $row=$repo->save($sid,'entretien','alice',$text.'\nSuite',1,$src['hash'],$src['context']);denied(fn()=>$repo->save($sid,'entretien','alice','Perte de texte',1,$src['hash'],$src['context']),'Révision périmée refusée');
 $m->add($sid,'user',"Préparer l'entretien");$m->add($sid,'assistant','Nouvelle préparation.');$fresh=$repo->source($sid,'entretien','alice');ck(App\Redaction\Repository::stale($row,$fresh),'Nouvelle génération signalée');ck($repo->find($sid,'entretien','alice')['contenu']===$row['contenu'],'Nouvelle génération sans écrasement des corrections');denied(fn()=>$repo->save($sid,'entretien','alice','Ancienne page',2,$src['hash'],$src['context']),'Source remplacée pendant édition refusée');
 $fb=$repo->source($sid,'feedback','alice');ck(str_contains($fb['text'],'faits'),'Trame manuelle possible depuis la grille');$fbrow=$repo->save($sid,'feedback','alice','## Feed-back\nUne phrase corrigée.',0,$fb['hash'],$fb['context']);ck($fbrow['contenu']!==$row['contenu'],'Préparation et feed-back séparés');
 $raw=(new PDO('sqlite:'.$dir.'/test.sqlite'))->query('SELECT contenu FROM pe_redactions')->fetchColumn();ck(str_starts_with($raw,'pe1:'),'Version de travail chiffrée au repos');denied(fn()=>$p->exec("UPDATE pe_redactions SET contenu='Texte clair'"),'Écriture en clair refusée');
 ck(!str_contains(file_get_contents($dir.'/test.sqlite'),'SENTINELLE-REDACTION'),'Sentinelle absente du stockage');
 $docx=App\Redaction\Export::docx('Entretien — Équipe',$text);ck(str_starts_with($docx,"PK\x03\x04"),'Document OOXML généré');$pdf=App\Redaction\Export::pdf('Entretien — Équipe',$text);ck(str_starts_with($pdf,'%PDF-'),'Véritable PDF généré');
 if(getenv('PREPA_QA_DIR')){file_put_contents(getenv('PREPA_QA_DIR').'/exemple.docx',$docx);file_put_contents(getenv('PREPA_QA_DIR').'/exemple.pdf',$pdf);}
 echo json_encode(['status'=>'passed','checks'=>count($checks),'tests'=>$checks],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),"\n";
}finally{foreach(glob($dir.'/*') as $f)unlink($f);rmdir($dir);}
