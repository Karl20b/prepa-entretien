<?php
declare(strict_types=1);
define('APP_ROOT',dirname(__DIR__));spl_autoload_register(static function($c){if(str_starts_with($c,'App\\'))require APP_ROOT.'/src/'.str_replace('\\','/',substr($c,4)).'.php';});
use App\Stt\Dictation as D;use App\Stt\Infomaniak as I;
$checks=[];function ck(bool $b,string $n):void{global $checks;if(!$b)throw new RuntimeException($n);$checks[]=$n;}
function rejects(callable $f,string $n):void{try{$f();}catch(InvalidArgumentException|RuntimeException $e){ck(true,$n);return;}throw new RuntimeException($n);}
$cfg=['ai'=>['openai_compatible'=>['endpoint'=>'https://api.infomaniak.com/2/ai/123/openai/v1/chat/completions','api_key'=>'FAKE_TEST_ONLY']]];
foreach(['https://example.com/2/ai/123/openai/v1/chat/completions','http://api.infomaniak.com/2/ai/123/openai/v1/chat/completions','https://api.infomaniak.com.evil/2/ai/123/openai/v1/chat/completions'] as $url){$c=$cfg;$c['ai']['openai_compatible']['endpoint']=$url;rejects(fn()=>new I($c),'Destination refusée '.$url);}
$c=$cfg;$c['ai']['openai_compatible']['api_key']='';rejects(fn()=>new I($c),'Clé absente refusée');
function audio(string $bytes="RIFF\x00\x00\x00\x00WAVEfake"):array{$p=tempnam(sys_get_temp_dir(),'stt-test-');file_put_contents($p,$bytes);return ['tmp_name'=>$p,'error'=>UPLOAD_ERR_OK];}
foreach(["RIFF\x00\x00\x00\x00WAVEfake"=>'audio/wav',"\x1a\x45\xdf\xa3xxxxxxxxxxxx"=>'audio/webm',"\x00\x00\x00\x18ftypM4A xxxx"=>'audio/mp4'] as $b=>$mime){$f=audio($b);ck(D::validateAudio($f)===$mime,'Conteneur '.$mime);unlink($f['tmp_name']);}
$f=audio('<?php echo 1; ?>');rejects(fn()=>D::validateAudio($f),'Fichier non audio refusé');unlink($f['tmp_name']);$f=audio(str_repeat('x',D::MAX_BYTES+1));rejects(fn()=>D::validateAudio($f),'Taille limitée');unlink($f['tmp_name']);
$calls=0;$polls=0;$engine=new I($cfg,function($path,$payload)use(&$calls,&$polls){if($payload!==null){$calls++;ck($payload['model']==='whisper'&&$payload['language']==='fr','Français explicite');return ['batch_id'=>'batch-test'];}$polls++;return ['status'=>'completed','data'=>json_encode(['text'=>'Contexte fictif : deux objectifs.'])];});
$state=[];$f=audio();$nonce=str_repeat('a',32);$job=D::submit($state,'alice','contexte',$nonce,$f,$engine,fn()=>null);ck(!is_file($f['tmp_name']),'Audio supprimé après succès');ck(!isset($job['external'])&&!isset($job['owner']),'Référence fournisseur non exposée');
$f=audio();$again=D::submit($state,'alice','contexte',$nonce,$f,$engine,fn()=>throw new RuntimeException('Quota ne doit pas être repris'));ck($again===$job&&$calls===1,'Doublon sans second appel');ck(!is_file($f['tmp_name']),'Audio doublon supprimé');
rejects(function()use(&$state,$job,$engine){D::poll($state,'bob',$job['job'],$engine);},'Résultat d’un autre utilisateur refusé');ck($polls===0,'Aucun appel pour un autre utilisateur');
$result=D::poll($state,'alice',$job['job'],$engine);ck($result['text']==='Contexte fictif : deux objectifs.','Texte décodé');D::poll($state,'alice',$job['job'],$engine);ck($polls===1,'Résultat terminé réutilisé');
foreach(['inconnu','titre','../contexte'] as $field){$f=audio();rejects(function()use(&$state,$field,$f,$engine){D::submit($state,'alice',$field,str_repeat('b',32),$f,$engine,fn()=>null);},'Champ non autorisé '.$field);ck(!is_file($f['tmp_name']),'Audio invalide supprimé '.$field);}
$bad=new I($cfg,fn()=>throw new RuntimeException('Panne simulée'));$f=audio();rejects(function()use(&$state,$f,$bad){D::submit($state,'alice','faits',str_repeat('c',32),$f,$bad,fn()=>null);},'Panne fournisseur gérée');ck(!is_file($f['tmp_name']),'Audio supprimé après panne');
$f=audio();$r=D::submit($state,'alice','faits',str_repeat('c',32),$f,$engine,fn()=>null);ck($r['status']==='failed'&&$calls===1,'Prise en échec non retransmise');
foreach($state as &$v)$v['created']=time()-1201;unset($v);rejects(function()use(&$state,$job,$engine){D::poll($state,'alice',$job['job'],$engine);},'Expiration appliquée');
$dir=sys_get_temp_dir().'/stt-limits-test-'.bin2hex(random_bytes(5));for($n=0;$n<12;$n++)D::reserve('alice',$dir);rejects(fn()=>D::reserve('alice',$dir),'Quota 12 prises persistant');D::reserve('bob',$dir);ck(count(glob($dir.'/*'))===2,'Quotas isolés par utilisateur');foreach(glob($dir.'/*') as $p)unlink($p);rmdir($dir);
foreach(['pending','queued','processing','running','submitted'] as $status){$e=new I($cfg,fn()=>['status'=>$status]);ck($e->poll('batch')['status']==='pending','État asynchrone '.$status);}
$e=new I($cfg,fn()=>['status'=>'completed','data'=>['text'=>'']]);rejects(fn()=>$e->poll('batch'),'Texte vide refusé');$e=new I($cfg,fn()=>['status'=>'failed']);rejects(fn()=>$e->poll('batch'),'Échec refusé');
echo json_encode(['status'=>'passed','checks'=>count($checks),'tests'=>$checks],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT),"\n";
