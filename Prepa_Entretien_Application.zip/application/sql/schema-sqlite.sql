PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS pe_situations (
 id INTEGER PRIMARY KEY AUTOINCREMENT, titre TEXT NOT NULL, type_entretien TEXT NOT NULL DEFAULT 'objectifs',
 collaborateur_ref TEXT, fonction TEXT, date_entretien TEXT, contexte TEXT, faits TEXT, objectif_manager TEXT, enjeux TEXT,
 statut TEXT NOT NULL DEFAULT 'brouillon' CHECK(statut IN ('brouillon','prepare','realise')), created_by TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%S','now','localtime')), updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%S','now','localtime'))
);
CREATE INDEX IF NOT EXISTS pe_owner ON pe_situations(created_by,updated_at);
CREATE TABLE IF NOT EXISTS pe_messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT, situation_id INTEGER NOT NULL REFERENCES pe_situations(id) ON DELETE CASCADE,
 role TEXT NOT NULL CHECK(role IN ('user','assistant')), contenu TEXT NOT NULL, sources TEXT, fournisseur TEXT,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%S','now','localtime'))
);
CREATE INDEX IF NOT EXISTS pe_thread ON pe_messages(situation_id,id);
CREATE TABLE IF NOT EXISTS pe_documents (
 id INTEGER PRIMARY KEY AUTOINCREMENT, titre TEXT NOT NULL, categorie TEXT NOT NULL DEFAULT 'autre', source TEXT, contenu TEXT NOT NULL,
 actif INTEGER NOT NULL DEFAULT 1, created_by TEXT, created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%S','now','localtime')), updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%S','now','localtime'))
);
CREATE TABLE IF NOT EXISTS pe_chunks (
 id INTEGER PRIMARY KEY AUTOINCREMENT, document_id INTEGER NOT NULL REFERENCES pe_documents(id) ON DELETE CASCADE,
 ordre INTEGER NOT NULL, contenu TEXT NOT NULL, embedding TEXT
);
CREATE INDEX IF NOT EXISTS pe_doc ON pe_chunks(document_id,ordre);
CREATE TABLE IF NOT EXISTS pe_constellations (
 id INTEGER PRIMARY KEY AUTOINCREMENT, situation_id INTEGER REFERENCES pe_situations(id) ON DELETE SET NULL,
 titre TEXT NOT NULL, question TEXT, data TEXT NOT NULL, analyse TEXT, analyse_sources TEXT, analyse_fournisseur TEXT, analyse_at TEXT,
 created_by TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%S','now','localtime')), updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%S','now','localtime'))
);
CREATE INDEX IF NOT EXISTS pe_const_owner ON pe_constellations(created_by,updated_at);
CREATE TABLE IF NOT EXISTS pe_accounts (username TEXT PRIMARY KEY, password_hash TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS pe_setup (id INTEGER PRIMARY KEY CHECK(id=1), token_hash TEXT NOT NULL, expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS pe_auth_limits (key_hash TEXT PRIMARY KEY, failures INTEGER NOT NULL, window_start INTEGER NOT NULL);
