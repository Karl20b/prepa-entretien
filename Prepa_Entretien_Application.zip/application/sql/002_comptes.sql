-- Migration additive SQLite. Aucun mot de passe, document ni situation supprimés.
ALTER TABLE pe_accounts ADD COLUMN display_name TEXT NOT NULL DEFAULT '';
ALTER TABLE pe_accounts ADD COLUMN role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','admin'));
ALTER TABLE pe_accounts ADD COLUMN active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1));
ALTER TABLE pe_accounts ADD COLUMN auth_version INTEGER NOT NULL DEFAULT 1;
ALTER TABLE pe_accounts ADD COLUMN updated_at INTEGER;
UPDATE pe_accounts SET display_name=username, updated_at=created_at;
CREATE TABLE pe_account_tokens (
 username TEXT PRIMARY KEY REFERENCES pe_accounts(username) ON DELETE CASCADE,
 token_hash TEXT NOT NULL UNIQUE, expires_at INTEGER NOT NULL,
 kind TEXT NOT NULL CHECK(kind IN ('activate','reset'))
);
CREATE TABLE pe_account_audit (
 id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT NOT NULL, subject TEXT NOT NULL,
 action TEXT NOT NULL, created_at INTEGER NOT NULL
);
