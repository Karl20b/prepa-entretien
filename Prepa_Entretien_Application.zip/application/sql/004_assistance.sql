CREATE TABLE pe_atelier_messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 situation_id INTEGER NOT NULL, kind TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('user','assistant')),
 content TEXT NOT NULL, sources TEXT, provider TEXT,
 revision INTEGER NOT NULL, context_hash TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%S','now','localtime')),
 FOREIGN KEY(situation_id,kind) REFERENCES pe_ateliers(situation_id,kind) ON DELETE CASCADE
);
CREATE INDEX pe_atelier_thread ON pe_atelier_messages(situation_id,kind,id);
