-- =====================================================================
-- Prépa Entretien RH — schéma MariaDB (10.6+ ; testé 10.11)
-- Préfixe pe_ pour cohabiter avec d'autres applications dans la même base
-- =====================================================================
SET NAMES utf8mb4;

-- Situations décrites par le manager -----------------------------------
CREATE TABLE IF NOT EXISTS pe_situations (
    id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
    titre              VARCHAR(200) NOT NULL,
    type_entretien     VARCHAR(40)  NOT NULL DEFAULT 'objectifs',
    collaborateur_ref  VARCHAR(100) NULL COMMENT 'Pseudonyme / initiales — pas de nom complet',
    fonction           VARCHAR(150) NULL,
    date_entretien     DATE         NULL,
    contexte           TEXT         NULL,
    faits              TEXT         NULL,
    objectif_manager   TEXT         NULL,
    enjeux             TEXT         NULL,
    statut             ENUM('brouillon','prepare','realise') NOT NULL DEFAULT 'brouillon',
    created_by         VARCHAR(100) NOT NULL,
    created_at         DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at         DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_owner (created_by, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Échanges avec l'assistant IA -----------------------------------------
CREATE TABLE IF NOT EXISTS pe_messages (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    situation_id  INT UNSIGNED NOT NULL,
    role          ENUM('user','assistant') NOT NULL,
    contenu       MEDIUMTEXT   NOT NULL,
    sources       LONGTEXT     NULL COMMENT 'JSON : extraits RAG utilisés',
    fournisseur   VARCHAR(80)  NULL,
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_situation (situation_id, id),
    CONSTRAINT fk_msg_situation FOREIGN KEY (situation_id)
        REFERENCES pe_situations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Base documentaire du RAG ---------------------------------------------
CREATE TABLE IF NOT EXISTS pe_documents (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    titre       VARCHAR(255) NOT NULL,
    categorie   VARCHAR(40)  NOT NULL DEFAULT 'autre',
    source      VARCHAR(255) NULL COMMENT 'Origine : fiche RH, directive, ouvrage…',
    contenu     MEDIUMTEXT   NOT NULL,
    actif       TINYINT(1)   NOT NULL DEFAULT 1,
    created_by  VARCHAR(100) NULL,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_categorie (categorie, actif)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Fragments indexés (chunks) -------------------------------------------
-- FULLTEXT = recherche lexicale disponible partout (Infomaniak inclus).
-- La colonne embedding est réservée à une future recherche vectorielle
-- (JSON aujourd'hui ; type VECTOR possible dès MariaDB 11.7).
CREATE TABLE IF NOT EXISTS pe_chunks (
    id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    document_id  INT UNSIGNED NOT NULL,
    ordre        SMALLINT UNSIGNED NOT NULL,
    contenu      TEXT NOT NULL,
    embedding    LONGTEXT NULL,
    PRIMARY KEY (id),
    KEY idx_doc (document_id, ordre),
    FULLTEXT KEY ft_contenu (contenu),
    CONSTRAINT fk_chunk_doc FOREIGN KEY (document_id)
        REFERENCES pe_documents(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Constellations systémiques -------------------------------
-- data = JSON {"version":1,"images":[{"id","nom","elements":[…],"liens":[…]}]}
CREATE TABLE IF NOT EXISTS pe_constellations (
    id                   INT UNSIGNED NOT NULL AUTO_INCREMENT,
    situation_id         INT UNSIGNED NULL,
    titre                VARCHAR(200) NOT NULL,
    question             TEXT         NULL COMMENT 'Question de travail',
    data                 LONGTEXT     NOT NULL,
    analyse              MEDIUMTEXT   NULL,
    analyse_sources      LONGTEXT     NULL,
    analyse_fournisseur  VARCHAR(80)  NULL,
    analyse_at           DATETIME     NULL,
    created_by           VARCHAR(100) NOT NULL,
    created_at           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_owner (created_by, updated_at),
    KEY idx_situation (situation_id),
    CONSTRAINT fk_const_situation FOREIGN KEY (situation_id)
        REFERENCES pe_situations(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
