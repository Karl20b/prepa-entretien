CREATE TABLE pe_redactions (
 situation_id INTEGER NOT NULL REFERENCES pe_situations(id) ON DELETE CASCADE,
 kind TEXT NOT NULL CHECK(kind IN ('entretien','eogi','feedback')),
 contenu TEXT NOT NULL, sources TEXT NOT NULL, source_hash TEXT NOT NULL,
 context_hash TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1,
 updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%S','now','localtime')),
 PRIMARY KEY(situation_id,kind)
);
