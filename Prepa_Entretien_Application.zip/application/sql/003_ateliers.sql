CREATE TABLE pe_ateliers (
 situation_id INTEGER NOT NULL REFERENCES pe_situations(id) ON DELETE CASCADE,
 kind TEXT NOT NULL CHECK(kind IN ('eogi','feedback')), data TEXT NOT NULL,
 revision INTEGER NOT NULL DEFAULT 1, analysis TEXT, sources TEXT, provider TEXT,
 analysis_revision INTEGER, context_hash TEXT, analysis_at TEXT,
 updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%S','now','localtime')),
 PRIMARY KEY(situation_id,kind)
);
