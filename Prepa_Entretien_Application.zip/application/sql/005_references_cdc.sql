ALTER TABLE pe_situations ADD COLUMN cdc_role TEXT;
ALTER TABLE pe_messages ADD COLUMN cdc_role TEXT;
CREATE TABLE pe_reference_docs (
 document_id INTEGER PRIMARY KEY REFERENCES pe_documents(id) ON DELETE CASCADE,
 source_key TEXT NOT NULL UNIQUE,
 resource TEXT NOT NULL CHECK(resource IN ('cdc','annual')),
 profile TEXT,
 page TEXT NOT NULL
);
CREATE INDEX pe_reference_profile ON pe_reference_docs(resource,profile);
