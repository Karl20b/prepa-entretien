ALTER TABLE pe_accounts ADD COLUMN password_changed_at INTEGER;
-- Unknown password age: require renewal after password + second factor on next login.
UPDATE pe_accounts SET password_changed_at=0 WHERE password_hash<>'';
CREATE TABLE pe_mfa (
 username TEXT PRIMARY KEY REFERENCES pe_accounts(username) ON DELETE CASCADE,
 secret TEXT, enabled INTEGER NOT NULL DEFAULT 0, last_step INTEGER NOT NULL DEFAULT -1,
 failures INTEGER NOT NULL DEFAULT 0, blocked_until INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE pe_recovery (
 username TEXT NOT NULL REFERENCES pe_accounts(username) ON DELETE CASCADE,
 hash TEXT NOT NULL UNIQUE, PRIMARY KEY(username,hash)
);
CREATE TABLE pe_password_history (
 username TEXT NOT NULL REFERENCES pe_accounts(username) ON DELETE CASCADE,
 hash TEXT NOT NULL, created_at INTEGER NOT NULL
);
CREATE TABLE pe_security_audit (
 id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL,
 event TEXT NOT NULL, created_at INTEGER NOT NULL
);
