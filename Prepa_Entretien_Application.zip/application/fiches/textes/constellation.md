---
titre: Constellation d’équipe — cartographie réflexive
categorie: constellation
source: Synthèse générique créée pour la version partageable ; à adapter et valider localement.
---
Représenter les acteurs et leurs liens à partir d’observations explicites. Distinguer coopération constatée, difficulté rapportée et perception personnelle. Utiliser cette carte pour formuler des questions et explorer des actions. Ne pas attribuer de motivations cachées ni considérer le dessin comme un diagnostic.
