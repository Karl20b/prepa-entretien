---
titre: EOGI — repères génériques
categorie: systemique
source: Synthèse générique créée pour la version partageable ; à adapter et valider localement.
---
Explorer les facteurs de l’environnement, de l’organisation, du groupe et de l’individu. Pour chaque niveau, noter les observations, les informations manquantes et les hypothèses à vérifier. Examiner les interactions entre niveaux avant de proposer une action dans sa marge de manœuvre. Cette grille ne démontre pas une causalité.
