---
titre: EOGI — interactions et hypothèses
categorie: systemique
source: Synthèse générique créée pour la version partageable ; à adapter et valider localement.
---
Un changement de règle peut modifier les échanges du groupe et l’expérience individuelle. Décrire une boucle possible comme une hypothèse, chercher des exemples contradictoires et demander d’autres points de vue. Choisir un petit essai, un indicateur et une date de relecture à convenir.
