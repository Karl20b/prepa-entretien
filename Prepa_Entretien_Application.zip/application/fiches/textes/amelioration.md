---
titre: Feed-back d’amélioration — repères génériques
categorie: feedback
source: Synthèse générique créée pour la version partageable ; à adapter et valider localement.
---
Choisir un comportement précis. Décrire ce qui est observé et distinguer les conséquences constatées des craintes. Poser une question ouverte avant de proposer une solution. Clarifier les attentes, les moyens et le suivi à convenir. Ne pas inventer l’accord du collaborateur.
