---
titre: Feed-back de valorisation — repères génériques
categorie: feedback
source: Synthèse générique créée pour la version partageable ; à adapter et valider localement.
---
Décrire une réussite observable et son contexte. Expliquer son effet positif sans généraliser sur la personnalité. Demander ce qui a aidé la personne. Reformuler ce qui mérite d’être poursuivi. Convenir ensemble d’une suite et d’un moment de suivi.
