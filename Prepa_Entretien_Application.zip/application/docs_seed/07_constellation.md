---
titre: La constellation systémique d'équipe
categorie: constellation
source: Synthèse de démarrage (à remplacer par vos fiches)
---
## Principe

La constellation systémique est une méthode d'accompagnement issue de l'approche systémique. Elle consiste à représenter dans l'espace les membres d'une équipe, leurs rôles et les enjeux qui les relient (mission, client, contrainte, projet). Mettre la situation « à plat » fait apparaître des dynamiques difficiles à formuler avec des mots : alliances, distances, tensions, personnes ou éléments oubliés.

L'image représente la perception de celui qui la construit, pas la réalité objective. Elle sert à se poser de meilleures questions, pas à juger des personnes.

## Démarche

1. **Formuler une question de travail** : ce qui pose problème ou ce que l'on cherche à comprendre (« Pourquoi les décisions ne sont-elles pas appliquées ? »).
2. **Choisir les éléments** : les personnes ou rôles concernés, soi-même, l'objectif ou la mission, éventuellement des ressources ou acteurs externes.
3. **Placer intuitivement** chaque élément, sans trop réfléchir : distance, place, direction du regard.
4. **Observer** l'image d'ensemble, puis chaque élément : qu'est-ce qui frappe ? Qu'est-ce qui surprend ?
5. **Tester des mouvements** : dans une nouvelle image, déplacer ou réorienter un élément et observer ce que cela change. L'image « souhaitée » éclaire les actions possibles.
6. **Revenir au concret** : quelles actions, quelles questions à poser, quel entretien à préparer ?

## Repères de lecture

- **Distance** : la proximité peut traduire une relation étroite, une alliance ou une dépendance ; l'éloignement une distance relationnelle, un retrait ou une exclusion perçue.
- **Place** : au centre, l'élément concentre l'attention ou les tensions ; en périphérie, il peut être en retrait, oublié ou en position d'observateur.
- **Regard** : vers qui ou quoi chacun est tourné. Un élément qui regarde la mission est souvent perçu comme engagé ; un élément qui tourne le dos au groupe peut signaler un désengagement, un conflit ou un regard porté ailleurs (un autre service, l'extérieur).
- **Se faire face** : peut indiquer un dialogue, mais aussi une confrontation.
- **Taille** : l'importance ou le poids perçu d'un élément.
- **Ordre et hiérarchie** : le responsable est-il à une place qui lui permet de voir l'équipe et la mission ? Les anciens et les nouveaux ont-ils chacun une place reconnue ?
- **Éléments absents** : qui ou quoi a été oublié ? L'absence d'un élément (la mission, un ancien collaborateur, le client) est souvent significative.

Ces repères sont des **hypothèses** à vérifier, jamais des conclusions.

## Questions utiles

- Qu'est-ce qui vous frappe en regardant l'image ?
- Qui voit la mission ? Qui ne la voit pas ?
- Qui est le plus proche de vous ? Le plus loin ?
- Si cette personne se tournait vers le groupe, que changerait-il ?
- Quelle serait la place juste pour chacun ? Quel premier petit mouvement est possible ?
- Qu'est-ce que l'image vous apprend pour votre prochain entretien ?

## Usage par un cadre

- Outil de **réflexion personnelle** avant un entretien, une réorganisation ou la gestion d'une tension.
- Support d'échange avec un coach, un RH ou un pair (codéveloppement).
- À éviter : montrer l'image à l'équipe sans accompagnement, en faire un outil d'évaluation des personnes, ou l'utiliser pour des situations relevant de la santé, du disciplinaire ou du harcèlement : dans ces cas, s'adresser aux RH.

## Confidentialité

La constellation contient des perceptions sur des personnes : utiliser des pseudonymes ou des rôles, ne pas la diffuser et la supprimer lorsqu'elle n'est plus utile.
