---
titre: Le modèle GROW — conduire un entretien orienté objectif
categorie: grow
source: Synthèse de démarrage (à remplacer par vos fiches)
---
## Principe

GROW est une trame de questionnement en quatre étapes qui aide un collaborateur à construire lui-même son objectif et son plan d'action. Le manager questionne, reformule et soutient ; il n'impose pas sa solution. Il peut en revanche exprimer ses exigences et attentes. L'impulsion peut venir du chef, mais les modalités et le chemin doivent venir du collaborateur, ce qui renforce l'engagement.

## G — Goal (but)

Clarifier ce que le collaborateur veut atteindre et pourquoi c'est important pour lui.
Questions utiles : Sur quoi aimerais-tu progresser ? Concrètement, que veux-tu obtenir ? À quoi verras-tu que tu as réussi ? Qu'est-ce que cela changera pour toi et pour l'équipe ?

## R — Reality (réalité)

Faire décrire la situation actuelle avec des faits et des exemples, sans jugement.
Questions utiles : Où te situes-tu aujourd'hui sur une échelle de 1 à 10 ? Peux-tu me donner un exemple récent ? Qu'as-tu déjà essayé, avec quel effet ? Qu'est-ce qui dépend de toi, qu'est-ce qui n'en dépend pas ?
Astuce : demander pourquoi la note n'est pas plus basse fait apparaître les ressources existantes.

## O — Options

Élargir le champ des possibles avant de choisir.
Questions utiles : Quelles pistes vois-tu ? Si tu avais déjà gagné un point sur l'échelle, qu'aurais-tu fait ? Comment évalues-tu chaque piste en impact, coût et facilité ? Laquelle te paraît la plus adaptée, et pourquoi ? Quels risques et quels espoirs y associes-tu ?

## W — Will (volonté, engagement)

Transformer l'option retenue en actions concrètes et datées.
Questions utiles : Quelle sera ta première action, et quand ? Quels obstacles prévois-tu ? De quels moyens ou de quelle formation as-tu besoin ? Comment puis-je t'aider ? Quand faisons-nous le point ?

## Pièges fréquents

- Passer directement aux options sans avoir exploré la réalité.
- Poser des questions fermées ou suggestives (« Tu ne crois pas que… ? »).
- Proposer sa propre solution trop tôt.
- Terminer sans action datée ni rendez-vous de suivi.
- Combiner GROW avec SMART : l'objectif issu de l'étape G doit être vérifié selon les critères SMART avant l'étape W.
