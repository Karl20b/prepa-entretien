---
titre: Préparer et conduire un entretien individuel — check-list
categorie: preparation
source: Synthèse de démarrage (à remplacer par vos fiches)
---
## Avant l'entretien

- Clarifier son propre objectif : qu'est-ce qui doit être différent à la fin de l'entretien ?
- Rassembler les faits, documents et objectifs précédents.
- Anticiper le point de vue du collaborateur et ses attentes possibles.
- Choisir la trame adaptée : GROW pour un objectif ou un développement, DESC pour un feedback ou un recadrage.
- Prévoir un lieu calme, un créneau suffisant, sans interruption.
- Informer le collaborateur à l'avance de l'objet de l'entretien (sauf urgence).

## Pendant l'entretien

1. **Accueil** : mettre à l'aise, rappeler l'objet et la durée.
2. **Écoute** : laisser s'exprimer le collaborateur en premier lorsque c'est possible.
3. **Échange** : faits, points de vue, questions ouvertes, reformulations.
4. **Construction** : objectifs ou solutions co-construits, vérifiés avec SMART.
5. **Engagement** : actions, échéances, soutien attendu du manager.
6. **Conclusion** : synthèse, vérification de l'accord, date de suivi.

## Après l'entretien

- Rédiger un compte rendu factuel et le partager si le cadre l'exige.
- Tenir ses propres engagements (moyens, formation, retour).
- Assurer le suivi aux dates convenues.

## Phrases d'ouverture et de conclusion

- « Je t'ai proposé ce moment pour faire le point ensemble sur… »
- « Comment vois-tu toi-même la situation ? »
- « Si je résume ce que nous avons convenu… Est-ce que cela te convient ? »
- « Nous refaisons le point le … ; d'ici là, n'hésite pas à revenir vers moi. »
