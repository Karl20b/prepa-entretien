---
titre: Donner un feedback — méthode DESC et feedback factuel
categorie: feedback
source: Synthèse de démarrage (à remplacer par vos fiches)
---
## Pourquoi un feedback structuré

Un feedback utile porte sur des faits et des comportements, pas sur la personne. Il est donné rapidement après les faits, en privé s'il est critique, et laisse une place à la réponse du collaborateur. Le feedback positif (reconnaissance) suit les mêmes règles : il est précis et sincère.

## Méthode DESC

- **D — Décrire** les faits de manière objective, datée, observable. « Mardi, le rapport d'intervention a été transmis deux jours après l'échéance. »
- **E — Exprimer** l'impact et son ressenti, en « je ». « Cela m'a mis en difficulté vis-à-vis de la direction. »
- **S — Spécifier** ce qui est attendu, ou mieux, le co-construire. « Qu'est-ce qui permettrait que les prochains rapports arrivent dans les délais ? »
- **C — Conséquences** : présenter les effets positifs du changement (et, si nécessaire, les conséquences en l'absence de changement).

## Variante pour la reconnaissance

Situation (quand, où) → Comportement observé → Impact positif pour l'équipe ou le service → Remerciement. « Lors de l'exercice de jeudi, tu as anticipé le besoin en véhicules ; cela a évité une heure d'attente aux équipes. Merci. »

## Bonnes pratiques

- Un seul sujet par feedback.
- Vérifier la compréhension et recueillir le point de vue de l'autre (écoute active).
- Éviter « toujours », « jamais », les généralisations et les interprétations d'intention.
- Conclure sur un engagement concret et un moment de suivi.
