---
titre: L'entretien de recadrage
categorie: recadrage
source: Synthèse de démarrage (à remplacer par vos fiches)
---
## Objectif

Faire cesser un comportement ou un écart par rapport aux règles, tout en préservant la relation et en obtenant un engagement. Le recadrage n'est pas une sanction ; il intervient tôt, sur des faits précis. Pour tout aspect disciplinaire ou juridique, coordonner au préalable avec les RH et la hiérarchie.

## Préparation

- Rassembler les faits (dates, situations, éventuels témoins ou traces), vérifier qu'ils sont établis.
- Identifier la règle, la directive ou l'attente concernée.
- Définir ce qui est négociable (les moyens) et ce qui ne l'est pas (la règle).
- Prévoir les réactions possibles : contestation, justification, émotion, mise en cause d'autrui.

## Déroulement type

1. Annoncer d'emblée l'objet de l'entretien, brièvement et sans détour.
2. Exposer les faits (méthode DESC) et rappeler la règle ou l'attente.
3. Écouter la version du collaborateur ; reformuler ; distinguer les explications des justifications.
4. Réaffirmer l'exigence ; chercher avec lui les moyens d'y répondre.
5. Obtenir un engagement concret et daté.
6. Annoncer le suivi et, si nécessaire, les conséquences en cas de répétition.
7. Conclure sur une note de confiance ; consigner l'entretien par écrit.

## Points de vigilance

- Rester factuel et calme ; ne pas se laisser entraîner sur d'autres sujets.
- Ne pas recadrer en public.
- Ne pas accumuler les reproches anciens.
- Être cohérent : appliquer la même exigence à toute l'équipe.
