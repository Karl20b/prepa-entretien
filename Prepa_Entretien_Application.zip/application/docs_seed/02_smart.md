---
titre: Formuler un objectif SMART
categorie: smart
source: Synthèse de démarrage (à remplacer par vos fiches)
---
## Les cinq critères

- **S — Spécifique** : l'objectif décrit un résultat précis, compréhensible sans explication, qui concerne le périmètre du collaborateur.
- **M — Mesurable** : on peut constater objectivement s'il est atteint (indicateur chiffré, livrable, comportement observable).
- **A — Atteignable** : il représente un défi, mais le collaborateur dispose ou peut obtenir les moyens, compétences et marges de manœuvre nécessaires.
- **R — Réaliste / pertinent** : il est cohérent avec la mission du service, les priorités de la hiérarchie et la charge de travail.
- **T — Temporel** : il comporte une échéance et, si besoin, des jalons intermédiaires.

## Exemple de reformulation

Formulation vague : « Améliorer le suivi des commandes de matériel. »
Formulation SMART : « D'ici au 30 juin, traiter 90 % des demandes de matériel standard en cinq jours ouvrables au plus, mesuré chaque mois dans l'outil de suivi, avec un point d'étape fin mars. »

## Questions de vérification

- Si deux personnes lisent l'objectif, comprendront-elles la même chose ? (S)
- Comment saurons-nous, sans discussion, qu'il est atteint ? (M)
- De quoi le collaborateur a-t-il besoin pour y parvenir ? Est-ce sous son contrôle ? (A)
- Pourquoi cet objectif, maintenant, pour ce service ? (R)
- Quelle échéance, quels jalons, quand fait-on le point ? (T)

## Bonnes pratiques

- Limiter le nombre d'objectifs (trois à cinq par période).
- Distinguer objectifs de résultat (ce qu'on obtient) et objectifs de comportement (comment on agit) ; les seconds doivent décrire des comportements observables.
- Faire formuler l'objectif par le collaborateur, puis le vérifier ensemble avec les cinq critères.
- Consigner l'objectif par écrit et prévoir le suivi.
