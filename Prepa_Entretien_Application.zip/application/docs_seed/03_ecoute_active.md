---
titre: L'écoute active
categorie: ecoute
source: Synthèse de démarrage (à remplacer par vos fiches)
---
## Principe

Écouter pour comprendre, et non pour préparer sa réponse. L'écoute active montre à l'interlocuteur que ce qu'il dit compte, améliore la compréhension mutuelle et apaise les tensions. Elle s'utilise dans tous les entretiens, formels ou non. Une part importante consiste à percevoir ce qui n'est pas dit : émotions, hésitations, non-verbal.

## Techniques

- **Disponibilité** : lieu calme, téléphone de côté, temps réservé, attention entière.
- **Signes d'intérêt** : contact visuel, hochements, relances brèves (« Ah oui ? », « Et ensuite ? »).
- **Ne pas interrompre** : laisser finir, accepter les silences ; ils permettent à l'autre d'aller plus loin.
- **Questions ouvertes** : « Comment décrirais-tu… ? », « Qu'est-ce qui te pose problème dans… ? », « C'est-à-dire ? ».
- **Reformulation** : redire avec ses mots pour vérifier sa compréhension. « Si je te comprends bien, c'est surtout l'accumulation des délais qui te pèse ? » La personne peut confirmer ou corriger.
- **Reflet des émotions** : nommer l'émotion perçue sans la juger. « J'ai l'impression que cette situation t'agace. »
- **Suspension du jugement** : rassembler les faits avant de se forger une opinion.
- **Synthèse** : résumer le sens général avant de passer à l'étape suivante.

## Attitudes à éviter

- Ramener la conversation à soi (« Moi aussi, quand j'étais… »).
- Donner des conseils immédiatement.
- Minimiser (« Ce n'est pas grave »), moraliser ou interpréter.

## Dans l'entretien managérial

L'écoute active est particulièrement utile dans les étapes Reality et Options du modèle GROW, en début d'entretien difficile et lorsque le collaborateur exprime une émotion forte. Laisser l'autre trouver ses propres solutions et l'encourager ensuite à passer à l'action.
